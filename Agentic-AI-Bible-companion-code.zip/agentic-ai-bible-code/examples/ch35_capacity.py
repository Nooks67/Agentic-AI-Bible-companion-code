"""Chapter 35: measure throughput and latency under load, check them with Little's law, and model monthly cost.

The agent is a stand-in that takes 200 ms per run (a typical single model call would take longer); the HTTP
service, job queue and workers are the real Module XI service running in-process.
"""
import concurrent.futures
import json
import statistics
import sys
import tempfile
import time
from pathlib import Path

from starlette.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m11_deploy"))
from deploy_server import create_app  # noqa: E402

from agentlab import Usage  # noqa: E402
from agentlab.agent import RunResult  # noqa: E402

RUN_SECONDS = 0.2
KEY = "load-test-key-0123456789"


def factory(payload):
    def run(message):
        time.sleep(RUN_SECONDS)
        return RunResult("done", "ok", 3, 2, Usage(2400, 180), 0.0)
    return run


def load_test(workers: int, jobs: int = 40) -> dict:
    with tempfile.TemporaryDirectory() as tmp, TestClient(
            create_app(factory, {KEY: {"budget_usd": 100}}, f"{tmp}/jobs.db", workers=workers,
                       requests_per_minute=10_000)) as c:
        h = {"authorization": f"Bearer {KEY}"}
        t0 = time.perf_counter()
        ids = [c.post("/v1/runs", headers=h, json={"message": f"m{i}", "customer_email": "a@b.c"}).json()["run_id"]
               for i in range(jobs)]
        submitted = {rid: time.perf_counter() for rid in ids}
        latency = {}
        while len(latency) < jobs:
            for rid in ids:
                if rid not in latency and c.get(f"/v1/runs/{rid}", headers=h).json()["status"] == "done":
                    latency[rid] = time.perf_counter() - submitted[rid]
            time.sleep(0.01)
        elapsed = time.perf_counter() - t0
    lat = sorted(latency.values())
    throughput = jobs / elapsed
    return {"workers": workers, "throughput_per_s": round(throughput, 1), "p50_s": round(statistics.median(lat), 2),
            "p95_s": round(lat[int(0.95 * (len(lat) - 1))], 2),
            "littles_law_in_service": round(throughput * statistics.mean(lat), 1)}


def monthly_cost(runs_per_day: int, in_tok: int, out_tok: int, price_in: float, price_out: float,
                 small_share: float = 0.0, small_factor: float = 0.2, cache_hit: float = 0.0) -> float:
    """USD per 30 days. small_share of runs go to a model costing small_factor as much; cache hits cost nothing."""
    per_run = in_tok / 1e6 * price_in + out_tok / 1e6 * price_out
    blended = per_run * ((1 - small_share) + small_share * small_factor) * (1 - cache_hit)
    return round(runs_per_day * 30 * blended, 2)


if __name__ == "__main__":
    for w in (2, 8):
        print(json.dumps(load_test(w)))
    print(f"\ntheoretical maximum: workers / run time = 2/{RUN_SECONDS} = {2 / RUN_SECONDS:.0f}/s and 8/{RUN_SECONDS} = {8 / RUN_SECONDS:.0f}/s")
    print("\nmonthly model cost, 3,000 runs/day, 2,400 in + 180 out tokens per run, illustrative prices $3 / $15 per M:")
    for label, kw in [("all large model", {}), ("60% routed to small", {"small_share": 0.6}),
                      ("routing + 20% cache hits", {"small_share": 0.6, "cache_hit": 0.2})]:
        print(f"  {label:<26} ${monthly_cost(3000, 2400, 180, 3.0, 15.0, **kw):>8,.2f}")
