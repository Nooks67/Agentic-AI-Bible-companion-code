"""Chapter 36: alert rules over two metric scrapes, and a compatibility check for tool schema changes."""
import re

SCRAPE_0900 = """agent_runs_total{status="done"} 1180
agent_runs_total{status="failed"} 12
agent_runs_total{status="max_steps"} 9
agent_cost_usd_total 41.20
agent_queue_depth 3
"""
SCRAPE_0915 = """agent_runs_total{status="done"} 1290
agent_runs_total{status="failed"} 31
agent_runs_total{status="max_steps"} 10
agent_cost_usd_total 47.95
agent_queue_depth 42
"""


def parse(text: str) -> dict[str, float]:
    out = {}
    for line in text.splitlines():
        m = re.match(r'(\w+)(?:\{status="(\w+)"\})?\s+([\d.]+)$', line.strip())
        if m:
            out[m[1] + (f":{m[2]}" if m[2] else "")] = float(m[3])
    return out


def evaluate(before: dict, after: dict, minutes: float) -> list[str]:
    d = {k: after[k] - before.get(k, 0) for k in after}
    runs = sum(v for k, v in d.items() if k.startswith("agent_runs_total"))
    alerts = []
    fail_ratio = d["agent_runs_total:failed"] / runs
    if fail_ratio > 0.05:
        alerts.append(f"PAGE failure ratio {fail_ratio:.1%} over {minutes:.0f} min (threshold 5%)")
    cost_per_hour = d["agent_cost_usd_total"] / minutes * 60
    if cost_per_hour > 20:
        alerts.append(f"TICKET spend rate ${cost_per_hour:.2f}/h (threshold $20/h)")
    if after["agent_queue_depth"] > 30:
        alerts.append(f"PAGE queue depth {after['agent_queue_depth']:.0f} (threshold 30)")
    return alerts


def breaking_changes(old: dict, new: dict) -> list[str]:
    """Changes to a tool's parameter schema that break callers built for the old version."""
    out = []
    op, np_ = old.get("properties", {}), new.get("properties", {})
    for name in op.keys() - np_.keys():
        out.append(f"removed parameter '{name}'")
    for name in set(new.get("required", [])) - set(old.get("required", [])):
        out.append(f"'{name}' is newly required")
    for name in op.keys() & np_.keys():
        if op[name].get("type") != np_[name].get("type"):
            out.append(f"'{name}' changed type {op[name].get('type')} -> {np_[name].get('type')}")
        if "enum" in np_[name] and ("enum" not in op[name] or set(op[name]["enum"]) - set(np_[name]["enum"])):
            out.append(f"'{name}' accepts fewer values")
    return out


if __name__ == "__main__":
    print("alerts:", evaluate(parse(SCRAPE_0900), parse(SCRAPE_0915), 15))
    v1 = {"type": "object", "properties": {"order_id": {"type": "string"}, "reason": {"type": "string"}},
          "required": ["order_id"]}
    v2_ok = {"type": "object", "properties": {"order_id": {"type": "string"}, "reason": {"type": "string"},
                                              "photo_url": {"type": "string"}}, "required": ["order_id"]}
    v2_bad = {"type": "object", "properties": {"order_id": {"type": "integer"}, "sku": {"type": "string"}},
              "required": ["order_id", "sku"]}
    print("v1 -> v2 (optional field added):", breaking_changes(v1, v2_ok) or "compatible")
    print("v1 -> v2 (redesigned):", breaking_changes(v1, v2_bad))
