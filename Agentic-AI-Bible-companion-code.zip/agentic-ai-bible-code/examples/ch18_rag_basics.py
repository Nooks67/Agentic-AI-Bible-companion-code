"""Chapter 18: the whole retrieval-augmented generation pipeline in one page.

load -> chunk -> embed + index -> retrieve -> build context -> answer -> check citations
The answer comes from a scripted model; retrieval, context and checks are real.
"""
from pathlib import Path

from agentlab import ScriptedModel
from agentlab.rag import HashingEmbedder, VectorStore, answer, build_context, check_citations, load_folder

DOCS = Path(__file__).resolve().parents[1] / "projects" / "m06_rag" / "docs"

chunks = load_folder(DOCS, max_words=90, overlap=15)
print(f"{len(chunks)} chunks from {len({c.doc for c in chunks})} documents; first: {chunks[0].id} "
      f"({len(chunks[0].text.split())} words, section '{chunks[0].meta['section']}')")

store = VectorStore(HashingEmbedder(dim=1024))
store.add(chunks)

question = "How long do refunds take to reach my card?"
hits = store.search(question, k=3)
for c, score in hits:
    print(f"  {score:.3f}  {c.id:<12} {c.text[:60]}...")

print("\ncontext sent to the model (first 260 chars):\n" + build_context(hits)[:260] + " ...\n")

model = ScriptedModel(["Refunds go back to the original payment method within 5 business days of the return "
                       "arriving at our warehouse [returns#2]."])
reply = answer(model, question, hits)
print("answer:", reply)
print("citation check:", check_citations(reply, hits))
