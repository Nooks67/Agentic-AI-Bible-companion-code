"""Chapter 9: a support workflow where code owns the route and the model owns only bounded decisions.

triage (model, structured) -> route (code) -> order agent | policy answer | human queue -> review (code) -> end
Model steps are simulated with small functions here so every branch is easy to see.
"""
from agentlab.workflow import END, Graph, GraphCheckpoints


def triage(s):            # in production: ask_structured(model, ..., Ticket) from Module II
    text = s["email"].lower()
    cat = "spam" if "seo" in text else "shipping" if "where is" in text else "returns" if "return" in text else "other"
    return {**s, "category": cat, "priority": 1 if "third email" in text else 2}


def order_agent(s):       # in production: the Module III agent with tools and limits
    return {**s, "draft": "Your order is held at the regional hub; please confirm your address.", "agent_steps": 3}


def policy_answer(s):     # in production: the Module VI retrieval assistant
    return {**s, "draft": "Unused items can be returned within 30 days of delivery [returns#1]."}


def human_queue(s):
    return {**s, "queued_for": "support team", "draft": None}


def review(s):            # deterministic checks on whatever the model drafted
    ok = s.get("draft") is None or ("refund" not in s["draft"].lower() and len(s["draft"]) < 600)
    return {**s, "approved_to_send": ok and s.get("draft") is not None}


def route(s) -> str:
    if s["category"] == "spam":
        return END
    if s["priority"] == 1 or s["category"] == "other":
        return "human_queue"
    return "order_agent" if s["category"] == "shipping" else "policy_answer"


g = (Graph(max_transitions=10)
     .step("triage", triage, start=True).step("order_agent", order_agent).step("policy_answer", policy_answer)
     .step("human_queue", human_queue).step("review", review))
g.edge("triage", route).edge("order_agent", "review").edge("policy_answer", "review")
g.edge("human_queue", END).edge("review", END)

for email in ["Where is my order BL-10301?", "Can I return unused boots?",
              "This is my third email, where is BL-10301???", "We offer SEO services"]:
    out = g.run({"email": email}, GraphCheckpoints(), run_id=email[:8])
    print(f"{email[:44]:<46} path={' > '.join(out['_history'])}  send={out.get('approved_to_send', False)}")
