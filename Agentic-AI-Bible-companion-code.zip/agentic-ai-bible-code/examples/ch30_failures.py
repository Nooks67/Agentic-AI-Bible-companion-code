"""Chapter 30: inject faults into a tool's dependency, validate responses, and roll back a half-finished action."""
import json
from datetime import datetime

from pydantic import BaseModel, ValidationError

from agentlab import ToolRegistry, tool
from agentlab.resilience import RetryableError, retry

GOOD = {"tracking": "TRK-87650", "events": [{"at": "2026-09-14T10:30", "event": "Picked up"},
                                            {"at": "2026-09-17T11:00", "event": "Held at hub"}]}
FAULTS = {   # what the carrier does on each successive call
    "healthy": [GOOD],
    "503 once": [RetryableError("503"), GOOD],
    "503 always": [RetryableError("503")] * 3,
    "connection reset": [ConnectionError("reset by peer")] * 3,
    "wrong parcel": [{**GOOD, "tracking": "TRK-11111"}],
    "malformed": [{"tracking": "TRK-87650", "events": [{"when": "yesterday"}]}],
    "time travel": [{"tracking": "TRK-87650", "events": [{"at": "2026-09-01T08:00", "event": "Delivered"}]}],
}


class Event(BaseModel):
    at: datetime
    event: str


class Tracking(BaseModel):
    tracking: str
    events: list[Event]


def make_tool(responses: list, placed: str = "2026-09-12"):
    queue = list(responses)

    def carrier(number: str) -> dict:
        r = queue.pop(0)
        if isinstance(r, Exception):
            raise r
        return r

    @tool
    def track(number: str) -> list[dict]:
        """Tracking events for a parcel.

        Args:
            number: Carrier tracking number.
        """
        raw = retry(lambda: carrier(number), attempts=3, sleep=lambda s: None)
        data = Tracking.model_validate(raw)                                   # shape
        if data.tracking != number:                                           # identity
            raise ValueError(f"carrier answered for {data.tracking}, not {number}")
        if any(e.at < datetime.fromisoformat(placed) for e in data.events):  # plausibility
            raise ValueError("event dated before the order was placed")
        return [e.model_dump(mode="json") for e in data.events]
    return track


# ---------------------------------------------------------------- rollback with a compensating action
class Shop:
    def __init__(self):
        self.stock, self.reserved, self.charges = {"TN-ALPINE2": 3}, [], []

    def reserve(self, sku):
        self.stock[sku] -= 1
        self.reserved.append(sku)

    def release(self, sku):
        self.stock[sku] += 1
        self.reserved.remove(sku)

    def charge(self, amount, fail=False):
        if fail:
            raise ConnectionError("payment provider unavailable")
        self.charges.append(amount)


def place_replacement(shop: Shop, sku: str, amount: float, payment_fails: bool) -> str:
    shop.reserve(sku)
    try:
        shop.charge(amount, fail=payment_fails)
    except Exception as e:
        shop.release(sku)                  # compensate: undo the step that succeeded
        return f"rolled back ({e})"
    return "placed"


if __name__ == "__main__":
    for name, responses in FAULTS.items():
        res = ToolRegistry().add(make_tool(responses)).call("track", {"number": "TRK-87650"})
        print(f"{name:<17} {'ok   ' if res.ok else 'ERROR'} {(res.content if res.ok else res.error).splitlines()[0][:78]}")
    for fails in (False, True):
        shop = Shop()
        outcome = place_replacement(shop, "TN-ALPINE2", 289.0, payment_fails=fails)
        print(f"payment_fails={fails!s:<5} -> {outcome}; stock={shop.stock['TN-ALPINE2']}, charges={shop.charges}")
