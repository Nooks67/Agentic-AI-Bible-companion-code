"""Chapter 1: the smallest useful agent - one tool, one loop, hard limits, a trace.

Run:  python examples/ch01_first_agent.py
The model here is scripted (it replays two decisions) so the example runs offline.
Replace it with model_from_env() to use a real provider (Appendix A).
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agentlab import Agent, AgentConfig, ScriptedModel, ToolRegistry, call, tool

ORDERS = {"BL-10301": {"status": "shipped", "carrier_note": "held at regional hub: address could not be verified"}}


@tool
def lookup_order(order_id: str) -> dict:
    """Get the status of a Brightline order.

    Args:
        order_id: Order number like BL-10301.
    """
    if order_id not in ORDERS:
        raise LookupError(f"no order {order_id}")
    return ORDERS[order_id]


model = ScriptedModel([
    [call("lookup_order", id="call_1", order_id="BL-10301")],      # decision 1: use the tool
    "Your order BL-10301 has shipped but is held at the regional hub because the address "
    "could not be verified. Please reply with your full address.",  # decision 2: answer
])

agent = Agent(model, ToolRegistry().add(lookup_order),
              system="You answer order questions for Brightline Outfitters. Use tools; never guess.",
              config=AgentConfig(max_steps=4, max_tool_calls=4))
result = agent.run("Where is my order BL-10301?")

for e in agent.tracer.events:
    keep = {k: e[k] for k in ("kind", "step", "tool_calls", "tool", "ok", "status") if k in e}
    print(json.dumps(keep))
print("\nANSWER:", result.answer)
print(f"status={result.status} steps={result.steps} tool_calls={result.tool_calls} "
      f"tokens={result.usage.input_tokens}+{result.usage.output_tokens} (estimated)")
