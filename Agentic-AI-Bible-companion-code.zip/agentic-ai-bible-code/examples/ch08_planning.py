"""Chapter 8: plans as data - validate them, order them, run independent steps together, revise on failure.

The plan is the kind of JSON a planner model returns (here written by hand).
"""
import json

from agentlab.multi import Plan, validate_plan


def waves(plan: Plan) -> list[list[str]]:
    """Group tasks into waves: every task in a wave depends only on tasks in earlier waves."""
    done: set[str] = set()
    remaining = {t.id: set(t.depends_on) for t in plan.tasks}
    out = []
    while remaining:
        ready = sorted(t for t, deps in remaining.items() if deps <= done)
        if not ready:
            raise ValueError("no task can start: dependency cycle")
        out.append(ready)
        done |= set(ready)
        for t in ready:
            del remaining[t]
    return out


PLAN = {"tasks": [
    {"id": "order", "worker": "orders", "instruction": "look up order BL-10301"},
    {"id": "tracking", "worker": "orders", "instruction": "get carrier events for BL-10301", "depends_on": ["order"]},
    {"id": "policy", "worker": "policy", "instruction": "find the policy for parcels held at a hub"},
    {"id": "history", "worker": "crm", "instruction": "list the customer's previous contacts"},
    {"id": "reply", "worker": "writer", "instruction": "draft the reply", "depends_on": ["tracking", "policy", "history"]},
]}
WORKERS = {"orders": None, "policy": None, "crm": None, "writer": None}

plan = Plan.model_validate(PLAN)
validate_plan(plan, WORKERS)
for i, wave in enumerate(waves(plan), 1):
    print(f"wave {i}: {', '.join(wave)}")

# Dynamic revision: the CRM is down, so the planner replaces 'history' and drops it from the reply's inputs.
revised = json.loads(json.dumps(PLAN))
revised["tasks"] = [t for t in revised["tasks"] if t["id"] != "history"]
revised["tasks"][-1]["depends_on"] = ["tracking", "policy"]
revised["tasks"][-1]["instruction"] += " (note: contact history unavailable)"
plan2 = Plan.model_validate(revised)
validate_plan(plan2, WORKERS)
print("revised:", " | ".join(", ".join(w) for w in waves(plan2)))

# A planner mistake is caught before anything runs.
bad = json.loads(json.dumps(PLAN))
bad["tasks"][0]["depends_on"] = ["reply"]
try:
    validate_plan(Plan.model_validate(bad), WORKERS)
except ValueError as e:
    print("rejected plan:", e)
