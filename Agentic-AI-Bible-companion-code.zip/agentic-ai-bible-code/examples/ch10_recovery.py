"""Chapter 10: crash in the middle of a run, resume from the checkpoint, and never repeat a side effect.

A real crash (power loss, deploy, out-of-memory) is simulated with an exception that the loop does not catch.
"""
import os
import tempfile

from agentlab import Agent, CheckpointStore, IdempotencyLedger, ScriptedModel, ToolRegistry, call, tool

work = tempfile.mkdtemp()
store = CheckpointStore(os.path.join(work, "runs.db"))           # survives the "crash": it is a file
ledger = IdempotencyLedger(os.path.join(work, "actions.db"))
labels_created = []


@tool(risk="write")
def create_return_label(order_id: str, sku: str) -> dict:
    """Create a prepaid return label (charges Brightline's carrier account).

    Args:
        order_id: Order number.
        sku: Item to return.
    """
    key = ledger.key("label", order=order_id, sku=sku)
    def do():
        labels_created.append(order_id)
        return {"label": f"LBL-{len(labels_created):04d}", "order": order_id}
    result, fresh = ledger.run_once(key, do)
    return {**result, "newly_created": fresh}


class Crash(BaseException):
    pass


def crash(_):
    raise Crash("process killed during model call")


class YesToLabels:
    def approve(self, t, args):
        return t.name == "create_return_label"


step = [call("create_return_label", order_id="BL-10388", sku="TN-ALPINE2")]

first = Agent(ScriptedModel([step, crash]), ToolRegistry(approver=YesToLabels()).add(create_return_label), store=store)
try:
    first.run("Create a return label for the tent in BL-10388.", run_id="ret-42")
except Crash as e:
    print("crashed:", e)
cp = store.load("ret-42")
print(f"checkpoint: step={cp.step} status={cp.status} last message role={cp.messages[-1].role}")

# The new process does not know whether the label was created; the model asks again.
second = Agent(ScriptedModel([step, "Your return label is LBL-0001."]),
               ToolRegistry(approver=YesToLabels()).add(create_return_label), store=store)
res = second.resume("ret-42")
print(f"resumed: status={res.status} answer={res.answer!r}")
print("tool result after resume:", res.messages[-2].content)
print("labels actually created:", len(labels_created))
