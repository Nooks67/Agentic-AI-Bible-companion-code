"""Chapter 6: route easy requests to a small model, fall back when a provider fails, cache repeats.

All three 'models' are scripted stand-ins so the behaviour is visible and repeatable.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agentlab import Message, ScriptedModel
from agentlab.routing import CachedModel, FallbackModel, RouterModel


class Outage:
    """A provider that is down: every call raises, as a real client would on a 503 after retries."""
    name = "large-primary"

    def complete(self, messages, tools=None, **opts):
        raise ConnectionError("503 Service Unavailable")


def choose(messages, tools) -> str:
    """Routing rule: tool-using or long requests go to the large tier; short questions to the small one."""
    text = messages[-1].content
    return "large" if tools or len(text) > 400 or "refund" in text.lower() else "small"


small = ScriptedModel(["Standard shipping takes 3 to 5 business days."] * 3, name="small")
large_backup = ScriptedModel(["I've checked the order and opened a refund request for review."], name="large-backup")
fallback_log = []
large = FallbackModel([Outage(), large_backup], on_fallback=lambda name, e: fallback_log.append(f"{name}: {e}"))
router = RouterModel({"small": small, "large": large}, choose)
model = CachedModel(router)

for q in ["How long is standard shipping?", "I want a refund for BL-10388, the tent zipper broke.",
          "How long is standard shipping?"]:
    reply = model.complete([Message("user", q)])
    print(f"{q[:52]:<54} -> {reply.message.content[:60]}")
print("\nroutes taken:", router.log)
print("fallbacks:", fallback_log)
print(f"cache hits={model.hits} misses={model.misses}")
