"""Chapter 2: how context and cost grow inside an agent loop.

Every model call re-sends the whole conversation, so input tokens grow with each step.
Token counts here are estimates (about 4 characters per token); use your provider's
reported usage for billing. Prices are illustrative placeholders, not current rates.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agentlab import Message, estimate_tokens
from agentlab.agent import Pricing
from agentlab.llm import Usage

SYSTEM = "You answer order questions for Brightline Outfitters. Use tools; never guess. " * 3
TOOL_SPEC_TOKENS = 180            # the JSON schemas of the tools are sent on every call too
PRICE = Pricing(input_per_m=2.00, output_per_m=8.00)   # illustrative USD per million tokens

conversation = [Message("system", SYSTEM), Message("user", "Where is my order BL-10301? It was due Monday.")]
turns = [
    ("assistant", '{"tool": "lookup_order", "order_id": "BL-10301"}'),
    ("tool", '{"status": "shipped", "items": 2, "tracking": "TRK-87650", "placed": "2026-09-12"}'),
    ("assistant", '{"tool": "track_shipment", "order_id": "BL-10301"}'),
    ("tool", '[{"at": "2026-09-14T10:30", "event": "Picked up"}, {"at": "2026-09-16T03:10", '
             '"event": "Arrived at regional hub"}, {"at": "2026-09-17T11:00", "event": "Held at hub: '
             'address could not be verified"}]'),
    ("assistant", "Your order is held at the regional hub because the address could not be verified. "
                  "Please reply with your full delivery address so we can release it."),
]

total = Usage()
print(f"{'call':>4} {'input':>7} {'output':>7} {'cumulative cost':>16}")
call_no = 0
for i in range(0, len(turns), 2):
    call_no += 1
    sent = sum(estimate_tokens(m.content) for m in conversation) + TOOL_SPEC_TOKENS
    out = estimate_tokens(turns[i][1])
    total = total + Usage(sent, out)
    print(f"{call_no:>4} {sent:>7} {out:>7} {PRICE.cost(total):>15.6f}")
    conversation += [Message(r, c) for r, c in turns[i:i + 2]]

print(f"\ninput tokens across all calls: {total.input_tokens}  (vs {sent} in the final prompt alone)")
print(f"cost per conversation: ${PRICE.cost(total):.6f};  per 10,000 conversations: ${PRICE.cost(total) * 10_000:,.2f}")
