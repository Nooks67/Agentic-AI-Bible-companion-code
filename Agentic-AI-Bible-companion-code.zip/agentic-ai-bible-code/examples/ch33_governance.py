"""Chapter 33: a risk register, an AI system record with required fields, and incident severity rules."""
from dataclasses import dataclass, fields

LEVEL = {"low": 1, "medium": 2, "high": 3}


@dataclass
class Risk:
    id: str
    description: str
    likelihood: str
    impact: str
    controls: str
    owner: str

    @property
    def score(self) -> int:
        return LEVEL[self.likelihood] * LEVEL[self.impact]


REGISTER = [
    Risk("R1", "Agent shares another customer's order details", "low", "high",
         "tools scoped to sender; evaluation cases; audit", "Support lead"),
    Risk("R2", "Wrong delivery promise to a customer", "medium", "medium",
         "prompt rule; promise-check evaluation; tracking validation", "Support lead"),
    Risk("R3", "Refund issued without authority", "low", "high", "policy: approve <=150, deny above; audit", "Finance"),
    Risk("R4", "Injected instructions in documents trigger actions", "medium", "high",
         "untrusted wrapping; deny-by-default policy; approvals", "Security"),
    Risk("R5", "Model provider changes behaviour after an update", "high", "medium",
         "pinned model version; live evaluation before switching", "Engineering"),
]


@dataclass
class SystemRecord:
    name: str
    purpose: str
    owner: str
    users: str
    model: str
    data_used: str
    actions: str
    human_oversight: str
    evaluation: str
    known_limitations: str
    review_date: str


def missing(record: SystemRecord) -> list[str]:
    return [f.name for f in fields(record) if not getattr(record, f.name).strip()]


def severity(customer_impact: int, data_exposed: bool, money_moved: bool, ongoing: bool) -> str:
    if data_exposed or (money_moved and ongoing):
        return "SEV1"
    if money_moved or customer_impact >= 50:
        return "SEV2"
    return "SEV3" if customer_impact else "SEV4"


if __name__ == "__main__":
    print(f"{'id':<3} {'score':>5}  {'owner':<12} risk")
    for r in sorted(REGISTER, key=lambda r: -r.score):
        flag = "  <- review controls" if r.score >= 6 else ""
        print(f"{r.id:<3} {r.score:>5}  {r.owner:<12} {r.description}{flag}")
    rec = SystemRecord("Order desk assistant", "Answer order-status and return questions", "Head of Customer Operations",
                       "Customers by email", "provider model, pinned version", "orders, tracking, policy pages",
                       "look up orders; create returns (approved); escalate", "staff approve returns; sampled review",
                       "replay suite on every change; live suite before releases", "", "2026-10-01")
    print("\nsystem record missing:", missing(rec))
    for case in [(1, False, False, False), (120, False, False, False), (3, False, True, False), (1, True, False, False)]:
        print(f"impact={case[0]:<4} data={case[1]!s:<5} money={case[2]!s:<5} ongoing={case[3]!s:<5} -> {severity(*case)}")
