"""Chapter 26: AI decides, deterministic automation acts.

Part 1 - RPA: the agent may only choose a pre-approved bot and supply validated parameters.
Part 2 - physical systems: every command a planner proposes for a simulated arm passes a safety
envelope that the planner cannot change. Rejected commands are reported, never silently "fixed".
"""
from dataclasses import dataclass, field

from pydantic import BaseModel, Field, ValidationError


# ---------------------------------------------------------------- part 1: pre-approved bots
class UpdateAddress(BaseModel):
    customer_id: str = Field(pattern=r"^C-\d{5}$")
    postcode: str = Field(min_length=3, max_length=10)


BOTS = {   # each bot is a recorded, tested sequence of UI steps in the legacy desktop app
    "update_address": (UpdateAddress, ["open Customers", "search {customer_id}", "edit Address",
                                       "set Postcode={postcode}", "save", "verify banner 'Saved'"]),
}


def run_bot(name: str, params: dict) -> list[str]:
    if name not in BOTS:
        raise PermissionError(f"no approved bot named {name!r}")
    schema, steps = BOTS[name]
    p = schema(**params).model_dump()                     # raises ValidationError on bad input
    return [s.format(**p) for s in steps]


# ---------------------------------------------------------------- part 2: simulated arm
@dataclass
class Command:
    x: float
    y: float
    z: float
    speed: float          # mm/s
    grip: bool | None = None


@dataclass
class Cell:
    pos: tuple = (300.0, 0.0, 300.0)
    holding: bool = False
    person_in_zone: bool = False
    log: list = field(default_factory=list)


LIMITS = {"x": (0, 600), "y": (-300, 300), "z": (20, 400)}
MAX_SPEED, REDUCED_SPEED = 250, 50


def envelope(cmd: Command, cell: Cell) -> str | None:
    for axis, (lo, hi) in LIMITS.items():
        if not lo <= getattr(cmd, axis) <= hi:
            return f"{axis}={getattr(cmd, axis)} outside {lo}..{hi} mm"
    limit = REDUCED_SPEED if cell.person_in_zone else MAX_SPEED
    if cmd.speed > limit:
        return f"speed {cmd.speed} mm/s above {limit} mm/s" + (" (person in zone)" if cell.person_in_zone else "")
    return None


def execute(plan: list[Command], cell: Cell) -> bool:
    for i, cmd in enumerate(plan, 1):
        reason = envelope(cmd, cell)
        if reason:
            cell.log.append(f"step {i}: REJECTED {reason}; arm holds position, plan returned to planner")
            return False
        cell.pos = (cmd.x, cmd.y, cmd.z)
        if cmd.grip is not None:
            cell.holding = cmd.grip
        cell.log.append(f"step {i}: moved to {cell.pos} at {cmd.speed} mm/s" + (f", grip={cmd.grip}" if cmd.grip is not None else ""))
    return True


if __name__ == "__main__":
    print("bot steps:", run_bot("update_address", {"customer_id": "C-10442", "postcode": "97205"}))
    for name, params in [("update_address", {"customer_id": "10442", "postcode": "97205"}),
                         ("delete_customer", {"customer_id": "C-10442"})]:
        try:
            run_bot(name, params)
        except (ValidationError, PermissionError) as e:
            print(f"refused {name}: {type(e).__name__}: {str(e).splitlines()[0]}")

    first = [Command(450, 120, 200, 200), Command(450, 120, 5, 100, grip=True)]       # planner error: below the table
    second = [Command(450, 120, 200, 200), Command(450, 120, 40, 80, grip=True), Command(150, -200, 200, 200, grip=False)]
    cell = Cell()
    print("plan 1 ok:", execute(first, cell))
    cell.person_in_zone = True                                                           # light curtain trips
    print("plan 2 ok:", execute(second, cell))
    third = [Command(c.x, c.y, c.z, min(c.speed, REDUCED_SPEED), c.grip) for c in second]   # planner re-plans slower
    print("plan 3 ok:", execute(third, cell), "| holding:", cell.holding)
    print("\n".join(cell.log))
