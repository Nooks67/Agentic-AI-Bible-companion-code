"""Chapter 30: a quality gate for every change. Run in CI; a non-zero exit blocks the merge.

  python examples/ch30_quality_gate.py --baseline baseline.json
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m09_evals"))
from evalmon import run_eval  # noqa: E402

from agentlab.evals import compare  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def gate(baseline: Path) -> list[str]:
    problems = []
    tests = subprocess.run([sys.executable, "-m", "pytest", "examples/ch27_agent_tests.py",
                            "projects/m03_orderdesk"], cwd=ROOT, capture_output=True, text=True)
    print("unit and integration tests:", tests.stdout.strip().splitlines()[-1])
    if tests.returncode:
        problems.append("tests failed")
    rep = run_eval("replay")
    current = {"summary": rep.summary(), "results": [r.__dict__ for r in rep.results]}
    print("evaluation:", current["summary"]["passed"], "/", current["summary"]["cases"])
    problems += compare(json.loads(baseline.read_text()), current)
    return problems


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--baseline", type=Path, required=True)
    problems = gate(ap.parse_args().baseline)
    print("GATE:", "PASS" if not problems else "FAIL -> " + "; ".join(problems))
    sys.exit(1 if problems else 0)
