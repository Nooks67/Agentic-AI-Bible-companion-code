"""Chapter 13: connect to an MCP server over stdio and discover what it offers.

Launches projects/m04_mcp/brightline_mcp.py as a subprocess (the usual way local servers run),
backed by the demo inventory API started in this process.
"""
import asyncio
import os
import sys
from pathlib import Path

from mcp import Client, StdioServerParameters

PROJECT = Path(__file__).resolve().parents[1] / "projects" / "m04_mcp"
sys.path.insert(0, str(PROJECT))
from inventory_api import serve  # noqa: E402

api = serve(0, api_keys={"dev-key"})
env = {**os.environ, "INVENTORY_URL": f"http://127.0.0.1:{api.server_port}", "INVENTORY_API_KEY": "dev-key"}
server = StdioServerParameters(command=sys.executable, args=[str(PROJECT / "brightline_mcp.py")], env=env, cwd=str(PROJECT))


async def main() -> None:
    async with Client(server) as c:
        print("server:", c.server_info.name, c.server_info.version, "| protocol", c.protocol_version)
        for t in (await c.list_tools()).tools:
            ro = t.annotations.read_only_hint if t.annotations else None
            print(f"tool  {t.name:<16} read_only={ro!s:<5} args={list(t.input_schema['properties'])}")
        for r in (await c.list_resources()).resources:
            print(f"resource {r.uri}  ({r.mime_type})")
        for p in (await c.list_prompts()).prompts:
            print(f"prompt   {p.name}  args={[a.name for a in p.arguments or []]}")
        result = await c.call_tool("check_stock", {"sku": "TN-SOLO1"})
        print("check_stock ->", result.structured_content, "| is_error:", result.is_error)
        bad = await c.call_tool("reserve_stock", {"sku": "TN-SOLO1", "qty": 9})
        print("reserve_stock(qty=9) ->", bad.content[0].text, "| is_error:", bad.is_error)

asyncio.run(main())
api.shutdown()
