"""Chapter 39: a transparent return-on-investment model with a sensitivity table.

Every input is an assumption to be replaced with your own measurements; none of these figures is a benchmark.
"""
from dataclasses import dataclass, replace


@dataclass
class Case:
    tickets_per_month: int = 6000
    minutes_per_ticket: float = 6.0
    staff_cost_per_hour: float = 32.0
    automation_rate: float = 0.45          # share of tickets the agent completes without a person
    review_minutes: float = 1.0            # staff time still spent on each automated ticket (sampling, approvals)
    error_rate: float = 0.03               # automated tickets that need rework
    rework_minutes: float = 15.0
    model_cost_per_ticket: float = 0.012
    platform_cost_per_month: float = 900.0  # hosting, monitoring, evaluation runs
    build_cost: float = 60000.0            # one-off: design, build, integration, testing, training
    maintenance_per_month: float = 2500.0  # engineering time to operate and improve


def monthly(c: Case) -> dict:
    auto = c.tickets_per_month * c.automation_rate
    saved_hours = auto * (c.minutes_per_ticket - c.review_minutes) / 60
    rework_hours = auto * c.error_rate * c.rework_minutes / 60
    benefit = (saved_hours - rework_hours) * c.staff_cost_per_hour
    cost = c.tickets_per_month * c.model_cost_per_ticket + c.platform_cost_per_month + c.maintenance_per_month
    net = benefit - cost
    return {"benefit": round(benefit), "running_cost": round(cost), "net": round(net),
            "payback_months": round(c.build_cost / net, 1) if net > 0 else None}


if __name__ == "__main__":
    base = Case()
    print("base case:", monthly(base))
    print("\nsensitivity of payback (months) to the two most uncertain inputs:")
    rates = [0.25, 0.35, 0.45, 0.55]
    print("automation rate ->   " + "".join(f"{r:>8.0%}" for r in rates))
    for review in (0.5, 1.0, 2.0, 3.0):
        row = [monthly(replace(base, automation_rate=r, review_minutes=review))["payback_months"] for r in rates]
        print(f"review {review:>3} min/ticket  " + "".join(f"{('never' if p is None else p):>8}" for p in row))
