"""Chapter 19: measure retrieval before tuning it - compare chunk sizes and retrieval methods on a labelled set.

Labels in eval.jsonl name chunks produced with max_words=90; for other chunk sizes a hit counts when the
retrieved chunk comes from the same document section as a labelled chunk.
"""
import json
from pathlib import Path

from agentlab.rag import BM25, HashingEmbedder, HybridRetriever, VectorStore, load_folder, overlap_rerank, rrf

M06 = Path(__file__).resolve().parents[1] / "projects" / "m06_rag"
rows = [json.loads(l) for l in (M06 / "data" / "eval.jsonl").read_text().splitlines() if l.strip()]
answerable = [r for r in rows if r["relevant"]]
reference = {c.id: (c.doc, c.meta["section"]) for c in load_folder(M06 / "docs", max_words=90, overlap=15)}


def recall(search, k):
    hit = 0
    for r in answerable:
        want = {reference[i] for i in r["relevant"]}
        got = {(c.doc, c.meta["section"]) for c, _ in search(r["question"], k)}
        hit += bool(want & got)
    return hit / len(answerable)


print(f"{len(answerable)} answerable questions\n")
print(f"{'method':<26}{'chunk words':>12}{'chunks':>8}{'recall@1':>10}{'recall@3':>10}")
for size in (40, 90, 200):
    chunks = load_folder(M06 / "docs", max_words=size, overlap=min(15, size // 4))
    bm25 = BM25(chunks)
    vec = VectorStore(HashingEmbedder())
    vec.add(chunks)
    hybrid = HybridRetriever(chunks)
    methods = {
        "keyword (BM25)": bm25.search,
        "vector (hashing)": vec.search,
        "hybrid (RRF)": lambda q, k: rrf(bm25.search(q, 10), vec.search(q, 10), top=k),
        "hybrid + rerank": lambda q, k: hybrid.search(q, k=k),
    }
    for name, fn in methods.items():
        print(f"{name:<26}{size:>12}{len(chunks):>8}{recall(fn, 1):>10.3f}{recall(fn, 3):>10.3f}")

# What does stemming contribute? Exact chunk-id labels, project index (injected chunk quarantined).
import sys  # noqa: E402
import agentlab.rag as rag  # noqa: E402
sys.path.insert(0, str(M06))
from policy_assistant import build_index, evaluate  # noqa: E402
for flag in (False, True):
    rag.USE_STEMMING = flag
    print(f"\nstemming={flag}:", evaluate(build_index()))
