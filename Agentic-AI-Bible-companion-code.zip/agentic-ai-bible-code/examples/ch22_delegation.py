"""Chapter 22: parallel execution, ownership of shared state and failure propagation, with timings."""
import json
import time

from agentlab import ScriptedModel
from agentlab.multi import Coordinator


def slow(name, seconds):
    def worker(instruction, inputs):
        time.sleep(seconds)
        return f"{name} done"
    return worker


def crm_down(instruction, inputs):
    raise ConnectionError("CRM timeout")


PLAN = {"tasks": [
    {"id": "order", "worker": "orders", "instruction": "look up the order"},
    {"id": "policy", "worker": "policy", "instruction": "find the hub policy"},
    {"id": "history", "worker": "crm", "instruction": "list previous contacts"},
    {"id": "tracking", "worker": "orders", "instruction": "carrier events", "depends_on": ["order"]},
    {"id": "summary", "worker": "writer", "instruction": "summarise contact history", "depends_on": ["history"]},
    {"id": "reply", "worker": "writer", "instruction": "draft the reply", "depends_on": ["tracking", "policy"]},
]}
workers = {"orders": slow("orders", 0.3), "policy": slow("policy", 0.3), "crm": crm_down, "writer": slow("writer", 0.2)}

for parallel in (1, 3):
    coord = Coordinator(ScriptedModel([json.dumps(PLAN)]), workers, parallel=parallel, retries=1)
    t0 = time.perf_counter()
    board = coord.execute(coord.plan("late order"))
    secs = time.perf_counter() - t0
    print(f"parallel={parallel}: {secs:.2f} s  " + ", ".join(f"{k}={r.status}" for k, r in board.records.items()))

print("history attempts:", board.records["history"].attempts, "| error:", board.records["history"].error)
try:
    board.write("reply", "orders", "done", output="tampered")
except PermissionError as e:
    print("ownership enforced:", e)
