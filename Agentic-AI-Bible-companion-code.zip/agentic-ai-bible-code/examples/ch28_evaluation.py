"""Chapter 28: task success, tool accuracy, judge calibration and how much a pass rate can be trusted.

The suite replays recorded model decisions through the real order-desk tools (Module IX project).
The judge scores are example model grades written for the exercise; the human grades are the reference.
"""
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m09_evals"))
from evalmon import load_cases, run_eval  # noqa: E402



def tool_accuracy(expected: dict[str, list[str]], used: dict[str, list[str]]) -> dict:
    """Precision: share of calls that were expected. Recall: share of expected tools that were called."""
    tp = sum(len(set(expected[c]) & set(used[c])) for c in expected)
    called = sum(len(set(used[c])) for c in expected)
    needed = sum(len(set(expected[c])) for c in expected)
    return {"precision": round(tp / max(1, called), 2), "recall": round(tp / max(1, needed), 2)}


def cohen_kappa(a: list[int], b: list[int]) -> float:
    labels = sorted(set(a) | set(b))
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    pe = sum((a.count(k) / n) * (b.count(k) / n) for k in labels)
    return (po - pe) / (1 - pe)


def wilson(passed: int, n: int, z: float = 1.96) -> tuple[float, float]:
    p = passed / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return round(centre - half, 3), round(centre + half, 3)


if __name__ == "__main__":
    report = run_eval("replay")
    print("suite:", json.dumps(report.summary()))
    _, meta = load_cases()
    expected = {cid: [n for turn in m["recorded"] if not isinstance(turn, str) for n, _ in turn] for cid, m in meta.items()}
    used = {cid: list(tools) for cid, tools in expected.items()}     # a candidate version that deviates twice:
    used["status-shipped"].append("escalate")                         # an unnecessary escalation
    used["status-shipped"].remove("track_shipment")                  # and a skipped tracking lookup
    print("tool accuracy:", tool_accuracy(expected, used))
    print("cases with different tools:", [c for c in expected if set(expected[c]) != set(used[c])])

    human = [5, 4, 2, 5, 3, 1, 4, 5, 2, 4, 3, 5]
    judge = [5, 4, 3, 5, 4, 1, 4, 5, 4, 4, 3, 4]
    exact = sum(h == j for h, j in zip(human, judge)) / len(human)
    within1 = sum(abs(h - j) <= 1 for h, j in zip(human, judge)) / len(human)
    print(f"judge vs human: exact {exact:.2f}, within one point {within1:.2f}, kappa {cohen_kappa(human, judge):.2f}")
    print("judge passes (>=4) that humans fail (<=3):",
          sum(j >= 4 and h <= 3 for h, j in zip(human, judge)), "of", len(human))

    for passed, n in [(8, 9), (80, 90), (800, 900)]:
        print(f"pass rate {passed}/{n} = {passed / n:.3f}  95% interval {wilson(passed, n)}")
