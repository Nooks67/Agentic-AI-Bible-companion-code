"""Chapter 27: unit, mocked and regression tests for agent components.

  python -m pytest examples/ch27_agent_tests.py -q
"""
import json

import pytest

from agentlab import Agent, ScriptedModel, ToolRegistry, call, tool
from agentlab.structured import extract_json


# ---------------------------------------------------------------- unit tests: deterministic parts
@tool
def shipping_quote(weight_kg: float, zone: str) -> dict:
    """Shipping price for a parcel.

    Args:
        weight_kg: Parcel weight in kilograms.
        zone: Destination zone, A or B.
    """
    if weight_kg <= 0:
        raise ValueError("weight must be positive")       # added after incident INC-044
    if zone not in ("A", "B"):
        raise ValueError(f"unknown zone {zone}")
    return {"usd": round(4.5 + weight_kg * (1.2 if zone == "A" else 2.0), 2)}


def test_tool_logic():
    assert shipping_quote.fn(2.0, "A") == {"usd": 6.9}


def test_schema_rejects_bad_arguments_before_the_tool_runs():
    reg = ToolRegistry().add(shipping_quote)
    res = reg.call("shipping_quote", {"weight_kg": "heavy", "zone": "A"})
    assert not res.ok and "weight_kg" in res.error
    assert reg.call("shipping_quote", {"weight_kg": 1, "zone": "C"}).error.endswith("ValueError: unknown zone C")


@pytest.mark.parametrize("text, expected", [
    ('{"a": 1}', {"a": 1}),
    ('Sure! ```json\n{"a": "x}"}\n```', {"a": "x}"}),
    ('Result: {"a": {"b": [1, 2]}} done', {"a": {"b": [1, 2]}}),
])
def test_json_extraction(text, expected):
    assert json.loads(extract_json(text)) == expected


# ---------------------------------------------------------------- mocking an external API
class FakeCarrier:
    """Stands in for the carrier API: scripted responses, records every call."""
    def __init__(self, responses):
        self.responses, self.calls = list(responses), []

    def track(self, number):
        self.calls.append(number)
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def make_tracking_tool(carrier):
    @tool
    def track(number: str) -> list:
        """Tracking events.

        Args:
            number: Carrier tracking number.
        """
        for attempt in range(2):
            try:
                return carrier.track(number)
            except TimeoutError:
                if attempt == 1:
                    raise
    return track


def test_timeout_is_retried_once_then_succeeds():
    carrier = FakeCarrier([TimeoutError("read timeout"), [{"event": "Delivered"}]])
    reg = ToolRegistry().add(make_tracking_tool(carrier))
    assert reg.call("track", {"number": "TRK-1"}).ok and carrier.calls == ["TRK-1", "TRK-1"]


def test_agent_reports_persistent_outage_instead_of_inventing_status():
    carrier = FakeCarrier([TimeoutError("t1"), TimeoutError("t2")])
    model = ScriptedModel([[call("track", number="TRK-1")], "Tracking is unavailable right now; please try later."])
    res = Agent(model, ToolRegistry().add(make_tracking_tool(carrier))).run("Where is TRK-1?")
    assert "timed out" in model.calls[1][-1].content      # the model saw the failure
    assert "Delivered" not in res.answer and res.status == "done"


# ---------------------------------------------------------------- regression tests from incidents
INCIDENTS = [   # one row per production incident, kept forever
    ("INC-031", "zone with a leading space", {"weight_kg": 1.5, "zone": " A"}, "unknown zone"),
    ("INC-044", "negative weight accepted", {"weight_kg": -2, "zone": "A"}, "weight must be positive"),
]


@pytest.mark.parametrize("incident, title, args, expect", INCIDENTS, ids=[i[0] for i in INCIDENTS])
def test_incident_does_not_recur(incident, title, args, expect):
    res = ToolRegistry().add(shipping_quote).call("shipping_quote", args)
    assert not res.ok and expect in res.error, f"{incident}: {title}"
