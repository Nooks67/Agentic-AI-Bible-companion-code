"""Chapter 5: assembling context deliberately, then forcing a structured, validated answer.

Context is built from labelled sections in a fixed order, each with a token budget.
The model here is scripted: its first reply is invalid on purpose, so you can watch
the validate-and-repair loop work.
"""
import json
import sys
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agentlab import Message, ScriptedModel, estimate_tokens
from agentlab.structured import ask_structured


def section(title: str, body: str, budget: int) -> str:
    """Trim a section to its token budget and say so, so the model knows text is missing."""
    if estimate_tokens(body) > budget:
        body = body[: budget * 4].rsplit(" ", 1)[0] + " [...truncated]"
    return f"## {title}\n{body}"


def build_context(task: str, facts: dict, history: list[str], policy: str) -> str:
    parts = [
        section("Task", task, 120),
        section("Facts from tools (authoritative)", json.dumps(facts, indent=1), 400),
        section("Relevant policy", policy, 300),
        section("Recent conversation (oldest first)", "\n".join(history[-4:]), 300),
    ]
    return "\n\n".join(parts)


class Decision(BaseModel):
    action: Literal["answer", "ask_customer", "escalate"]
    reply: str = Field(min_length=10, max_length=600)
    facts_used: list[str] = Field(min_length=1, description="keys from the Facts section that support the reply")
    conflict_noted: bool = Field(description="true if the customer's claim contradicts the facts")


facts = {"order.status": "delivered", "order.delivered_at": "2026-10-02T14:40", "carrier.last_event": "Delivered to front door"}
history = ["customer: My order BL-10422 never arrived!", "agent: Let me check that for you."]
policy = "If a parcel is marked delivered but the customer did not receive it, open a carrier investigation (escalate)."
context = build_context("Respond to the customer's latest message.", facts, history, policy)

model = ScriptedModel([
    '{"action": "refund", "reply": "Refund issued.", "facts_used": []}',
    json.dumps({"action": "escalate", "facts_used": ["order.status", "carrier.last_event"], "conflict_noted": True,
                "reply": "Our records show BL-10422 was delivered to your front door on 2 October. Since you did not "
                         "receive it, I've asked a colleague to open an investigation with the carrier."}),
])
decision, usage = ask_structured(model, [Message("system", "You are Brightline's order desk."), Message("user", context)], Decision)
print(context, "\n")
print("repair prompt sent:", model.calls[1][-1].content[:150], "...\n")
print(decision.model_dump_json(indent=1))
print(f"model calls: {len(model.calls)}")
