"""Chapter 7: every way an agent run can end, demonstrated with scripted models.

Each scenario prints the final status. In production you would alert on the
non-'done' statuses and review a sample of those runs.
"""
import time

from agentlab import Agent, AgentConfig, ScriptedModel, ToolRegistry, call, tool
from agentlab.agent import Pricing


@tool
def check_stock(sku: str) -> dict:
    """Units in stock for a SKU.

    Args:
        sku: Product SKU such as TN-ALPINE2.
    """
    return {"sku": sku, "in_stock": 6}


class SlowModel:
    name = "slow"

    def __init__(self):
        self.inner = ScriptedModel([[call("check_stock", sku=f"S{i}")] for i in range(10)])

    def complete(self, messages, tools=None, **opts):
        time.sleep(0.15)                        # a slow provider
        return self.inner.complete(messages, tools)


class BrokenModel:
    name = "broken"

    def complete(self, messages, tools=None, **opts):
        raise TimeoutError("provider did not respond in 60 s")


def run(label, model, config, pricing=None):
    reg = ToolRegistry().add(check_stock)
    res = Agent(model, reg, config=config, pricing=pricing).run("Is the Alpine tent in stock?")
    print(f"{label:<28} status={res.status:<15} steps={res.steps} tool_calls={res.tool_calls} cost=${res.cost_usd:.4f}")


run("normal answer", ScriptedModel([[call("check_stock", sku="TN-ALPINE2")], "Yes, 6 in stock."]), AgentConfig())
run("never stops calling tools", ScriptedModel([[call("check_stock", sku=f"S{i}")] for i in range(20)]),
    AgentConfig(max_steps=5))
run("asks for 8 tools at once", ScriptedModel([[call("check_stock", sku=f"S{i}") for i in range(8)]]),
    AgentConfig(max_tool_calls=5))
run("slow provider", SlowModel(), AgentConfig(max_seconds=0.4, max_steps=50))
run("expensive conversation", ScriptedModel([[call("check_stock", sku=f"S{i}")] for i in range(20)]),
    AgentConfig(max_cost_usd=0.002, max_steps=50), Pricing(input_per_m=3.0, output_per_m=15.0))
run("provider failure", BrokenModel(), AgentConfig())
