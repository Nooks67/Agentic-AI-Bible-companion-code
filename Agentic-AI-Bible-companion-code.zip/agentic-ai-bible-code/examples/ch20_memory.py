"""Chapter 20: short-term and long-term memory with budgets, provenance, expiry, redaction and erasure."""
from agentlab import Message, ScriptedModel, call, estimate_tokens
from agentlab.memory import ConversationWindow, LongTermMemory, compress

# --- short-term: a long support conversation squeezed into a 120-token window
convo = [Message("system", "You are Brightline's order desk.")]
for i in range(6):
    convo += [Message("user", f"Question {i}: " + "details " * 12), Message("assistant", f"Answer {i}: " + "words " * 10)]
convo += [Message("assistant", "", [call("lookup_order", id="c9", order_id="BL-10301")]),
          Message("tool", '{"status": "shipped"}', tool_call_id="c9"),
          Message("user", "So when will it arrive?")]
window = ConversationWindow(max_tokens=120).fit(convo)
total = sum(estimate_tokens(m.content) for m in convo)
print(f"full conversation: {len(convo)} messages, ~{total} tokens")
print(f"windowed: {len(window)} messages -> {[m.role for m in window]}")

# --- summarisation keeps meaning that windowing drops (summary text is scripted here)
summary_model = ScriptedModel(["- Customer: lee@example.com asked about late order BL-10301\n- Status: shipped, held at hub\n"
                               "- Open task: confirm delivery address"])
compressed = compress(summary_model, convo, keep_recent=3)
print(f"compressed: {len(compressed)} messages; summary message:\n{compressed[1].content}\n")

# --- long-term: facts with provenance, expiry and erasure (a fake clock makes time explicit)
now = [1_000_000.0]
mem = LongTermMemory(clock=lambda: now[0])
mem.remember("lee@example.com", "Prefers delivery to the Lisbon office, not home", kind="preference", ttl_days=365)
mem.remember("lee@example.com", "Call me on +351 912 345 678 about returns", kind="contact", ttl_days=30)
print("recall 'delivery address':", [m.text for m in mem.recall("lee@example.com", "delivery address office")])
print("stored contact note:", mem.recall("lee@example.com", "call returns")[0].text)
now[0] += 31 * 86400
print("after 31 days, purged:", mem.purge_expired(), "| remaining:", [m.text for m in mem.recall("lee@example.com", "delivery office returns")])
print("erasure request deleted:", mem.forget("lee@example.com"), "memories")
