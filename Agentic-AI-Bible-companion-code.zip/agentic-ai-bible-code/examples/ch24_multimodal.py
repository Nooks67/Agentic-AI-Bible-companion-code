"""Chapter 24: multimodal inputs as provider payloads, a document pipeline that prefers text, and field-level accuracy.

No vision or audio model is called here; the payload builders follow the providers' documented shapes and
the predictions in PREDICTED are example outputs written for the exercise.
"""
import base64
import io
import json
import tempfile
import wave
from pathlib import Path

from PIL import Image, ImageDraw
from pypdf import PdfReader

INVOICES = Path(__file__).resolve().parents[1] / "projects" / "m08_docs_browser" / "data" / "invoices"


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def openai_parts(text: str, png: bytes | None = None, wav: bytes | None = None) -> list[dict]:
    parts = [{"type": "text", "text": text}]
    if png:
        parts.append({"type": "image_url", "image_url": {"url": "data:image/png;base64," + b64(png), "detail": "high"}})
    if wav:
        parts.append({"type": "input_audio", "input_audio": {"data": b64(wav), "format": "wav"}})
    return parts


def anthropic_blocks(text: str, png: bytes | None = None, pdf: bytes | None = None) -> list[dict]:
    blocks = []
    if pdf:
        blocks.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": b64(pdf)}})
    if png:
        blocks.append({"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64(png)}})
    return blocks + [{"type": "text", "text": text}]


def receipt_photo() -> bytes:
    img = Image.new("RGB", (480, 300), "white")
    d = ImageDraw.Draw(img)
    for i, line in enumerate(["TRAILHEAD CAFE", "2x Coffee      7.00", "1x Bagel       3.50", "TOTAL         10.50"]):
        d.text((30, 30 + 50 * i), line, fill="black")
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return buf.getvalue()


def silence_wav(seconds: float = 1.5, rate: int = 16000) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1), w.setsampwidth(2), w.setframerate(rate)
        w.writeframes(b"\x00\x00" * int(seconds * rate))
    return buf.getvalue()


def route_document(path: Path) -> str:
    """Prefer the text layer: it is exact and cheap. Fall back to vision only for scans."""
    text = "".join(p.extract_text() or "" for p in PdfReader(path).pages)
    return "text" if len(text.strip()) > 50 else "vision"


# ---- field-level accuracy for document extraction
GOLD = {
    "summit-2291": {"vendor": "Summit Textiles Ltd", "invoice_number": "ST-2291", "total": "2265.00", "bank_last4": "4821"},
    "granite-7781": {"vendor": "Granite Freight Co", "invoice_number": "GF-7781", "total": "1405.00", "bank_last4": "0094"},
    "northlake-5520": {"vendor": "Northlake Packaging", "invoice_number": "NP-5520", "total": "620.00", "bank_last4": "3390"},
}
PREDICTED = {   # example extractor outputs, one with a misread digit and one with a formatting difference
    "summit-2291": {"vendor": "Summit Textiles Ltd", "invoice_number": "ST-2291", "total": "2,265.00", "bank_last4": "4821"},
    "granite-7781": {"vendor": "Granite Freight Co", "invoice_number": "GF-7787", "total": "1405.00", "bank_last4": "0094"},
    "northlake-5520": {"vendor": "Northlake Packaging Inc", "invoice_number": "NP-5520", "total": "620.00", "bank_last4": "3390"},
}


def norm(field: str, value: str) -> str:
    v = value.strip()
    if field == "total":
        return f"{float(v.replace(',', '')):.2f}"
    if field == "vendor":
        return v.lower().removesuffix(" inc").removesuffix(" ltd")
    return v


def field_accuracy(gold: dict, pred: dict) -> dict[str, float]:
    fields = next(iter(gold.values())).keys()
    return {f: sum(norm(f, pred[k][f]) == norm(f, gold[k][f]) for k in gold) / len(gold) for f in fields}


if __name__ == "__main__":
    png, wav = receipt_photo(), silence_wav()
    oa = openai_parts("Extract the total from this receipt.", png=png, wav=wav)
    an = anthropic_blocks("Extract the invoice fields.", pdf=(INVOICES / "summit-2291.pdf").read_bytes(), png=png)
    print("openai parts:   ", [p["type"] for p in oa], f"payload {len(json.dumps(oa)) // 1024} KiB")
    print("anthropic blocks:", [b["type"] for b in an], f"payload {len(json.dumps(an)) // 1024} KiB")
    scan = Path(tempfile.mkdtemp()) / "scanned-receipt.pdf"
    Image.open(io.BytesIO(png)).save(scan)          # an image-only PDF, like a phone scan
    for pdf in [*sorted(INVOICES.glob("*.pdf")), scan]:
        print(f"{pdf.name:<20} route: {route_document(pdf)}")
    acc = field_accuracy(GOLD, PREDICTED)
    print("field accuracy:", {k: round(v, 2) for k, v in acc.items()})
    exact = sum(all(norm(f, PREDICTED[k][f]) == norm(f, GOLD[k][f]) for f in GOLD[k]) for k in GOLD)
    print(f"documents fully correct: {exact}/{len(GOLD)}")
