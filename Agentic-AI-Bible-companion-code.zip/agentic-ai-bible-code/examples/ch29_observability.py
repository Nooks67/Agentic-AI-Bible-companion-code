"""Chapter 29: structured logs, a trace per run, and the questions you answer from traces.

Three order-desk runs with scripted decisions write one JSON event per line; the analysis below reads only that file.
"""
import json
import logging
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m03_orderdesk"))
from orderdesk import CarrierAPI, OrderDB, make_agent  # noqa: E402

from agentlab import AllowList, ScriptedModel, call  # noqa: E402
from agentlab.trace import load, summarize  # noqa: E402


class JsonFormatter(logging.Formatter):
    def format(self, r: logging.LogRecord) -> str:
        return json.dumps({"ts": round(r.created, 3), "level": r.levelname, "logger": r.name, "msg": r.getMessage(),
                           **getattr(r, "ctx", {})})


log = logging.getLogger("orderdesk")
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter())
log.addHandler(handler)
log.setLevel(logging.INFO)

RUNS = {
    "ok-status": ("lee@example.com", CarrierAPI(), [[call("lookup_order", order_id="BL-10301")],
                  [call("track_shipment", order_id="BL-10301")], "Your order is held at the regional hub."]),
    "carrier-down": ("lee@example.com", CarrierAPI(failure_rate=1.0), [[call("track_shipment", order_id="BL-10301")],
                     [call("escalate", reason="carrier API down")], "A colleague will follow up."]),
    "looping": ("lee@example.com", CarrierAPI(), [[call("lookup_order", order_id="BL-10455")]] * 5 + ["Still processing."]),
}


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, round(p / 100 * (len(xs) - 1)))] if xs else 0


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmp:
        trace = Path(tmp) / "trace.jsonl"
        for run_id, (sender, carrier, script) in RUNS.items():
            agent = make_agent(sender, ScriptedModel(script), AllowList({"escalate": lambda a: True}),
                               Path(tmp) / run_id, carrier, OrderDB())
            agent.tracer.path, agent.tracer.run_id = trace, run_id
            res = agent.run("customer message", run_id=run_id)
            log.info("run finished", extra={"ctx": {"run_id": run_id, "status": res.status, "steps": res.steps}})
        events = load(trace)

    print("\nsummary:", json.dumps(summarize(events)))
    print("\ntimeline of carrier-down:")
    t0 = next(e["ts"] for e in events if e["run_id"] == "carrier-down")
    for e in (e for e in events if e["run_id"] == "carrier-down"):
        calls = e.get("tool_calls") if e["kind"] == "model_reply" else []
        what = e.get("tool") or ",".join(calls) or e.get("status", "")
        extra = f" error={e['error']}" if e.get("error") else ""
        print(f"  +{(e['ts'] - t0) * 1000:6.0f} ms  {e['kind']:<12} {what}{extra}")

    print("\nfailed tool calls:", [(e["run_id"], e["tool"], e.get("error") or "repeated call")
                                   for e in events if e["kind"] == "tool_result" and not e["ok"]])
    by_run = defaultdict(list)
    for e in events:
        by_run[e["run_id"]].append(e)
    for run_id, evs in by_run.items():
        repeats = sum(1 for e in evs if e.get("repeated"))
        gap = max((b["ts"] - a["ts"] for a, b in zip(evs, evs[1:])), default=0)
        print(f"{run_id:<13} repeats={repeats}  longest gap={gap * 1000:.0f} ms  status={evs[-1].get('status')}")
    tool_ms = [e["ms"] for e in events if e["kind"] == "tool_result" and "ms" in e]
    tokens = [e["input_tokens"] + e["output_tokens"] for e in events if e["kind"] == "model_reply"]
    print(f"tool latency p50={pct(tool_ms, 50)} ms p95={pct(tool_ms, 95)} ms; tokens per run={sum(tokens) / len(by_run):.0f}")
