"""Chapter 37: an approval-based purchase-request process. The model extracts the request; code routes it by amount
and budget; people approve at the level the policy requires; nothing is ordered without the recorded approvals."""
from agentlab.workflow import END, Graph

BUDGETS = {"warehouse": 2500.0, "marketing": 800.0}
APPROVERS = {"manager": "dana.lee", "finance": "omar.ruiz"}


def extract(s):        # in production: ask_structured(model, [...request text...], PurchaseRequest)
    return {**s, "item": s["text"].split(" for ")[0], "amount": s["amount"], "team": s["team"]}


def check(s):
    issues = []
    if s["amount"] > BUDGETS.get(s["team"], 0):
        issues.append(f"exceeds remaining {s['team']} budget of {BUDGETS.get(s['team'], 0):.2f}")
    return {**s, "issues": issues}


def route(s) -> str:
    if s["issues"]:
        return "reject"
    return "auto_approve" if s["amount"] < 100 else "manager" if s["amount"] <= 1000 else "manager_then_finance"


def approve_as(*roles):
    def step(s):
        decisions = [(r, APPROVERS[r], s["decide"](r, s)) for r in roles]
        return {**s, "approvals": s.get("approvals", []) + decisions}
    return step


def place_order(s):
    if not all(ok for _, _, ok in s.get("approvals", [])):
        return {**s, "outcome": "declined by " + ", ".join(who for _, who, ok in s["approvals"] if not ok)}
    BUDGETS[s["team"]] -= s["amount"]
    return {**s, "outcome": f"ordered; {s['team']} budget left {BUDGETS[s['team']]:.2f}"}


g = (Graph(max_transitions=10).step("extract", extract, start=True).step("check", check)
     .step("auto_approve", lambda s: {**s, "approvals": [("policy", "auto", True)]})
     .step("manager", approve_as("manager")).step("manager_then_finance", approve_as("manager", "finance"))
     .step("reject", lambda s: {**s, "outcome": "rejected: " + "; ".join(s["issues"])}).step("place_order", place_order))
g.edge("extract", "check").edge("check", route)
for s in ("auto_approve", "manager", "manager_then_finance"):
    g.edge(s, "place_order")
g.edge("reject", END).edge("place_order", END)

if __name__ == "__main__":
    finance_says_no_above_1500 = lambda role, s: not (role == "finance" and s["amount"] > 1500)
    for text, amount, team in [("Packing tape for warehouse", 64.0, "warehouse"),
                               ("Label printer for warehouse", 420.0, "warehouse"),
                               ("Pallet jack for warehouse", 1850.0, "warehouse"),
                               ("Trade show booth for marketing", 1200.0, "marketing")]:
        out = g.run({"text": text, "amount": amount, "team": team, "decide": finance_says_no_above_1500})
        path = " > ".join(out["_history"])
        print(f"{text[:30]:<31} {amount:>8.2f}  {path:<54} {out['outcome']}")
