"""Chapter 4: versioned prompt templates and a consistency measurement.

The 'model' below is a simulation: it picks a label at random with fixed probabilities,
standing in for a real model's run-to-run variation. With a real model, replace
`simulated_model` with a function that calls model_from_env() and parses the label.
"""
import random
import string
from collections import Counter
from dataclasses import dataclass


@dataclass(frozen=True)
class PromptTemplate:
    name: str
    version: str
    text: str

    def variables(self) -> set[str]:
        return {f for _, f, _, _ in string.Formatter().parse(self.text) if f}

    def render(self, **values: str) -> str:
        missing = self.variables() - values.keys()
        extra = values.keys() - self.variables()
        if missing or extra:
            raise ValueError(f"{self.name}@{self.version}: missing {sorted(missing)}, unexpected {sorted(extra)}")
        return self.text.format(**values)


CLASSIFY = PromptTemplate("classify-email", "v2", """Classify the customer email into exactly one category:
billing, defect, shipping, returns, pre_sales, spam, other.
Reply with the category name only.

Email:
<<<
{email}
>>>""")


def consistency(labels: list[str]) -> float:
    """Share of runs that agree with the most common answer."""
    return Counter(labels).most_common(1)[0][1] / len(labels)


def simulated_model(prompt: str, rng: random.Random, clear: bool) -> str:
    # A clear email gets the same label 95% of the time; an ambiguous one only 60%.
    p = 0.95 if clear else 0.60
    return "shipping" if rng.random() < p else rng.choice(["returns", "other"])


if __name__ == "__main__":
    rng = random.Random(7)
    prompt = CLASSIFY.render(email="Where is my order BL-10301? It was due Monday.")
    print(f"template {CLASSIFY.name}@{CLASSIFY.version}, variables={sorted(CLASSIFY.variables())}")
    for clear in (True, False):
        labels = [simulated_model(prompt, rng, clear) for _ in range(20)]
        print(f"{'clear' if clear else 'ambiguous':>9} email: consistency={consistency(labels):.2f} "
              f"counts={dict(Counter(labels))}")
    try:
        CLASSIFY.render(mail="typo in the variable name")
    except ValueError as e:
        print("render error:", e)
