"""Chapter 25: an observe-act browser loop. The model sees a compact snapshot of the page and proposes
one action at a time as JSON; code validates every action before Playwright performs it.

The model is scripted, so the run is reproducible; the browser and the web page are real.
"""
import json
import sys
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m08_docs_browser"))
from ap_portal import Portal  # noqa: E402

SNAPSHOT_JS = """() => [...document.querySelectorAll('input:not([type=hidden]), select, button')].map(el => ({
  role: el.tagName === 'BUTTON' ? 'button' : el.tagName === 'SELECT' ? 'combobox' : 'textbox',
  name: el.tagName === 'BUTTON' ? el.innerText : (document.querySelector(`label[for="${el.id}"]`) || {}).innerText,
  value: el.value || '' }))"""

ALLOWED_HOSTS = {"127.0.0.1"}
NEEDS_APPROVAL = {"Submit for payment"}


def snapshot(page) -> dict:
    return {"url": page.url, "title": page.title(), "elements": page.evaluate(SNAPSHOT_JS)}


def validate(action: dict, snap: dict) -> str | None:
    """Return a reason to refuse, or None if the action may run."""
    kind = action.get("action")
    if kind == "navigate":
        return None if urlparse(action.get("url", "")).hostname in ALLOWED_HOSTS else "host not on the allowlist"
    names = {e["name"] for e in snap["elements"]}
    if kind not in ("fill", "select", "click"):
        return f"unknown action {kind!r}"
    if action.get("target") not in names:
        return f"no element named {action.get('target')!r} on this page"
    if kind == "click" and action["target"] in NEEDS_APPROVAL:
        return "needs human approval"
    return None


def perform(page, action: dict) -> None:
    if action["action"] == "navigate":
        page.goto(action["url"])
    elif action["action"] == "click":
        page.get_by_role("button", name=action["target"]).click()
    else:
        field = page.get_by_label(action["target"], exact=True)
        field.select_option(action["value"]) if action["action"] == "select" else field.fill(action["value"])


PROPOSED = [   # what a model might propose, step by step, after reading each snapshot
    {"action": "select", "target": "Vendor", "value": "V-102"},
    {"action": "fill", "target": "Invoice number", "value": "ST-2291"},
    {"action": "fill", "target": "Amount (USD)", "value": "2265.00"},
    {"action": "fill", "target": "Due date", "value": "2026-10-03"},
    {"action": "fill", "target": "Invoice date", "value": "2026-10-03"},
    {"action": "navigate", "url": "https://pay-faster.example/upload"},
    {"action": "click", "target": "Submit for payment"},
]

if __name__ == "__main__":
    portal = Portal()
    srv = portal.serve()
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(f"http://127.0.0.1:{srv.server_port}/")
        snap = snapshot(page)
        print("snapshot:", json.dumps(snap["elements"][:2]), f"... {len(snap['elements'])} elements")
        for action in PROPOSED:
            reason = validate(action, snapshot(page))
            label = action.get("target") or action.get("url")
            if reason:
                print(f"REFUSED  {action['action']:<8} {label:<34} {reason}")
                continue
            perform(page, action)
            print(f"done     {action['action']:<8} {label}")
        print("form values:", {e["name"]: e["value"] for e in snapshot(page)["elements"] if e["role"] != "button"})
        print("requests submitted:", portal.requests)
        browser.close()
    srv.shutdown()
