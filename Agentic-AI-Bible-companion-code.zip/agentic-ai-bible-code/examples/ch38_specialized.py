"""Chapter 38: a claims ledger for research briefs, and a domain gate for regulated topics."""
import re
from datetime import date

SOURCES = {
    "S1": {"title": "Outdoor retail market survey", "published": date(2026, 6, 2)},
    "S2": {"title": "Competitor price list (web page)", "published": date(2026, 10, 12)},
    "S3": {"title": "Industry blog post", "published": date(2025, 3, 30)},
}
BRIEF = """Ultralight tents grew faster than any other category in the first half of 2026 [S1].
Our main competitor now sells its two-person tent at 279 USD [S2].
Most buyers choose tents mainly on weight [S3].
Demand will double next year."""


def audit_claims(brief: str, sources: dict, today: date, max_age_days: int = 365) -> list[str]:
    findings = []
    for n, sentence in enumerate(s for s in brief.splitlines() if s.strip()):
        cites = re.findall(r"\[(S\d+)\]", sentence)
        if not cites:
            findings.append(f"claim {n + 1}: no source -> remove or mark as opinion")
        for c in cites:
            src = sources.get(c)
            if src is None:
                findings.append(f"claim {n + 1}: unknown source {c}")
            elif (today - src["published"]).days > max_age_days:
                findings.append(f"claim {n + 1}: source {c} is {(today - src['published']).days} days old")
    return findings


REGULATED = {   # topic -> (pattern, handling)
    "health": (r"\b(dose|dosage|symptom|diagnos\w*|medication|allerg\w*|injur\w*)\b",
               "general information only; recommend a clinician; no individual advice"),
    "finance": (r"\b(invest\w*|loan|credit score|tax|pension|stock)\b",
                "general information only; no personal recommendation; offer a qualified adviser"),
    "legal": (r"\b(sue|lawsuit|contract dispute|liabilit\w*)\b", "do not advise; escalate to the legal team"),
}


def domain_gate(question: str) -> tuple[str, str]:
    for topic, (pattern, handling) in REGULATED.items():
        if re.search(pattern, question.lower()):
            return topic, handling
    return "general", "normal agent handling"


if __name__ == "__main__":
    for f in audit_claims(BRIEF, SOURCES, date(2026, 10, 22)):
        print(f)
    print()
    for q in ["Which tent is lightest?", "What dosage of ibuprofen should I pack for altitude headaches?",
              "Should I invest in outdoor retail stocks?", "Can I sue the carrier for a lost parcel?"]:
        topic, handling = domain_gate(q)
        print(f"{q[:56]:<58} {topic:<8} {handling}")
