"""Chapter 21: a coordinator plans, specialised workers execute, the blackboard holds results.

The plan is scripted (a planner model would produce it); workers are plain functions here.
"""
import json

from agentlab import ScriptedModel
from agentlab.multi import Coordinator

PLAN = {"tasks": [
    {"id": "order", "worker": "order_specialist", "instruction": "status and items of BL-10301"},
    {"id": "policy", "worker": "policy_specialist", "instruction": "policy for parcels held at a hub"},
    {"id": "reply", "worker": "writer", "instruction": "draft a reply to the customer", "depends_on": ["order", "policy"]},
]}


def order_specialist(instruction, inputs):
    return json.dumps({"order": "BL-10301", "status": "held at regional hub", "reason": "address could not be verified"})


def policy_specialist(instruction, inputs):
    return "If tracking has not updated for 5 business days, open an investigation with the carrier [shipping#3]."


def writer(instruction, inputs):
    facts = json.loads(inputs["order"])
    return (f"Your order {facts['order']} is {facts['status']} because the {facts['reason']}. "
            "Please reply with your full address so the carrier can deliver it.")


coord = Coordinator(ScriptedModel([json.dumps(PLAN)]),
                    {"order_specialist": order_specialist, "policy_specialist": policy_specialist, "writer": writer})
plan = coord.plan("Customer asks why BL-10301 has not arrived.")
board = coord.execute(plan)
for tid, rec in board.records.items():
    print(f"{tid:<7} {rec.task.worker:<18} {rec.status:<5} {rec.output[:70]}")
print("\nlog:", board.log)
