"""Chapter 12: calling a REST API from an agent tool - authentication, errors, rate limits, retries.

Starts the Module IV demo inventory API on a free local port, then exercises the client.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m04_mcp"))
from inventory_api import serve
from inventory_client import APIError, InventoryClient

srv = serve(0, api_keys={"key-ops"}, limit=3)              # 3 requests per minute per key, to show a 429
url = f"http://127.0.0.1:{srv.server_port}"
waits = []
client = InventoryClient(url, "key-ops", attempts=2, sleep=waits.append)   # record waits instead of sleeping

print("search 'tent':", [p["sku"] for p in client.search("tent")])
print("stock TN-SOLO1:", client.stock("TN-SOLO1"))
for label, fn in [("reserve 2 x PK-SUMMIT45", lambda: client.reserve("PK-SUMMIT45", 2)),
                  ("stock with a bad key", lambda: InventoryClient(url, "stolen-key").stock("TN-SOLO1")),
                  ("4th request this minute", lambda: client.stock("HL-BEAM"))]:
    try:
        print(label, "->", fn())
    except APIError as e:
        print(f"{label} -> APIError status={e.status}: {e}")
print("client waited (seconds, from Retry-After):", [round(w) for w in waits])
srv.shutdown()
