"""Chapter 11: what a tool looks like to the model, and what the registry does with every call."""
import json
import time

from agentlab import AllowList, ToolRegistry, tool


@tool
def search_products(query: str, max_results: int = 5, in_stock_only: bool = False) -> list[dict]:
    """Search Brightline's catalogue by name or category.

    Args:
        query: Words to search for, e.g. "tent" or "rain jacket".
        max_results: How many products to return (1-10).
        in_stock_only: Only return products with stock above zero.
    """
    return [{"sku": "TN-ALPINE2", "name": "Alpine 2P Tent", "price": 289.0}][:max_results]


@tool(timeout=0.5)
def slow_supplier_eta(sku: str) -> str:
    """Ask the supplier for a restock date (their API is slow)."""
    time.sleep(2)
    return "2026-11-02"


@tool(risk="external")
def email_customer(to: str, subject: str, body: str) -> str:
    """Send an email to a customer."""
    return "queued"


print(json.dumps(search_products.spec(), indent=1))

reg = ToolRegistry(approver=AllowList({"email_customer": lambda a: a["to"] == "lee@example.com"}))
reg.add(search_products, slow_supplier_eta, email_customer)
cases = [
    ("search_products", {"query": "tent", "max_results": 1}),
    ("search_products", {"query": "tent", "max_results": "three"}),
    ("search_products", {"q": "tent"}),
    ("find_products", {"query": "tent"}),
    ("slow_supplier_eta", {"sku": "PK-SUMMIT45"}),
    ("email_customer", {"to": "someone@else.example", "subject": "Hi", "body": "..."}),
    ("email_customer", {"to": "lee@example.com", "subject": "Your order", "body": "..."}),
]
for name, args in cases:
    r = reg.call(name, args)
    print(f"{name}({json.dumps(args)[:44]}) -> {'OK ' + r.content[:40] if r.ok else r.error[:96]}")
