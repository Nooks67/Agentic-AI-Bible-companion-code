"""Chapter 32: API keys stored as hashes with scopes, secrets from the environment, field encryption, tamper-evident audit."""
import hashlib
import hmac
import json
import os
import secrets
import tempfile
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

from agentlab.security import AuditLog

# ---------------------------------------------------------------- authentication and scopes
KEYS: dict[str, dict] = {}          # key id -> {"hash": ..., "scopes": [...]}; the raw key is never stored


def issue_key(owner: str, scopes: list[str]) -> str:
    key_id, secret = secrets.token_hex(4), secrets.token_urlsafe(24)
    KEYS[key_id] = {"owner": owner, "hash": hashlib.sha256(secret.encode()).hexdigest(), "scopes": scopes}
    return f"ak_{key_id}_{secret}"          # shown once to the client


def authorize(presented: str, needed: str) -> str:
    try:
        _, key_id, secret = presented.split("_", 2)
        rec = KEYS[key_id]
    except (ValueError, KeyError):
        return "401 unknown key"
    if not hmac.compare_digest(rec["hash"], hashlib.sha256(secret.encode()).hexdigest()):
        return "401 bad key"
    return "200 ok" if needed in rec["scopes"] else f"403 key lacks scope {needed}"


# ---------------------------------------------------------------- secrets from the environment
def require_env(name: str) -> str:
    value = os.environ.get(name, "")
    if len(value) < 20:
        raise RuntimeError(f"{name} is missing or too short; set it in the deployment's secret store")
    return value


if __name__ == "__main__":
    support = issue_key("support-portal", ["agent:run"])
    print("support key, run agent:  ", authorize(support, "agent:run"))
    print("support key, read audit: ", authorize(support, "audit:read"))
    print("tampered key:            ", authorize(support[:-2] + "xx", "agent:run"))
    print("stored record:           ", json.dumps(next(iter(KEYS.values())))[:90], "...")

    try:
        require_env("AGENTLAB_DATA_KEY")
    except RuntimeError as e:
        print("\nstartup check:", e)
    os.environ["AGENTLAB_DATA_KEY"] = Fernet.generate_key().decode()   # in production: from a secret manager
    box = Fernet(require_env("AGENTLAB_DATA_KEY").encode())
    token = box.encrypt(b"Lee Park, 14 Alder St, Portland")
    print("encrypted address:", token[:32].decode(), "...")
    print("decrypted:", box.decrypt(token).decode())
    try:
        Fernet(Fernet.generate_key()).decrypt(token)
    except InvalidToken:
        print("wrong key: InvalidToken (data unreadable without the key)")

    with tempfile.TemporaryDirectory() as tmp:
        audit = AuditLog(Path(tmp) / "audit.jsonl")
        audit.record("agent", "executed", tool="issue_refund", amount=40)
        audit.record("ana.ops", "approval", tool="issue_refund", approved=True)
        audit.record("agent", "executed", tool="send_email", to="lee@example.com")
        print("\naudit chain intact:", audit.verify())
        lines = audit.path.read_text().splitlines()
        lines[0] = lines[0].replace('"amount": 40', '"amount": 4')          # someone edits history
        audit.path.write_text("\n".join(lines) + "\n")
        print("after editing line 1:", audit.verify())
