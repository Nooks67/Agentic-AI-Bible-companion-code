"""Chapter 34: validated configuration per environment, a smoke test against a real HTTP server, and canary assignment."""
import hashlib
import json
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Literal

import uvicorn
from pydantic import BaseModel, Field, ValidationError, model_validator

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "projects" / "m11_deploy"))
from deploy_server import create_app  # noqa: E402

from agentlab import Usage  # noqa: E402
from agentlab.agent import RunResult  # noqa: E402


class Settings(BaseModel):
    env: Literal["dev", "staging", "prod"]
    model: str
    max_cost_per_run: float = Field(gt=0, le=1.0)
    workers: int = Field(ge=1, le=32)
    api_keys: dict[str, dict]

    @model_validator(mode="after")
    def production_rules(self):
        if self.env == "prod":
            if self.model.endswith("latest") or not any(c.isdigit() for c in self.model):
                raise ValueError("production must pin a dated or versioned model, not an alias")
            if any(len(k) < 24 for k in self.api_keys):
                raise ValueError("production API keys must be at least 24 characters")
        return self


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def http(method: str, url: str, body: dict | None = None, key: str = "") -> tuple[int, str]:
    req = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body else None,
                                 headers={"authorization": f"Bearer {key}", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def smoke_test(base: str, key: str) -> list[str]:
    """Run after every deployment, before traffic is shifted."""
    checks = []
    checks.append(f"healthz {http('GET', base + '/healthz')[0]}")
    checks.append(f"readyz {http('GET', base + '/readyz')[0]}")
    code, body = http("POST", base + "/v1/runs", {"message": "smoke test", "customer_email": "smoke@example.com"}, key)
    rid = json.loads(body)["run_id"]
    for _ in range(50):
        status = json.loads(http("GET", f"{base}/v1/runs/{rid}", key=key)[1])["status"]
        if status in ("done", "failed"):
            break
        time.sleep(0.05)
    checks.append(f"run {code} -> {status}")
    checks.append("metrics " + ("ok" if "agent_runs_total" in http("GET", base + "/metrics")[1] else "missing"))
    return checks


def canary(customer: str, percent: int, salt: str = "release-2026-10") -> str:
    bucket = int(hashlib.sha256((salt + customer).encode()).hexdigest(), 16) % 100
    return "v2" if bucket < percent else "v1"


if __name__ == "__main__":
    for env, model, keys in [("dev", "any-model-latest", {"dev": {}}), ("prod", "any-model-latest", {"k" * 30: {}}),
                             ("prod", "provider-model-2026-08-15", {"short": {}}),
                             ("prod", "provider-model-2026-08-15", {"k" * 30: {"budget_usd": 25}})]:
        try:
            Settings(env=env, model=model, max_cost_per_run=0.05, workers=2, api_keys=keys)
            print(f"{env:<5} {model:<26} keys={len(next(iter(keys)))} chars -> valid")
        except ValidationError as e:
            print(f"{env:<5} {model:<26} keys={len(next(iter(keys)))} chars -> {e.errors()[0]['msg']}")

    def factory(payload):
        return lambda msg: (time.sleep(0.05), RunResult("done", "ok", 1, 0, Usage(50, 10), 0.001))[1]
    port, key = free_port(), "smoke-key-0123456789abcdef"
    tmp = Path(__file__).parent / ".smoke-jobs.db"
    tmp.unlink(missing_ok=True)
    server = uvicorn.Server(uvicorn.Config(create_app(factory, {key: {"budget_usd": 1}}, str(tmp)),
                                           port=port, log_level="warning"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    while not server.started:
        time.sleep(0.05)
    print("\nsmoke test:", smoke_test(f"http://127.0.0.1:{port}", key))
    server.should_exit = True
    t.join(timeout=10)
    tmp.unlink(missing_ok=True)

    customers = [f"customer{i}@example.com" for i in range(1000)]
    share = sum(canary(c, 10) == "v2" for c in customers) / len(customers)
    print(f"\ncanary share at 10%: {share:.3f}; same customer, same version: {canary(customers[7], 10) == canary(customers[7], 10)}")
