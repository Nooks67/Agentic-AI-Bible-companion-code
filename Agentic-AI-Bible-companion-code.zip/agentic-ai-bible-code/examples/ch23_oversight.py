"""Chapter 23: humans in the loop - approval queue, escalation rules and a decision record for each action."""
import json

from agentlab import Agent, ScriptedModel, ToolRegistry, call, tool
from agentlab.approvals import ApprovalQueue, QueueApprover

queue = ApprovalQueue(ttl_seconds=8 * 3600)


@tool(risk="write")
def issue_store_credit(order_id: str, amount: float, reason: str) -> dict:
    """Give the customer store credit for a problem with an order.

    Args:
        order_id: Order number.
        amount: Credit in USD.
        reason: Short reason shown to the approver.
    """
    return {"credit_id": "SC-2210", "order_id": order_id, "amount": amount}


def escalation_rule(text: str) -> str | None:
    """Deterministic triggers that send a conversation straight to a person."""
    low = text.lower()
    for trigger, why in [("lawyer", "legal threat"), ("chargeback", "payment dispute"),
                         ("injured", "possible safety issue"), ("speak to a human", "customer request")]:
        if trigger in low:
            return why
    return None


for message in ["My tent arrived torn, I'd like some credit for BL-10388.",
                "I was injured by the stove you sold me."]:
    why = escalation_rule(message)
    if why:
        print(f"ESCALATED before any model call ({why}): {message}")
        continue
    reg = ToolRegistry(approver=QueueApprover(queue, reason=lambda t, a: a.get("reason", ""))).add(issue_store_credit)
    step = [call("issue_store_credit", order_id="BL-10388", amount=25.0, reason="tent arrived torn")]
    Agent(ScriptedModel([step, "I've asked a colleague to approve a credit of 25 USD."]), reg).run(message)

for req in queue.pending():
    print("\nAPPROVAL CARD")
    print(json.dumps({"id": req.id, "action": req.tool, "arguments": req.arguments, "reason": req.reason,
                      "expires_in_hours": round((req.expires_at - req.requested_at) / 3600)}, indent=1))
    decided = queue.decide(req.id, approved=True, by="ana.ops", note="photos show tear along seam")
    print(f"decision: {decided.status} by {decided.decided_by} ({decided.note})")
