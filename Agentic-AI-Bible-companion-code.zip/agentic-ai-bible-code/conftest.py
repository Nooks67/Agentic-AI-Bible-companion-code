# Each project folder is importable by its own module names during tests.
import sys
from pathlib import Path

def pytest_collect_file(parent, file_path):
    proj = file_path.parent.parent
    if file_path.name.startswith("test_") and proj.parent.name == "projects" and str(proj) not in sys.path:
        sys.path.insert(0, str(proj))
