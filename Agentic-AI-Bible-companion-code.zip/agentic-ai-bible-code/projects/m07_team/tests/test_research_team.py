import json

from agentlab import ScriptedModel
from research_team import analyst, review_report, run_team

PLAN = json.dumps({"tasks": [
    {"id": "stats", "worker": "analyst", "instruction": "statistics for TN-ALPINE2 and JK-STORM"},
    {"id": "policy", "worker": "researcher", "instruction": "warranty coverage for broken zippers"},
    {"id": "draft", "worker": "writer", "instruction": "write the quality report", "depends_on": ["stats", "policy"]}]})

GOOD = """# Quality report: tents and jackets
The Alpine 2P Tent averages 3.17 stars over 6 reviews; 0.5 of reviews are 3 stars or lower, and the top complaint term is "zipper".
The Storm Shell Jacket averages 3.8 stars over 5 reviews.
Broken zippers are covered by the two-year warranty [warranty#1].

Actions:
1. Ask the supplier about the tent door zipper.
2. Review jacket seam taping."""

BAD = GOOD.replace("3.17", "4.6").replace("[warranty#1]", "[warranty#9]")


def test_analyst_statistics_are_deterministic():
    s = json.loads(analyst("TN-ALPINE2 and JK-STORM", {}))
    assert s["TN-ALPINE2"] == {"reviews": 6, "avg_rating": 3.17, "share_low": 0.5, "top_complaint_terms": ["zipper", "door", "night"]}
    assert s["JK-STORM"]["avg_rating"] == 3.8 and set(s) == {"TN-ALPINE2", "JK-STORM"}


def test_reviewer_catches_invented_numbers_and_citations():
    stats = analyst("TN-ALPINE2 JK-STORM", {})
    issues = review_report(BAD, stats, {"warranty#1"})
    assert "number 4.6 does not come from the analyst's statistics" in issues
    assert "citation [warranty#9] is not one of the researcher's sources" in issues
    assert review_report(GOOD, stats, {"warranty#1", "warranty#2"}) == []


def test_full_run_with_revision_and_approval(tmp_path):
    model = ScriptedModel([PLAN, BAD, GOOD])          # plan, first draft (bad), revised draft (good)
    seen = []
    res = run_team("Quality report: tents and jackets", model, lambda r: seen.append(r) or True, tmp_path)
    assert res.published and res.path.read_text() == GOOD and seen == [GOOD]
    assert "Fix these problems" in model.calls[2][-1].content
    assert {k: r.status for k, r in res.board.records.items()} == {"stats": "done", "policy": "done", "draft": "done"}


def test_human_can_refuse_publication(tmp_path):
    res = run_team("Quality report", ScriptedModel([PLAN, GOOD]), lambda r: False, tmp_path)
    assert not res.published and list(tmp_path.iterdir()) == []


def test_unfixable_draft_is_not_published(tmp_path):
    res = run_team("Quality report", ScriptedModel([PLAN, BAD, BAD]), lambda r: True, tmp_path)
    assert not res.published and res.issues
