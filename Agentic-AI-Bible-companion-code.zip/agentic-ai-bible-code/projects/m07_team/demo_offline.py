"""Offline demonstration: the team plans, works, drafts a report with a bad number, revises it, and asks a person.

Planner and writer replies are scripted; retrieval, statistics, review checks and approval are real.
"""
import json
import tempfile
from pathlib import Path

from agentlab import ScriptedModel
from research_team import run_team

PLAN = json.dumps({"tasks": [
    {"id": "stats", "worker": "analyst", "instruction": "statistics for TN-ALPINE2 and JK-STORM"},
    {"id": "policy", "worker": "researcher", "instruction": "warranty coverage for broken zippers"},
    {"id": "draft", "worker": "writer", "instruction": "write the quality report", "depends_on": ["stats", "policy"]}]})
GOOD = """# Quality report: tents and jackets
The Alpine 2P Tent averages 3.17 stars over 6 reviews; 0.5 of reviews are 3 stars or lower, and the top complaint term is "zipper".
The Storm Shell Jacket averages 3.8 stars over 5 reviews.
Broken zippers are covered by the two-year warranty [warranty#1].

Actions:
1. Ask the supplier about the tent door zipper.
2. Review jacket seam taping."""
FIRST = GOOD.replace("3.17", "4.6")

res = run_team("Quality report: tents and jackets", ScriptedModel([PLAN, FIRST, GOOD]),
               approve=lambda report: True, out_dir=Path(tempfile.mkdtemp()))
for tid, rec in res.board.records.items():
    print(f"{tid:<7} {rec.task.worker:<11} {rec.status:<5} {rec.output[:66].replace(chr(10), " / ")}")
print("\nreviewer issues on first draft:", res.first_issues)
print("reviewer issues on revised draft:", res.issues or "none")
print("published:", res.published, "->", res.path.name if res.path else None)
