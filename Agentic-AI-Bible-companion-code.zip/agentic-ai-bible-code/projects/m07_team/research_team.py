"""Module VII project: a supervised multi-agent research-and-reporting workflow.

Workers:  researcher (retrieval over policy docs), analyst (statistics from review data, no model),
          writer (model drafts the report), reviewer (deterministic checks; can send the draft back once).
A human approves before the report is published.

Usage:  python research_team.py "Quality report: tents and jackets"
"""
from __future__ import annotations

import csv
import json
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "m06_rag"))
from agentlab import ChatModel, Message, model_from_env  # noqa: E402
from agentlab.multi import Blackboard, Coordinator  # noqa: E402
from agentlab.rag import tokenize  # noqa: E402
from policy_assistant import build_index  # noqa: E402  (reuses the Module VI retriever)

HERE = Path(__file__).parent
STOPWORDS = {"the", "a", "and", "on", "of", "for", "in", "is", "but", "after", "it", "my", "to", "was", "very", "bit",
             "me", "inside", "over", "full", "through", "week", "two", "three", "within", "all", "few"}


def load_reviews() -> list[dict]:
    with (HERE / "data" / "reviews.csv").open() as f:
        return [{**r, "rating": int(r["rating"])} for r in csv.DictReader(f)]


# ------------------------------------------------------------------ workers
def analyst(instruction: str, inputs: dict[str, str]) -> str:
    """Deterministic statistics: no model, so every number in the report has a checkable origin."""
    by_sku: dict[str, list[dict]] = defaultdict(list)
    for r in load_reviews():
        by_sku[r["sku"]].append(r)
    wanted = [s for s in by_sku if s.lower() in instruction.lower()] or list(by_sku)
    out = {}
    for sku in wanted:
        rs = by_sku[sku]
        low = [r["text"] for r in rs if r["rating"] <= 3]
        words = Counter(w for t in low for w in set(tokenize(t)) if w not in STOPWORDS)
        out[sku] = {"reviews": len(rs), "avg_rating": round(mean(r["rating"] for r in rs), 2),
                    "share_low": round(len(low) / len(rs), 2), "top_complaint_terms": [w for w, n in words.most_common(3) if n > 1]}
    return json.dumps(out)


def make_researcher(index):
    def researcher(instruction: str, inputs: dict[str, str]) -> str:
        hits = index.retriever.search(instruction, k=3)
        return json.dumps([{"id": c.id, "text": c.text} for c, _ in hits])
    return researcher


WRITER = """Write a short internal quality report in Markdown for Brightline's product team.
Use only the statistics and policy sources provided. Cite policy sources like [warranty#1].
Copy numbers exactly as given. End with 2-3 recommended actions. Maximum 250 words."""


def make_writer(model: ChatModel):
    def writer(instruction: str, inputs: dict[str, str]) -> str:
        material = "\n\n".join(f"## Input from task '{k}'\n{v}" for k, v in inputs.items())
        return model.complete([Message("system", WRITER), Message("user", f"Task: {instruction}\n\n{material}")]).message.content
    return writer


NUM = re.compile(r"(?<![\w-])\d+(?:\.\d+)?(?![\w-])")


def review_report(draft: str, stats_json: str, source_ids: set[str]) -> list[str]:
    """Reviewer checks: every number appears in the analyst's output, every citation exists, length is sane."""
    issues = []
    allowed = set(NUM.findall(stats_json)) | {str(int(float(x) * 100)) for x in re.findall(r"0\.\d+", stats_json)}
    for n in set(NUM.findall(draft)) - allowed - {"1", "2", "3"}:     # list numbering is fine
        issues.append(f"number {n} does not come from the analyst's statistics")
    for cid in re.findall(r"\[([\w.-]+#\d+)\]", draft):
        if cid not in source_ids:
            issues.append(f"citation [{cid}] is not one of the researcher's sources")
    if len(draft.split()) > 300:
        issues.append("report is longer than 300 words")
    return issues


# ------------------------------------------------------------------ the supervised run
@dataclass
class TeamResult:
    report: str
    issues: list[str]
    published: bool
    board: Blackboard
    path: Path | None
    first_issues: list[str] = field(default_factory=list)


def run_team(goal: str, model: ChatModel, approve, out_dir: Path = HERE / "reports") -> TeamResult:
    index = build_index()
    workers = {"researcher": make_researcher(index), "analyst": analyst, "writer": make_writer(model)}
    coord = Coordinator(model, workers, max_tasks=6)
    board = coord.execute(coord.plan(goal))
    drafts = [r for r in board.records.values() if r.task.worker == "writer" and r.status == "done"]
    if not drafts:
        return TeamResult("", ["no draft produced: " + "; ".join(f"{k}={r.status}" for k, r in board.records.items())],
                          False, board, None)
    draft = drafts[-1]
    stats = " ".join(r.output for r in board.records.values() if r.task.worker == "analyst")
    sources = {s["id"] for r in board.records.values() if r.task.worker == "researcher" and r.status == "done"
               for s in json.loads(r.output)}
    issues = first_issues = review_report(draft.output, stats, sources)
    report = draft.output
    if issues:   # handoff back to the writer once, with the reviewer's notes
        inputs = {d: board.records[d].output for d in draft.task.depends_on}
        inputs["reviewer"] = "Fix these problems: " + "; ".join(issues)
        report = workers["writer"](draft.task.instruction, inputs)
        issues = review_report(report, stats, sources)
    published, path = False, None
    if not issues and approve(report):                    # human oversight before anything leaves the team
        out_dir.mkdir(exist_ok=True)
        path = out_dir / (re.sub(r"[^a-z0-9]+", "-", goal.lower()).strip("-")[:60] + ".md")
        path.write_text(report)
        published = True
    return TeamResult(report, issues, published, board, path, first_issues)


def console_approve(report: str) -> bool:
    print("\n" + report + "\n")
    return input("Publish this report? [y/N] ").strip().lower() == "y"


if __name__ == "__main__":
    res = run_team(" ".join(sys.argv[1:]), model_from_env(), console_approve)
    print("published:" if res.published else "not published.", res.path or "; ".join(res.issues))
