"""Module III project: an order-desk agent with persistent state, approvals and failure recovery.

Usage:
  python orderdesk.py --from lee@example.com "Where is my order BL-10301?"
  python orderdesk.py --resume <run-id>          # continue a run after a crash
"""
from __future__ import annotations

import argparse
import json
import random
import sqlite3
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from agentlab import (Agent, AgentConfig, CheckpointStore, IdempotencyLedger, ToolRegistry, Tracer,  # noqa: E402
                      model_from_env, tool)
from agentlab.resilience import RetryableError, retry  # noqa: E402

DATA = Path(__file__).parent / "data"
RETURN_WINDOW_DAYS = 30

SYSTEM = """You are the Brightline Outfitters order desk. You help the customer who wrote in, and only them.
- Look up orders and tracking before answering. Quote dates and statuses exactly as the tools return them.
- To start a return, call create_return. A staff member must approve it; if approval is denied, say a
  colleague will review the request.
- If a tool fails twice, or the customer asks for a person, call escalate and tell the customer.
- Never promise refunds, discounts or delivery dates the tools did not give you."""


class OrderDB:
    def __init__(self, path: str = ":memory:"):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, email TEXT, data TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS returns (rma TEXT PRIMARY KEY, order_id TEXT, sku TEXT, reason TEXT)")
        if not self.db.execute("SELECT 1 FROM orders LIMIT 1").fetchone():
            with self.db:
                for o in json.loads((DATA / "orders.json").read_text()):
                    self.db.execute("INSERT INTO orders VALUES (?,?,?)", (o["id"], o["email"], json.dumps(o)))

    def get(self, order_id: str) -> dict | None:
        row = self.db.execute("SELECT data FROM orders WHERE id=?", (order_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def add_return(self, order_id: str, sku: str, reason: str) -> str:
        rma = f"RMA-{uuid.uuid4().hex[:6].upper()}"
        with self.db:
            self.db.execute("INSERT INTO returns VALUES (?,?,?,?)", (rma, order_id, sku, reason))
        return rma

    def returns(self) -> list[tuple]:
        return self.db.execute("SELECT * FROM returns").fetchall()


class CarrierAPI:
    """Stands in for a shipping carrier's HTTP API. failure_rate simulates timeouts and 503s."""

    def __init__(self, failure_rate: float = 0.0, seed: int | None = None):
        self.failure_rate, self.rng, self.calls = failure_rate, random.Random(seed), 0
        self.events = json.loads((DATA / "tracking.json").read_text())

    def track(self, number: str) -> list[dict]:
        self.calls += 1
        if self.rng.random() < self.failure_rate:
            raise RetryableError("carrier API returned 503")
        return self.events.get(number, [])


def build_tools(sender: str, db: OrderDB, carrier: CarrierAPI, ledger: IdempotencyLedger,
                escalations: list[dict]) -> list:
    """Tools are created per conversation and bound to the sender, so the model cannot ask for other people's data."""

    def owned(order_id: str) -> dict:
        order = db.get(order_id.strip().upper())
        if order is None:
            raise LookupError(f"no order {order_id}")
        if order["email"].lower() != sender.lower():
            raise PermissionError(f"order {order_id} does not belong to the customer in this conversation")
        return order

    @tool
    def lookup_order(order_id: str) -> dict:
        """Get status, date placed, items and tracking number for one of the customer's orders.

        Args:
            order_id: Order number like BL-10422.
        """
        o = owned(order_id)
        return {k: o[k] for k in ("id", "placed", "status", "items", "tracking")}

    @tool(timeout=15)
    def track_shipment(order_id: str) -> list[dict]:
        """Carrier tracking events for one of the customer's orders, oldest first.

        Args:
            order_id: Order number like BL-10422.
        """
        o = owned(order_id)
        if not o["tracking"]:
            return [{"event": "Not shipped yet", "status": o["status"]}]
        return retry(lambda: carrier.track(o["tracking"]), attempts=3, base=0.2)

    @tool(risk="write")
    def create_return(order_id: str, sku: str, reason: str) -> dict:
        """Create a return authorisation for one item. Requires staff approval.

        Args:
            order_id: Order number like BL-10422.
            sku: The item's SKU from lookup_order.
            reason: The customer's reason, in a few words.
        """
        o = owned(order_id)
        if sku not in {i["sku"] for i in o["items"]}:
            raise ValueError(f"{sku} is not in order {order_id}")
        if o["status"] != "delivered":
            raise ValueError(f"order {order_id} is {o['status']}; returns open after delivery")
        key = ledger.key("create_return", order=o["id"], sku=sku)
        rma, fresh = ledger.run_once(key, lambda: db.add_return(o["id"], sku, reason))
        return {"rma": rma, "created": fresh, "note": "Return label will be emailed by staff."}

    @tool(risk="write")
    def escalate(reason: str) -> str:
        """Hand this conversation to a human colleague.

        Args:
            reason: Why a human is needed.
        """
        escalations.append({"customer": sender, "reason": reason})
        return "Escalated. A colleague will reply within one business day."

    return [lookup_order, track_shipment, create_return, escalate]


class ConsoleApprover:
    def approve(self, t, arguments: dict) -> bool:
        if t.name == "escalate":
            return True           # handing off to a person is always allowed
        print(f"\nAPPROVAL NEEDED: {t.name}({json.dumps(arguments)})")
        return input("Approve? [y/N] ").strip().lower() == "y"


def make_agent(sender: str, model, approver, workdir: Path, carrier: CarrierAPI | None = None,
               db: OrderDB | None = None, escalations: list | None = None) -> Agent:
    workdir.mkdir(parents=True, exist_ok=True)
    db = db or OrderDB(str(workdir / "orders.db"))
    ledger = IdempotencyLedger(str(workdir / "actions.db"))
    reg = ToolRegistry(approver=approver).add(*build_tools(sender, db, carrier or CarrierAPI(), ledger,
                                                          escalations if escalations is not None else []))
    return Agent(model, reg, SYSTEM, AgentConfig(max_steps=8, max_tool_calls=12),
                 tracer=Tracer(workdir / "trace.jsonl"), store=CheckpointStore(str(workdir / "runs.db")))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("message", nargs="?")
    ap.add_argument("--from", dest="sender")
    ap.add_argument("--resume")
    ap.add_argument("--workdir", default=".orderdesk")
    a = ap.parse_args()
    work = Path(a.workdir)
    if a.resume:
        sender = json.loads((work / f"{a.resume}.json").read_text())["sender"]
        result = make_agent(sender, model_from_env(), ConsoleApprover(), work).resume(a.resume)
    else:
        run_id = uuid.uuid4().hex[:10]
        work.mkdir(exist_ok=True)
        (work / f"{run_id}.json").write_text(json.dumps({"sender": a.sender}))
        print(f"run id: {run_id}")
        result = make_agent(a.sender, model_from_env(), ConsoleApprover(), work).run(a.message, run_id=run_id)
    print(f"[{result.status}] {result.answer}")


if __name__ == "__main__":
    main()
