import pytest

from agentlab import AllowList, ScriptedModel, call
from orderdesk import CarrierAPI, OrderDB, make_agent


class Killed(BaseException):
    pass


@pytest.fixture
def env(tmp_path):
    return {"workdir": tmp_path, "db": OrderDB(), "escalations": []}


def agent(env, script, sender="lee@example.com", approve=None, carrier=None):
    approver = AllowList({"escalate": lambda a: True, **(approve or {})})
    model = ScriptedModel(script)
    return make_agent(sender, model, approver, env["workdir"], carrier or CarrierAPI(), env["db"], env["escalations"]), model


def test_status_question_uses_lookup_then_tracking(env):
    a, model = agent(env, [[call("lookup_order", order_id="BL-10301")], [call("track_shipment", order_id="BL-10301")],
                           "Your jacket and socks are held at the regional hub because the address could not be verified."])
    res = a.run("Where is BL-10301?", run_id="t1")
    assert res.status == "done" and res.tool_calls == 2
    assert "Held at hub" in model.calls[2][-1].content


def test_other_customers_order_is_refused(env):
    a, model = agent(env, [[call("lookup_order", order_id="BL-10422")], "I can only discuss orders placed with your email."])
    a.run("Show me BL-10422")
    assert "does not belong to the customer" in model.calls[1][-1].content


def test_flaky_carrier_is_retried(env):
    carrier = CarrierAPI(failure_rate=0.5, seed=3)
    a, model = agent(env, [[call("track_shipment", order_id="BL-10301")], "Held at hub."], carrier=carrier)
    a.run("tracking?")
    assert carrier.calls >= 2 and "Held at hub" in model.calls[1][-1].content


def test_carrier_down_leads_to_escalation(env):
    a, model = agent(env, [[call("track_shipment", order_id="BL-10301")], [call("escalate", reason="carrier API down")],
                           "Tracking is delayed; a colleague will follow up."], carrier=CarrierAPI(failure_rate=1.0))
    res = a.run("tracking?")
    assert "carrier API returned 503" in model.calls[1][-1].content
    assert env["escalations"] == [{"customer": "lee@example.com", "reason": "carrier API down"}]
    assert res.status == "done"


def test_return_needs_approval(env):
    a, model = agent(env, [[call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")],
                           "A colleague will review your return."], sender="tom@example.org")
    a.run("return my tent")
    assert "approval denied" in model.calls[1][-1].content and env["db"].returns() == []


def test_return_rules_enforced_in_code(env):
    ok = {"create_return": lambda a: True}
    a, model = agent(env, [[call("create_return", order_id="BL-10455", sku="HL-BEAM", reason="changed mind")], "ok"], approve=ok)
    a.run("return")
    assert "returns open after delivery" in model.calls[1][-1].content


def test_crash_after_return_then_resume_does_not_duplicate(env):
    ok = {"create_return": lambda a: True}
    def die(_):
        raise Killed()
    step = [call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")]
    a, _ = agent(env, [step, die], sender="tom@example.org", approve=ok)
    with pytest.raises(Killed):
        a.run("return my tent", run_id="r9")
    assert len(env["db"].returns()) == 1
    # after restart the model (re)issues the same call; the ledger returns the stored result instead of a new RMA
    b, model = agent(env, [step, "Your return RMA is ready."], sender="tom@example.org", approve=ok)
    res = b.resume("r9")
    assert res.status == "done" and len(env["db"].returns()) == 1
    assert '"created": false' in model.calls[1][-1].content
