"""Offline demonstration of the order desk: a status question with a flaky carrier API, then a return request.

Model decisions are scripted; tools, retries, approvals, checkpoints and the trace are real.
"""
import json
import tempfile
from pathlib import Path

from agentlab import AllowList, ScriptedModel, call
from orderdesk import CarrierAPI, OrderDB, make_agent

work = Path(tempfile.mkdtemp())
db, carrier = OrderDB(), CarrierAPI(failure_rate=0.5, seed=3)       # every other carrier call fails
approver = AllowList({"escalate": lambda a: True})                   # returns are NOT approved in this run

agent = make_agent("lee@example.com", ScriptedModel([
    [call("lookup_order", order_id="BL-10301")],
    [call("track_shipment", order_id="BL-10301")],
    "Your jacket and socks (BL-10301) are held at the regional hub because the address could not be verified. "
    "Please reply with your full delivery address.",
]), approver, work / "a", carrier, db)
r = agent.run("Where is my order BL-10301?", run_id="demo-1")
for e in agent.tracer.events:
    if e["kind"] == "tool_result":
        print(f'tool {e["tool"]:<15} ok={e["ok"]}  {e["ms"]:>7.1f} ms')
print(f"[{r.status}] carrier API calls made: {carrier.calls}\n{r.answer}\n")

agent = make_agent("tom@example.org", ScriptedModel([
    [call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")],
    "I've sent your return request for the Alpine 2P Tent to a colleague for approval; you'll get the label by email.",
]), approver, work / "b", carrier, db)
r = agent.run("My tent zipper broke. I want to return BL-10388.", run_id="demo-2")
print("tool message:", r.messages[-2].content)
print(f"[{r.status}] returns in database: {db.returns()}")
print("checkpoint status:", agent.store.load("demo-2").status)
