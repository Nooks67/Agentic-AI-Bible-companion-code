"""Run the Module VIII workflow on the three sample invoices with a scripted extractor and a real browser.

The scripted replies are what a correct extractor returns for each PDF; the checks, portal and browser are real.
"""
import json
import tempfile
from pathlib import Path

from agentlab import ScriptedModel
from ap_portal import Portal
from browser_agent import process

INV = Path(__file__).parent / "data" / "invoices"
REPLIES = {
    "summit-2291.pdf": {"vendor": "Summit Textiles Ltd", "invoice_number": "ST-2291", "invoice_date": "2026-10-03",
                        "currency": "USD", "total": 2265.0, "bank_last4": "4821",
                        "lines": [{"description": "Ripstop nylon, 200 m", "qty": 1, "unit_price": 1840.0},
                                  {"description": "YKK #5 zippers, box of 500", "qty": 2, "unit_price": 212.5}]},
    "granite-7781.pdf": {"vendor": "Granite Freight Co", "invoice_number": "GF-7781", "invoice_date": "2026-10-06",
                         "currency": "USD", "total": 1405.0, "bank_last4": "0094",
                         "lines": [{"description": "Pallet freight", "qty": 3, "unit_price": 410.0},
                                   {"description": "Liftgate", "qty": 1, "unit_price": 75.0}]},
    "northlake-5520.pdf": {"vendor": "Northlake Packaging", "invoice_number": "NP-5520", "invoice_date": "2026-10-08",
                           "currency": "USD", "total": 620.0, "bank_last4": "3390",
                           "lines": [{"description": "Boxes", "qty": 1000, "unit_price": 0.62}]},
}

portal = Portal()
srv = portal.serve()
url = f"http://127.0.0.1:{srv.server_port}/"
approver = lambda inv, shot: print(f"  approver sees {Path(shot).name}, {inv.vendor}, {inv.total:.2f}") or True
with tempfile.TemporaryDirectory() as tmp:
    for name, reply in REPLIES.items():
        out = process(INV / name, ScriptedModel([json.dumps(reply)]), url, approver, Path(tmp))
        print(f"{name:<20} [{out.status}] {out.detail}")
    portal.invoice_label = "Supplier reference"          # the portal is redesigned overnight
    out = process(INV / "summit-2291.pdf", ScriptedModel([json.dumps(REPLIES["summit-2291.pdf"])]), url, approver, Path(tmp))
    print(f"after redesign       [{out.status}] {out.detail}")
    print("audit actions:", [json.loads(l)["action"] for l in (Path(tmp) / "audit.jsonl").read_text().splitlines()])
print("portal requests:", portal.requests)
srv.shutdown()
