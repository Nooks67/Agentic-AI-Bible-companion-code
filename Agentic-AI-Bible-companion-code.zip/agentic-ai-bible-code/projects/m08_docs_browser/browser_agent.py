"""Module VIII project, part 2: enter a checked invoice into a web portal with Playwright, under human approval.

The browser steps are explicit and verified, not improvised: find each field by its visible label,
fill it, read it back, screenshot the filled form, ask a person, then submit and confirm.

  python browser_agent.py data/invoices/summit-2291.pdf --portal http://127.0.0.1:8790
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from playwright.sync_api import Page, sync_playwright

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from agentlab import model_from_env  # noqa: E402
from agentlab.security import AuditLog  # noqa: E402
from invoice_extract import VENDORS, Invoice, check, extract  # noqa: E402


class PageChanged(RuntimeError):
    """The page no longer looks the way the automation expects. Stop; do not guess."""


@dataclass
class Outcome:
    status: str            # submitted | rejected_by_checks | rejected_by_human | page_changed
    detail: str
    screenshot: str | None = None


def fill_by_label(page: Page, label: str, value: str, select: bool = False) -> None:
    field = page.get_by_label(label, exact=True)
    if field.count() != 1:
        raise PageChanged(f"expected one field labelled '{label}', found {field.count()}")
    field.select_option(value) if select else field.fill(value)
    if field.input_value() != value:
        raise PageChanged(f"field '{label}' did not keep the value we typed")


def submit_invoice(inv: Invoice, portal_url: str, approve, shots: Path, audit: AuditLog, headless: bool = True) -> Outcome:
    shots.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page()
        try:
            page.goto(portal_url, timeout=15_000)
            if "New payment request" not in page.title():
                raise PageChanged(f"unexpected page title {page.title()!r}")
            fill_by_label(page, "Vendor", VENDORS[inv.vendor]["vendor_id"], select=True)
            fill_by_label(page, "Invoice number", inv.invoice_number)
            fill_by_label(page, "Amount (USD)", f"{inv.total:.2f}")
            fill_by_label(page, "Invoice date", inv.invoice_date.isoformat())
            shot = str(shots / f"{inv.invoice_number}-before-submit.png")
            page.screenshot(path=shot, full_page=True)
            if not approve(inv, shot):
                audit.record("browser-agent", "submit_declined", invoice=inv.invoice_number)
                return Outcome("rejected_by_human", "approver declined", shot)
            page.get_by_role("button", name="Submit for payment").click()
            page.wait_for_selector("#ref", timeout=10_000)
            ref = page.locator("#ref").inner_text()
            audit.record("browser-agent", "submitted", invoice=inv.invoice_number, amount=inv.total, portal_ref=ref)
            return Outcome("submitted", ref, shot)
        except PageChanged as e:
            page.screenshot(path=str(shots / "page-changed.png"), full_page=True)
            audit.record("browser-agent", "stopped_page_changed", invoice=inv.invoice_number, reason=str(e))
            return Outcome("page_changed", str(e), str(shots / "page-changed.png"))
        finally:
            browser.close()


def process(pdf: Path, model, portal_url: str, approve, workdir: Path) -> Outcome:
    audit = AuditLog(workdir / "audit.jsonl")
    inv, raw = extract(model, pdf)
    issues = check(inv, raw)
    audit.record("browser-agent", "extracted", file=pdf.name, invoice=inv.model_dump(mode="json"), issues=issues)
    if issues:
        return Outcome("rejected_by_checks", "; ".join(issues))
    return submit_invoice(inv, portal_url, approve, workdir / "screenshots", audit)


def console_approve(inv: Invoice, screenshot: str) -> bool:
    print(json.dumps(inv.model_dump(mode="json"), indent=1), f"\nScreenshot: {screenshot}")
    return input("Submit this payment request? [y/N] ").strip().lower() == "y"


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf", type=Path)
    ap.add_argument("--portal", default="http://127.0.0.1:8790")
    a = ap.parse_args()
    out = process(a.pdf, model_from_env(), a.portal, console_approve, Path(".ap-run"))
    print(f"[{out.status}] {out.detail}")
