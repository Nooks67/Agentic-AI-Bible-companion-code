import json
from pathlib import Path

import pytest

from agentlab import ScriptedModel
from ap_portal import Portal
from browser_agent import process
from invoice_extract import check, extract, pdf_text

INV = Path(__file__).resolve().parent.parent / "data" / "invoices"


def reply(**kw):
    base = {"vendor": "Summit Textiles Ltd", "invoice_number": "ST-2291", "invoice_date": "2026-10-03", "currency": "USD",
            "lines": [{"description": "Ripstop nylon, 200 m", "qty": 1, "unit_price": 1840.0},
                      {"description": "YKK #5 zippers, box of 500", "qty": 2, "unit_price": 212.5}],
            "total": 2265.0, "bank_last4": "4821"}
    return json.dumps({**base, **kw})


def test_clean_invoice_passes_checks():
    inv, raw = extract(ScriptedModel([reply()]), INV / "summit-2291.pdf")
    assert check(inv, raw) == []


def test_arithmetic_mismatch_is_caught():
    r = reply(vendor="Granite Freight Co", invoice_number="GF-7781", invoice_date="2026-10-06", bank_last4="0094",
              lines=[{"description": "Pallet freight", "qty": 3, "unit_price": 410.0}, {"description": "Liftgate", "qty": 1, "unit_price": 75.0}],
              total=1405.0)
    inv, raw = extract(ScriptedModel([r]), INV / "granite-7781.pdf")
    assert check(inv, raw) == ["line items add up to 1305.00 but total is 1405.00"]


def test_changed_bank_and_hidden_instructions_are_caught():
    assert "pre-approved" in pdf_text(INV / "northlake-5520.pdf")
    r = reply(vendor="Northlake Packaging", invoice_number="NP-5520", invoice_date="2026-10-08", bank_last4="3390",
              lines=[{"description": "Boxes", "qty": 1000, "unit_price": 0.62}], total=620.0)
    inv, raw = extract(ScriptedModel([r]), INV / "northlake-5520.pdf")
    issues = check(inv, raw)
    assert "bank account ending 3390 differs from vendor record ending 7713" in issues
    assert "document contains instructions aimed at automated systems" in issues


@pytest.fixture
def portal():
    p = Portal()
    srv = p.serve()
    yield p, f"http://127.0.0.1:{srv.server_port}/"
    srv.shutdown()


def test_browser_submits_only_after_approval(portal, tmp_path):
    p, url = portal
    asked = []
    out = process(INV / "summit-2291.pdf", ScriptedModel([reply()]), url, lambda inv, shot: asked.append(shot) or True, tmp_path)
    assert out.status == "submitted" and out.detail == "Reference PR-0001"
    assert p.requests == [{"vendor": "V-102", "invoice": "ST-2291", "amount": "2265.00", "date": "2026-10-03", "ref": "PR-0001"}]
    assert Path(asked[0]).stat().st_size > 5000           # the approver saw a real screenshot
    lines = (tmp_path / "audit.jsonl").read_text().splitlines()
    assert [json.loads(l)["action"] for l in lines] == ["extracted", "submitted"]


def test_declined_approval_submits_nothing(portal, tmp_path):
    p, url = portal
    out = process(INV / "summit-2291.pdf", ScriptedModel([reply()]), url, lambda inv, shot: False, tmp_path)
    assert out.status == "rejected_by_human" and p.requests == []


def test_redesigned_page_stops_the_automation(portal, tmp_path):
    p, url = portal
    p.invoice_label = "Supplier reference"                 # the site was redesigned
    out = process(INV / "summit-2291.pdf", ScriptedModel([reply()]), url, lambda inv, shot: True, tmp_path)
    assert out.status == "page_changed" and "Invoice number" in out.detail and p.requests == []


def test_invalid_invoice_never_reaches_the_browser(portal, tmp_path):
    p, url = portal
    out = process(INV / "summit-2291.pdf", ScriptedModel([reply(total=9999.0)]), url, lambda *a: True, tmp_path)
    assert out.status == "rejected_by_checks" and p.requests == []
