"""A tiny accounts-payable web portal, standing in for a supplier or ERP site with no API.

  python ap_portal.py          # http://127.0.0.1:8790
"""
from __future__ import annotations

import html
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

FORM = """<!doctype html><html><head><title>AP Portal - New payment request</title>
<style>body{{font:15px sans-serif;margin:40px}} label{{display:block;margin-top:12px}} input,select{{font-size:15px}}</style></head>
<body><h1>New payment request</h1>
<form method="post" action="/requests">
<input type="hidden" name="csrf" value="{csrf}">
<label for="vendor">Vendor</label>
<select id="vendor" name="vendor"><option value="">Choose...</option>{options}</select>
<label for="{inv_id}">{inv_label}</label><input id="{inv_id}" name="invoice">
<label for="amount">Amount (USD)</label><input id="amount" name="amount" inputmode="decimal">
<label for="due">Invoice date</label><input id="due" name="date" type="date">
<p><button type="submit">Submit for payment</button></p></form></body></html>"""

VENDOR_IDS = {"V-102": "Summit Textiles Ltd", "V-117": "Granite Freight Co", "V-130": "Northlake Packaging"}


class Portal:
    def __init__(self, invoice_label: str = "Invoice number"):
        self.requests: list[dict] = []
        self.csrf = secrets.token_hex(8)
        self.invoice_label = invoice_label      # change it to simulate a redesigned page

    def handler(self):
        portal = self

        class H(BaseHTTPRequestHandler):
            def page(self, code: int, body: str) -> None:
                data = body.encode()
                self.send_response(code)
                self.send_header("content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(data)

            def do_GET(self) -> None:
                opts = "".join(f'<option value="{k}">{html.escape(v)}</option>' for k, v in VENDOR_IDS.items())
                self.page(200, FORM.format(csrf=portal.csrf, options=opts, inv_label=portal.invoice_label,
                                           inv_id="invoice" if portal.invoice_label == "Invoice number" else "ref"))

            def do_POST(self) -> None:
                form = {k: v[0] for k, v in parse_qs(self.rfile.read(int(self.headers["content-length"])).decode()).items()}
                if form.get("csrf") != portal.csrf:
                    return self.page(403, "<h1>Forbidden</h1>")
                missing = [k for k in ("vendor", "invoice", "amount", "date") if not form.get(k)]
                if missing:
                    return self.page(400, f"<h1>Missing: {', '.join(missing)}</h1>")
                ref = f"PR-{len(portal.requests) + 1:04d}"
                portal.requests.append({**{k: form[k] for k in ("vendor", "invoice", "amount", "date")}, "ref": ref})
                self.page(200, f"<h1>Request received</h1><p id='ref'>Reference {ref}</p>")

            def log_message(self, *a) -> None:
                pass
        return H

    def serve(self, port: int = 0) -> ThreadingHTTPServer:
        srv = ThreadingHTTPServer(("127.0.0.1", port), self.handler())
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return srv


if __name__ == "__main__":
    Portal().serve(8790)
    print("AP portal on http://127.0.0.1:8790")
    threading.Event().wait()
