"""Module VI project: a policy assistant with retrieval, source citations and memory controls.

Usage:
  python policy_assistant.py index                 # build and check the index, report quarantined chunks
  python policy_assistant.py ask --user ana "Can I return a sale item?"
  python policy_assistant.py eval                  # retrieval quality on data/eval.jsonl
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from agentlab import ChatModel, Message, model_from_env  # noqa: E402
from agentlab.memory import LongTermMemory  # noqa: E402
from agentlab.rag import (ANSWER_RULES, Chunk, HybridRetriever, build_context, check_citations, load_folder,  # noqa: E402
                          recall_at_k)
from agentlab.security import scan_injection  # noqa: E402

HERE = Path(__file__).parent
ABSTAIN = "I don't know based on the provided documents."
MIN_RELEVANCE = 0.30       # reranker score below which we do not even ask the model


@dataclass
class Index:
    retriever: HybridRetriever
    quarantined: list[tuple[Chunk, list[str]]] = field(default_factory=list)


def build_index(folder: Path = HERE / "docs") -> Index:
    """Chunk documents and keep suspicious chunks out of the index (reported for human review)."""
    clean, bad = [], []
    for c in load_folder(folder, max_words=90, overlap=15):
        rep = scan_injection(c.text)
        (bad if rep.suspicious else clean).append(c if not rep.suspicious else (c, rep.matches))
    return Index(HybridRetriever(clean), bad)


@dataclass
class Answer:
    text: str
    sources: list[str]
    status: str            # answered | abstained | unsupported
    problems: list[str] = field(default_factory=list)


class PolicyAssistant:
    def __init__(self, model: ChatModel, index: Index, memory: LongTermMemory | None = None, k: int = 3):
        self.model, self.index, self.k = model, index, k
        self.memory = memory or LongTermMemory()

    def ask(self, question: str, user: str | None = None) -> Answer:
        hits = self.index.retriever.search(question, k=self.k)
        if not hits or hits[0][1] < MIN_RELEVANCE:
            return Answer(ABSTAIN, [], "abstained")
        prefs = self.memory.recall(user, question + " prefer", k=2) if user else []
        system = ANSWER_RULES + ("\nUser preferences (from memory): " + "; ".join(m.text for m in prefs) if prefs else "")
        msgs = [Message("system", system), Message("user", f"{build_context(hits)}\n\nQuestion: {question}")]
        for attempt in range(2):
            text = self.model.complete(msgs).message.content.strip()
            check = check_citations(text, hits)
            if check["abstained"]:
                return Answer(ABSTAIN, [], "abstained")
            if check["ok"]:
                return Answer(text, sorted({c.id for c, _ in hits if f"[{c.id}]" in text}), "answered")
            msgs += [Message("assistant", text),
                     Message("user", "Some sentences were unsupported: " + "; ".join(check["problems"]) +
                             ". Rewrite using only the sources, citing each sentence, or abstain.")]
        return Answer(ABSTAIN, [], "unsupported", check["problems"])

    # memory controls: nothing is stored unless the user asks, and the user can see and erase it
    def remember(self, user: str, text: str) -> int:
        return self.memory.remember(user, text, kind="preference", source="user request", ttl_days=365)

    def what_do_you_know(self, user: str) -> list[str]:
        return [f"#{m.id}: {m.text}" for m in self.memory._live(user)]

    def forget_me(self, user: str) -> int:
        return self.memory.forget(user)


def evaluate(index: Index, path: Path = HERE / "data" / "eval.jsonl", k: int = 3) -> dict:
    rows = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
    answerable = [r for r in rows if r["relevant"]]
    search = lambda q, n: index.retriever.search(q, k=n)
    unanswerable = [r for r in rows if r.get("expect_abstain")]
    abstained = sum(1 for r in unanswerable if (h := search(r["question"], 1)) == [] or h[0][1] < MIN_RELEVANCE)
    return {"questions": len(rows), "recall@1": round(recall_at_k(search, answerable, 1), 3),
            f"recall@{k}": round(recall_at_k(search, answerable, k), 3),
            "retrieval_gate_abstains": round(abstained / max(1, len(unanswerable)), 3)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["index", "ask", "eval"])
    ap.add_argument("question", nargs="?")
    ap.add_argument("--user")
    a = ap.parse_args()
    index = build_index()
    if a.cmd == "index":
        print(f"indexed {len(index.retriever.bm25.chunks)} chunks; quarantined {len(index.quarantined)}")
        for c, why in index.quarantined:
            print(f"  QUARANTINED {c.id}: {why}")
    elif a.cmd == "eval":
        print(json.dumps(evaluate(index), indent=1))
    else:
        mem = LongTermMemory(str(HERE / ".memory.db"))
        ans = PolicyAssistant(model_from_env(), index, mem).ask(a.question, a.user)
        print(f"[{ans.status}] {ans.text}\nsources: {', '.join(ans.sources) or '-'}")


if __name__ == "__main__":
    main()
