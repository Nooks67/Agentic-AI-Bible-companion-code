# Returns

Unused items in their original packaging can be returned within 30 days of delivery. Start a return from your account page or by emailing the order desk with your order number. We email a prepaid label for faulty items; for change-of-mind returns the return shipping fee of 6.95 USD is deducted from the refund.

# Refunds

Refunds go back to the original payment method within 5 business days of the return arriving at our warehouse. Gift cards are refunded as store credit. Sale items marked final sale cannot be returned unless faulty.

# Exchanges

We do not process direct exchanges. Return the original item for a refund and place a new order for the replacement size or colour.
