# Caring for waterproof jackets

Wash waterproof shells such as the Storm Shell Jacket on a cool cycle with a technical cleaner, not regular detergent or fabric softener. Tumble dry on low heat for 20 minutes to reactivate the water-repellent finish.

# Tents

Always dry a tent completely before storing it to prevent mildew. Store tents loosely in a cool, dry place rather than compressed in the stuff sack.

# Merino clothing

Merino socks and base layers can be machine washed on a wool cycle at 30 C. Do not use bleach and do not tumble dry.
