# Your account

You can check out as a guest, but an account lets you track orders, start returns and save addresses. Passwords must be at least 12 characters.

# Deleting your account

To delete your account and personal data, open Account settings and choose Delete account, or email privacy@brightline.example. We complete deletion within 30 days, except for order records we must keep for 7 years for tax purposes.

# Marketing emails

You can unsubscribe from marketing emails with the link at the bottom of any message. Order and shipping emails cannot be turned off because they are part of the service.
