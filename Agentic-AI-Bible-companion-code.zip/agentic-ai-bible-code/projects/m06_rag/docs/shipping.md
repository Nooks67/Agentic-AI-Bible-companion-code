# Delivery options

Standard shipping takes 3 to 5 business days within the continental United States and is free on orders over 75 USD. Express shipping arrives the next business day when ordered before 2 pm Eastern time and costs 19 USD.

# International shipping

We ship to Canada, the United Kingdom and the European Union. International orders take 7 to 12 business days. Import duties and taxes are collected by the carrier on delivery and are not included in our prices.

# Tracking

A tracking link is emailed when the order leaves the warehouse. If tracking has not updated for 5 business days, contact the order desk and we will open an investigation with the carrier.
