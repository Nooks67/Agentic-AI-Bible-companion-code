# Two-year warranty

All Brightline-branded products carry a two-year warranty against manufacturing defects in materials and workmanship, counted from the delivery date. The warranty covers failed seams, broken zippers and delaminating fabric under normal use.

# What the warranty does not cover

The warranty does not cover accidental damage, normal wear such as faded colours or worn soles, damage from improper washing, or products modified after purchase. Third-party brands are covered by their manufacturer's warranty.

# Making a claim

Send a photo of the defect and your order number to the order desk. We repair, replace or refund at our discretion, usually within 10 business days of receiving the item.
