import pytest

from agentlab import ScriptedModel
from agentlab.memory import LongTermMemory
from policy_assistant import ABSTAIN, PolicyAssistant, build_index, evaluate


@pytest.fixture(scope="module")
def index():
    return build_index()


def test_injected_chunk_is_quarantined_not_indexed(index):
    assert [c.id for c, _ in index.quarantined] == ["community_faq#2"]
    ids = {c.id for c in index.retriever.bm25.chunks}
    assert "community_faq#2" not in ids and "community_faq#1" in ids


def test_retrieval_quality_meets_targets(index):
    m = evaluate(index)
    assert m["recall@3"] >= 0.9 and m["recall@1"] >= 0.8


def test_cited_answer_is_accepted(index):
    model = ScriptedModel(["Express shipping costs 19 USD and arrives the next business day when ordered before 2 pm Eastern time [shipping#1]."])
    ans = PolicyAssistant(model, index).ask("How much does express shipping cost?")
    assert ans.status == "answered" and ans.sources == ["shipping#1"]
    assert "<source id=\"shipping#1\">" in model.calls[0][1].content


def test_unsupported_answer_is_retried_then_refused(index):
    model = ScriptedModel(["Express shipping includes a lifetime guarantee on every jacket [shipping#1].",
                           "Every express parcel comes with a complimentary gift [shipping#1]."])
    ans = PolicyAssistant(model, index).ask("How much does express shipping cost?")
    assert ans.status == "unsupported" and ans.text == ABSTAIN and len(model.calls) == 2
    assert "unsupported" in model.calls[1][-1].content


def test_irrelevant_question_abstains_without_model_call(index):
    model = ScriptedModel([])
    ans = PolicyAssistant(model, index).ask("Do you offer student discounts?")
    assert ans.status == "abstained" and model.calls == []


def test_model_abstention_is_respected(index):
    model = ScriptedModel([ABSTAIN])
    assert PolicyAssistant(model, index).ask("What is the CEO's phone number?").status == "abstained"


def test_memory_only_when_asked_visible_and_erasable(index):
    mem = LongTermMemory()
    pa = PolicyAssistant(ScriptedModel(["Standard shipping takes 3 to 5 business days within the continental United States [shipping#1]."]), index, mem)
    assert pa.what_do_you_know("ana") == []
    pa.remember("ana", "I prefer short answers. Reach me at ana@example.com")
    assert pa.what_do_you_know("ana") == ["#1: I prefer short answers. Reach me at [email]"]
    pa.ask("How long does standard shipping take? prefer short", user="ana")
    assert "User preferences (from memory): I prefer short answers" in pa.model.calls[0][0].content
    assert pa.forget_me("ana") == 1 and pa.what_do_you_know("ana") == []


def test_known_limit_word_overlap_misses_subtle_contradictions(index):
    """Documented limitation (Chapter 19): a false claim made of the source's own words passes the overlap check."""
    model = ScriptedModel(["Express shipping is free for members [shipping#1]."])
    assert PolicyAssistant(model, index).ask("How much does express shipping cost?").status == "answered"
