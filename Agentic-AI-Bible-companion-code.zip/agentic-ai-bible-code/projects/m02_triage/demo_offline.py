"""Offline demonstration: triage the five sample emails with a scripted model.

The scripted replies stand in for a real model so the run is free and repeatable.
Two replies are deliberately flawed (an invented order number and a malformed category)
to show the repair loop and the deterministic guard at work.
"""
import json
from pathlib import Path

from agentlab import ScriptedModel
from triage import run

EMAILS = [json.loads(l) for l in (Path(__file__).parent / "data" / "emails.jsonl").read_text().splitlines()]


def t(category, priority, sentiment, order_id, summary, needs_human):
    return json.dumps({"category": category, "priority": priority, "sentiment": sentiment,
                       "order_id": order_id, "summary": summary, "needs_human": needs_human})


SCRIPT = [
    t("billing", 1, "negative", "BL-10422", "Customer was charged twice for order BL-10422.", True),
    t("defects", 2, "negative", "BL-10388", "Tent zipper snapped on first night.", False),      # bad category
    t("defect", 2, "negative", "BL-10388", "Tent zipper snapped on first night.", False),       # repaired
    t("shipping", 3, "neutral", "BL-55555", "Asks whether Brightline ships to Canada.", False),  # invented id
    t("shipping", 1, "negative", "BL-10301", "Third email about a 3-week-late order; wants refund.", True),
    t("spam", 3, "neutral", None, "Unsolicited SEO services offer.", False),
]

if __name__ == "__main__":
    for row in run(ScriptedModel(SCRIPT), EMAILS):
        tk = row["ticket"]
        print(f'{row["id"]}: {tk["category"]:<9} p{tk["priority"]} order={tk["order_id"]} human={tk["needs_human"]}')
