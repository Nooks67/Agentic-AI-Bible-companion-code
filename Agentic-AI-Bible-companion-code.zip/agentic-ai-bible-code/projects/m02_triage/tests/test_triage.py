import json
from pathlib import Path

from agentlab import ScriptedModel
from triage import Ticket, consistency, guard, run, triage_one

EMAILS = [json.loads(l) for l in (Path(__file__).parent.parent / "data" / "emails.jsonl").read_text().splitlines()]


def t(**kw):
    base = {"category": "billing", "priority": 1, "sentiment": "negative", "order_id": "BL-10422",
            "summary": "Customer was charged twice for an order.", "needs_human": True}
    return json.dumps({**base, **kw})


def test_valid_reply_becomes_ticket():
    ticket, _ = triage_one(ScriptedModel([t()]), EMAILS[0])
    assert ticket.category == "billing" and ticket.order_id == "BL-10422"


def test_invalid_category_is_repaired():
    model = ScriptedModel([t(category="payments"), t()])
    ticket, _ = triage_one(model, EMAILS[0])
    assert ticket.category == "billing"
    assert "category" in model.calls[1][-1].content      # the validation error was fed back


def test_bad_order_format_is_rejected_then_fixed():
    ticket, _ = triage_one(ScriptedModel([t(order_id="10422"), t()]), EMAILS[0])
    assert ticket.order_id == "BL-10422"


def test_guard_removes_invented_order_id_and_forces_human_on_p1():
    invented = Ticket.model_validate_json(t(order_id="BL-99999", needs_human=False))
    fixed = guard(invented, EMAILS[0])
    assert fixed.order_id is None and fixed.needs_human


def test_email_text_is_wrapped_as_untrusted():
    model = ScriptedModel([t(category="spam", priority=3, order_id=None, needs_human=False,
                             summary="Unsolicited SEO services offer.")])
    triage_one(model, EMAILS[4])
    user = model.calls[0][1].content
    assert user.startswith('<untrusted source="email from promo@spam.example">')


def test_consistency_measure_and_failed_runs():
    assert consistency(["billing", "billing", "defect"]) == 2 / 3
    rows = run(ScriptedModel([t(), t(category="defect"), t()]), EMAILS[:1], runs=3)
    assert rows[0]["consistency"]["category"] == 2 / 3 and rows[0]["failed_runs"] == 0
    bad = run(ScriptedModel(["x", "y", "z"]), EMAILS[:1], runs=1)
    assert bad[0]["ticket"] is None and bad[0]["failed_runs"] == 1
