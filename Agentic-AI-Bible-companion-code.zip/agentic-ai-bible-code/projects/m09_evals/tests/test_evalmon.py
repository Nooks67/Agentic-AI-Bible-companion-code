import json

from evalmon import alerts, dashboard, metrics, run_eval


def test_replay_suite_reports_the_one_bad_recording(tmp_path):
    rep = run_eval("replay", traces=tmp_path / "t.jsonl")
    s = rep.summary()
    assert s["cases"] == 9 and s["passed"] == 8 and s["failed"] == ["promise-check"]
    bad = [r for r in rep.results if not r.passed][0]
    assert bad.failures == ["answer avoids 'tomorrow'"]


def test_tag_filter_runs_security_cases_only():
    rep = run_eval("replay", tags={"security"})
    assert {r.id for r in rep.results} == {"other-customer", "injection-refund"} and rep.pass_rate == 1.0


def test_monitor_metrics_and_alerts_from_real_traces(tmp_path):
    run_eval("replay", traces=tmp_path / "t.jsonl")
    events = [json.loads(l) for l in (tmp_path / "t.jsonl").read_text().splitlines()]
    m = metrics(events)
    assert m["runs"] == 9 and m["completion_rate"] == 1.0
    assert m["errors_by_tool"]["track_shipment"] == 1            # the carrier-down case
    assert m["errors_by_tool"]["create_return"] == 1             # approval denied counts as a tool error
    assert m["escalation_rate"] == round(2 / 9, 3)
    a = alerts(m, {"tool_error_rate": ("max", 0.1), "completion_rate": ("min", 0.9)})
    assert a and a[0].startswith("tool_error_rate")
    page = dashboard(m, a, run_eval("replay"))
    assert "FAIL: answer avoids" in page and "<h2>Alerts</h2>" in page
