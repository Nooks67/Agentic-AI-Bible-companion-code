"""Module IX project: an evaluation suite and a monitoring report for the Module III order-desk agent.

  python evalmon.py eval --mode replay            # recorded model decisions (deterministic, free)
  python evalmon.py eval --mode live              # the model from your environment (costs tokens)
  python evalmon.py eval --save baseline.json     # store a baseline; later runs are compared to it
  python evalmon.py monitor .orderdesk/trace.jsonl
"""
from __future__ import annotations

import argparse
import html
import json
import statistics
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "m03_orderdesk"))
from agentlab import AllowList, ScriptedModel, ToolCall, model_from_env  # noqa: E402
from agentlab.evals import Case, Report, compare, run_suite  # noqa: E402
from agentlab.trace import load  # noqa: E402
from orderdesk import CarrierAPI, OrderDB, make_agent  # noqa: E402

HERE = Path(__file__).parent


def load_cases(path: Path = HERE / "data" / "cases.json") -> tuple[list[Case], dict[str, dict]]:
    raw = json.loads(path.read_text())
    return [Case(r["id"], r["input"], r["checks"], r.get("tags", [])) for r in raw], {r["id"]: r for r in raw}


def replay_model(recorded: list) -> ScriptedModel:
    """Turn a recorded transcript ([[name, args]...] for tool turns, strings for text turns) into a model."""
    steps = [s if isinstance(s, str) else [ToolCall(f"r{i}{j}", n, a) for j, (n, a) in enumerate(s)]
             for i, s in enumerate(recorded)]
    return ScriptedModel(steps, name="replay")


def case_runner(meta: dict[str, dict], mode: str, workdir: Path, traces: Path | None = None):
    def run_case(case: Case):
        m = meta[case.id]
        model = replay_model(m["recorded"]) if mode == "replay" else model_from_env()
        approver = AllowList({"escalate": lambda a: True})        # returns stay unapproved in evals
        agent = make_agent(m["sender"], model, approver, workdir / case.id,
                           CarrierAPI(failure_rate=m.get("carrier_failure_rate", 0.0), seed=1), OrderDB())
        if traces:
            agent.tracer.path = traces
        return agent.run(case.input, run_id=case.id)
    return run_case


def run_eval(mode: str = "replay", tags: set[str] | None = None, traces: Path | None = None) -> Report:
    cases, meta = load_cases()
    if tags:
        cases = [c for c in cases if tags & set(c.tags)]
    with tempfile.TemporaryDirectory() as tmp:
        return run_suite(case_runner(meta, mode, Path(tmp), traces), cases)


# ------------------------------------------------------------------ monitoring
def pct(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    return s[min(len(s) - 1, int(round(p / 100 * (len(s) - 1))))]


def metrics(events: list[dict]) -> dict:
    runs = [e for e in events if e["kind"] == "run_end"]
    tools = [e for e in events if e["kind"] == "tool_result" and not e.get("repeated")]
    model = [e for e in events if e["kind"] == "model_reply"]
    tokens = [e.get("input_tokens", 0) + e.get("output_tokens", 0) for e in model]
    return {
        "runs": len(runs),
        "completion_rate": round(sum(r["status"] == "done" for r in runs) / max(1, len(runs)), 3),
        "escalation_rate": round(sum(e["tool"] == "escalate" for e in tools) / max(1, len(runs)), 3),
        "tool_error_rate": round(sum(not e["ok"] for e in tools) / max(1, len(tools)), 3),
        "tool_p95_ms": pct([e.get("ms", 0) for e in tools], 95),
        "model_p50_ms": pct([e.get("ms", 0) for e in model], 50),
        "tokens_per_run": round(sum(tokens) / max(1, len(runs)), 1),
        "cost_usd_total": round(sum(r.get("cost_usd", 0) for r in runs), 4),
        "errors_by_tool": {t: sum(1 for e in tools if e["tool"] == t and not e["ok"]) for t in sorted({e["tool"] for e in tools})},
    }


ALERTS = {"completion_rate": ("min", 0.9), "tool_error_rate": ("max", 0.15), "escalation_rate": ("max", 0.3),
          "tool_p95_ms": ("max", 3000), "tokens_per_run": ("max", 6000)}


def alerts(m: dict, rules: dict = ALERTS) -> list[str]:
    out = []
    for key, (kind, limit) in rules.items():
        v = m[key]
        if (kind == "min" and v < limit) or (kind == "max" and v > limit):
            out.append(f"{key} = {v} ({'below' if kind == 'min' else 'above'} {limit})")
    return out


def dashboard(m: dict, alert_list: list[str], report: Report | None = None) -> str:
    rows = "".join(f"<tr><th>{html.escape(k)}</th><td>{html.escape(json.dumps(v))}</td></tr>" for k, v in m.items())
    al = "".join(f"<li>{html.escape(a)}</li>" for a in alert_list) or "<li>none</li>"
    ev = ""
    if report:
        ev = "<h2>Evaluation</h2><table>" + "".join(
            f"<tr class={'ok' if r.passed else 'bad'}><th>{r.id}</th><td>{'PASS' if r.passed else 'FAIL: ' + html.escape('; '.join(r.failures))}</td></tr>"
            for r in report.results) + "</table>"
    return (f"<!doctype html><meta charset=utf-8><title>Order desk monitor</title><style>body{{font:14px sans-serif;margin:32px}}"
            f"th{{text-align:left;padding:4px 12px}} .bad{{color:#b42318}} .ok{{color:#067647}}</style>"
            f"<h1>Order desk: health</h1><h2>Alerts</h2><ul>{al}</ul><h2>Metrics</h2><table>{rows}</table>{ev}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["eval", "monitor"])
    ap.add_argument("trace", nargs="?")
    ap.add_argument("--mode", default="replay", choices=["replay", "live"])
    ap.add_argument("--save")
    ap.add_argument("--baseline")
    a = ap.parse_args()
    if a.cmd == "eval":
        rep = run_eval(a.mode)
        print(json.dumps(rep.summary(), indent=1))
        if a.save:
            rep.save(a.save)
        if a.baseline:
            cur = {"summary": rep.summary(), "results": [r.__dict__ for r in rep.results]}
            problems = compare(json.loads(Path(a.baseline).read_text()), cur)
            print("\n".join(problems) or "no regressions")
            sys.exit(1 if problems else 0)
    else:
        m = metrics(load(a.trace))
        al = alerts(m)
        Path("dashboard.html").write_text(dashboard(m, al))
        print(json.dumps(m, indent=1), "\nALERTS:", al or "none")


if __name__ == "__main__":
    main()
