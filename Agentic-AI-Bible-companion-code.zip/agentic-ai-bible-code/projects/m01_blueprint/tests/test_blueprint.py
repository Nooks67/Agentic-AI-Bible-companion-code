import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from blueprint import AgentSpec, main, mermaid, render, review

SPEC = json.loads((Path(__file__).parent.parent / "specs" / "order_desk.json").read_text())


def test_example_spec_passes(capsys):
    assert main(str(Path(__file__).parent.parent / "specs" / "order_desk.json")) == 0
    out = capsys.readouterr().out
    assert "| create_return | create a return authorisation | write | support staff |" in out
    assert "All design rules pass." in out


def test_write_tool_without_approver_is_flagged():
    bad = json.loads(json.dumps(SPEC))
    bad["tools"][2]["approval"] = None
    bad["boundaries"]["allowed_without_approval"].append("create_return")
    problems = review(AgentSpec.model_validate(bad))
    assert "tool create_return has risk 'write' but no approver" in problems
    assert any("allowed without approval" in p for p in problems)


def test_schema_rejects_missing_limits_and_few_failure_modes():
    bad = json.loads(json.dumps(SPEC))
    bad["boundaries"]["max_steps"] = 0
    bad["failure_modes"] = bad["failure_modes"][:1]
    with pytest.raises(ValidationError) as e:
        AgentSpec.model_validate(bad)
    assert {err["loc"][0] for err in e.value.errors()} == {"boundaries", "failure_modes"}


def test_mermaid_marks_approval_gates():
    m = mermaid(AgentSpec.model_validate(SPEC))
    assert 'A -- "needs support staff" --> T_create_return' in m
    assert "T_lookup_order --> D_orders" in m
