"""Module I project: validate an agent design spec and render a design document.

Usage:  python blueprint.py specs/order_desk.json  > design.md
"""
from __future__ import annotations

import json
import sys
from typing import Literal

from pydantic import BaseModel, Field


class Goal(BaseModel):
    id: str
    statement: str
    metric: str
    target: str


class ToolSpec(BaseModel):
    name: str
    purpose: str
    risk: Literal["read", "write", "external", "destructive"]
    data: list[str] = []
    approval: str | None = None


class DataSource(BaseModel):
    name: str
    owner: str
    contains_personal_data: bool


class Boundaries(BaseModel):
    max_steps: int = Field(gt=0, le=50)
    max_tool_calls: int = Field(gt=0, le=100)
    max_cost_usd_per_run: float = Field(gt=0)
    allowed_without_approval: list[str]
    never: list[str] = Field(min_length=1)


class FailureMode(BaseModel):
    mode: str
    mitigation: str


class Oversight(BaseModel):
    approver: str
    escalation: str


class AgentSpec(BaseModel):
    name: str
    problem: str = Field(min_length=20)
    users: list[str] = Field(min_length=1)
    goals: list[Goal] = Field(min_length=1)
    non_goals: list[str] = []
    model: dict[str, str]
    tools: list[ToolSpec] = Field(min_length=1)
    data_sources: list[DataSource]
    boundaries: Boundaries
    stop_conditions: list[str] = Field(min_length=1)
    human_oversight: Oversight
    failure_modes: list[FailureMode] = Field(min_length=3)


def review(spec: AgentSpec) -> list[str]:
    """Design rules that a schema alone cannot express. Returns a list of problems (empty = pass)."""
    problems = []
    names = {t.name for t in spec.tools}
    sources = {d.name for d in spec.data_sources}
    for t in spec.tools:
        if t.risk != "read" and not t.approval:
            problems.append(f"tool {t.name} has risk '{t.risk}' but no approver")
        if t.risk != "read" and t.name in spec.boundaries.allowed_without_approval:
            problems.append(f"tool {t.name} changes things but is listed as allowed without approval")
        for d in t.data:
            if d not in sources:
                problems.append(f"tool {t.name} uses undeclared data source '{d}'")
    for n in spec.boundaries.allowed_without_approval:
        if n not in names:
            problems.append(f"allowed tool '{n}' is not defined")
    if not any("limit" in s or "budget" in s for s in spec.stop_conditions):
        problems.append("stop conditions should include a step, time or cost limit")
    if any(d.contains_personal_data for d in spec.data_sources) and not any(
            "data" in n.lower() or "customer" in n.lower() for n in spec.boundaries.never):
        problems.append("personal data is in scope but no 'never' rule protects it")
    return problems


def mermaid(spec: AgentSpec) -> str:
    lines = ["flowchart LR", '  U["User request"] --> A["Agent loop<br/>(model decides)"]']
    for t in spec.tools:
        gate = f' -- "needs {t.approval}" --> ' if t.risk != "read" else " --> "
        lines.append(f'  A{gate}T_{t.name}["{t.name}<br/>({t.risk})"]')
        for d in t.data:
            lines.append(f'  T_{t.name} --> D_{d.replace(" ", "_")}[("{d}")]')
    lines.append('  A --> S{"Stop?"}')
    lines.append('  S -- "answer / limit / escalate" --> H["Reply or human"]')
    return "\n".join(lines)


def render(spec: AgentSpec, problems: list[str]) -> str:
    b = spec.boundaries
    out = [f"# Design: {spec.name}", "", f"**Problem.** {spec.problem}", "", "## Goals and measures", "",
           "| ID | Goal | Metric | Target |", "|---|---|---|---|"]
    out += [f"| {g.id} | {g.statement} | {g.metric} | {g.target} |" for g in spec.goals]
    out += ["", "## Tools and permissions", "", "| Tool | Purpose | Risk | Approval |", "|---|---|---|---|"]
    out += [f"| {t.name} | {t.purpose} | {t.risk} | {t.approval or 'none'} |" for t in spec.tools]
    out += ["", "## Execution boundaries", "",
            f"- At most {b.max_steps} model steps, {b.max_tool_calls} tool calls and ${b.max_cost_usd_per_run:.2f} per run.",
            *[f"- Never: {n}." for n in b.never], "", "## Failure modes", ""]
    out += [f"- **{f.mode}** → {f.mitigation}" for f in spec.failure_modes]
    out += ["", "## Architecture", "", "```mermaid", mermaid(spec), "```", "", "## Design review", ""]
    out += [f"- PROBLEM: {p}" for p in problems] or ["- All design rules pass."]
    return "\n".join(out) + "\n"


def main(path: str) -> int:
    spec = AgentSpec.model_validate(json.loads(open(path).read()))
    problems = review(spec)
    print(render(spec, problems))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
