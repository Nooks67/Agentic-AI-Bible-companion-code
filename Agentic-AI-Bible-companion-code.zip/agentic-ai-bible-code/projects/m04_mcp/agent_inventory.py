"""Module IV project: an agent that uses a REST API directly *and* tools from an MCP server.

Usage:
  python inventory_api.py &                     # start the demo API (key: dev-key)
  INVENTORY_API_KEY=dev-key python agent_inventory.py "Is the Alpine 2P tent in stock?"
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from mcp import StdioServerParameters  # noqa: E402

from agentlab import Agent, AgentConfig, DenyAll, ToolRegistry, model_from_env, tool  # noqa: E402
from inventory_client import InventoryClient  # noqa: E402
from mcp_bridge import MCPBridge  # noqa: E402

SYSTEM = """You answer stock and product questions for Brightline Outfitters.
Use the tools; never guess stock levels or prices. Quote prices in USD.
Reserving stock changes the inventory and needs staff approval."""


def rest_tools(api: InventoryClient) -> list:
    @tool
    def product_details(sku: str) -> dict:
        """Full catalogue entry (name, category, price) for one SKU, from the REST API.

        Args:
            sku: Product SKU such as TN-ALPINE2.
        """
        hits = [p for p in api.search("") if p["sku"] == sku]
        if not hits:
            raise LookupError(f"unknown sku {sku}")
        return hits[0]
    return [product_details]


def build(model, api: InventoryClient, mcp_server, approver=None) -> tuple[Agent, MCPBridge]:
    bridge = MCPBridge(mcp_server, prefix="inv_")
    reg = ToolRegistry(approver=approver or DenyAll()).add(*rest_tools(api), *bridge.tools())
    return Agent(model, reg, SYSTEM, AgentConfig(max_steps=6)), bridge


if __name__ == "__main__":
    server = StdioServerParameters(command=sys.executable, args=[str(Path(__file__).with_name("brightline_mcp.py"))],
                                   env={**os.environ})
    agent, bridge = build(model_from_env(), InventoryClient(), server)
    try:
        r = agent.run(" ".join(sys.argv[1:]))
        print(f"[{r.status}] {r.answer}")
    finally:
        bridge.close()
