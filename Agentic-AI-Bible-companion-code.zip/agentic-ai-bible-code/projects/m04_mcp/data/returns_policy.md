# Returns policy (summary)
Unused items can be returned within 30 days of delivery for a full refund to the original payment method.
Faulty items are covered by a two-year warranty; we repair, replace or refund.
Customers pay return shipping unless the item is faulty.
