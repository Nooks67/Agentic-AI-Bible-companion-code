"""Client for the inventory API: authentication, timeouts, retries on 429/5xx, clear errors."""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request


class APIError(RuntimeError):
    def __init__(self, status: int, message: str):
        super().__init__(f"inventory API {status}: {message}")
        self.status = status


class InventoryClient:
    def __init__(self, base_url: str | None = None, api_key: str | None = None, timeout: float = 5.0,
                 attempts: int = 3, sleep=time.sleep):
        self.base = (base_url or os.environ.get("INVENTORY_URL", "http://127.0.0.1:8765")).rstrip("/")
        self.key = api_key or os.environ["INVENTORY_API_KEY"]   # fail fast if the key is missing
        self.timeout, self.attempts, self.sleep = timeout, attempts, sleep

    def _request(self, method: str, path: str, body: dict | None = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        for attempt in range(1, self.attempts + 1):
            req = urllib.request.Request(self.base + path, data=data, method=method,
                                         headers={"x-api-key": self.key, "content-type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    return json.loads(r.read())
            except urllib.error.HTTPError as e:
                msg = json.loads(e.read() or b"{}").get("error", e.reason)
                if e.code in (429, 502, 503, 504) and attempt < self.attempts:
                    self.sleep(min(10.0, float(e.headers.get("retry-after") or 2 ** attempt)))
                    continue
                raise APIError(e.code, msg) from None
            except (urllib.error.URLError, TimeoutError) as e:
                if attempt == self.attempts:
                    raise APIError(0, f"cannot reach {self.base}: {e}") from None
                self.sleep(2 ** attempt)
        raise AssertionError("unreachable")

    def search(self, q: str) -> list[dict]:
        return self._request("GET", "/v1/products?" + urllib.parse.urlencode({"q": q}))["results"]

    def stock(self, sku: str) -> int:
        return self._request("GET", f"/v1/stock/{urllib.parse.quote(sku)}")["stock"]

    def reserve(self, sku: str, qty: int) -> dict:
        return self._request("POST", "/v1/reservations", {"sku": sku, "qty": qty})
