"""An MCP server that exposes Brightline's inventory and policies to any MCP-capable client.

Run over stdio (how desktop apps and agents usually launch local servers):
  INVENTORY_API_KEY=dev-key python brightline_mcp.py
Requires: mcp >= 2.3 (in v2 the high-level server class is MCPServer).
"""
from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import ToolAnnotations

from inventory_client import APIError, InventoryClient

mcp = MCPServer("brightline-inventory", version="1.0.0",
                instructions="Product search, stock levels and store policies for Brightline Outfitters.")
_client: InventoryClient | None = None


def client() -> InventoryClient:
    global _client
    if _client is None:
        _client = InventoryClient()
    return _client


class Product(BaseModel):
    sku: str
    name: str
    price: float


class Stock(BaseModel):
    sku: str
    in_stock: int


class Reservation(BaseModel):
    reservation: str
    sku: str
    qty: int
    expires_in_s: int


# Typed return values give each tool an output schema, and results arrive as structured_content.
READ_ONLY = ToolAnnotations(read_only_hint=True, open_world_hint=False)


@mcp.tool(annotations=READ_ONLY)
def search_products(query: str) -> list[Product]:
    """Search the catalogue by product name or category (e.g. "tent", "packs")."""
    try:
        return [Product(**p) for p in client().search(query)]
    except APIError as e:
        raise ToolError(str(e)) from None          # ToolError text is shown to the client; other errors are hidden


@mcp.tool(annotations=READ_ONLY)
def check_stock(sku: str) -> Stock:
    """Units in stock for one SKU."""
    try:
        return Stock(sku=sku, in_stock=client().stock(sku))
    except APIError as e:
        raise ToolError(str(e)) from None


@mcp.tool(annotations=ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False))
def reserve_stock(sku: str, qty: int) -> Reservation:
    """Hold units of a product for 15 minutes while a customer completes checkout."""
    if not 1 <= qty <= 5:
        raise ToolError("qty must be between 1 and 5")
    try:
        return Reservation(**client().reserve(sku, qty))
    except APIError as e:
        raise ToolError(str(e)) from None


@mcp.resource("policy://returns", mime_type="text/markdown")
def returns_policy() -> str:
    """Brightline's returns and warranty policy."""
    return (Path(__file__).parent / "data" / "returns_policy.md").read_text()


@mcp.prompt()
def stock_reply(customer: str, product: str) -> str:
    """A prompt template for answering a customer's availability question."""
    return (f"Write a short, friendly reply to {customer} about whether '{product}' is in stock. "
            "Use the check_stock tool first. Do not promise restock dates.")


if __name__ == "__main__":
    mcp.run("stdio")
