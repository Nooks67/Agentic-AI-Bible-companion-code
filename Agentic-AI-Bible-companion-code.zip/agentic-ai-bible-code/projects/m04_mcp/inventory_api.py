"""A small REST API for Brightline's inventory, standing in for any third-party business API.

Endpoints (all need the header  X-API-Key: <key>):
  GET  /v1/products?q=tent        search products
  GET  /v1/stock/<sku>            stock level for one product
  POST /v1/reservations           {"sku": ..., "qty": ...}  hold stock for 15 minutes
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

PRODUCTS = {p["sku"]: p for p in json.loads((Path(__file__).parent / "data" / "products.json").read_text())}


class Limiter:
    """Fixed window: `limit` requests per key per `window` seconds."""
    def __init__(self, limit: int, window: float = 60.0):
        self.limit, self.window, self.hits, self.lock = limit, window, {}, threading.Lock()

    def check(self, key: str) -> float:
        """0 if allowed, otherwise seconds until the window resets."""
        with self.lock:
            now = time.monotonic()
            start, n = self.hits.get(key, (now, 0))
            if now - start >= self.window:
                start, n = now, 0
            if n >= self.limit:
                return self.window - (now - start)
            self.hits[key] = (start, n + 1)
            return 0.0


def make_handler(api_keys: set[str], limiter: Limiter):
    class Handler(BaseHTTPRequestHandler):
        def send(self, code: int, body: dict, headers: dict | None = None) -> None:
            data = json.dumps(body).encode()
            self.send_response(code)
            self.send_header("content-type", "application/json")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def authorised(self) -> bool:
            key = self.headers.get("x-api-key", "")
            if key not in api_keys:
                self.send(401, {"error": "missing or invalid API key"})
                return False
            wait = limiter.check(key)
            if wait:
                self.send(429, {"error": "rate limit exceeded"}, {"retry-after": f"{wait:.0f}"})
                return False
            return True

        def do_GET(self) -> None:
            if not self.authorised():
                return
            url = urlparse(self.path)
            if url.path == "/v1/products":
                q = parse_qs(url.query).get("q", [""])[0].lower()
                hits = [p for p in PRODUCTS.values() if q in p["name"].lower() or q in p["category"]]
                self.send(200, {"results": hits[:10]})
            elif url.path.startswith("/v1/stock/"):
                sku = url.path.rsplit("/", 1)[1]
                p = PRODUCTS.get(sku)
                self.send(200, {"sku": sku, "stock": p["stock"]}) if p else self.send(404, {"error": f"unknown sku {sku}"})
            else:
                self.send(404, {"error": "not found"})

        def do_POST(self) -> None:
            if not self.authorised():
                return
            if self.path != "/v1/reservations":
                return self.send(404, {"error": "not found"})
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))))
                sku, qty = body["sku"], int(body["qty"])
            except (ValueError, KeyError):
                return self.send(400, {"error": "body must be JSON with sku and qty"})
            p = PRODUCTS.get(sku)
            if not p:
                return self.send(404, {"error": f"unknown sku {sku}"})
            if not 0 < qty <= p["stock"]:
                return self.send(409, {"error": f"only {p['stock']} in stock"})
            self.send(201, {"reservation": f"RES-{uuid.uuid4().hex[:6].upper()}", "sku": sku, "qty": qty, "expires_in_s": 900})

        def log_message(self, *args) -> None:
            pass

    return Handler


def serve(port: int = 0, api_keys: set[str] | None = None, limit: int = 60) -> ThreadingHTTPServer:
    srv = ThreadingHTTPServer(("127.0.0.1", port), make_handler(api_keys or {"dev-key"}, Limiter(limit)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    s = serve(8765)
    print("inventory API on http://127.0.0.1:8765  (key: dev-key)")
    threading.Event().wait()
