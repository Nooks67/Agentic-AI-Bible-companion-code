import os
import sys
from pathlib import Path

import pytest
from mcp import StdioServerParameters

from agentlab import AllowList, ScriptedModel, call
from inventory_api import serve
from inventory_client import APIError, InventoryClient

HERE = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def api():
    srv = serve(0, {"test-key"}, limit=1000)
    url = f"http://127.0.0.1:{srv.server_port}"
    os.environ.update(INVENTORY_URL=url, INVENTORY_API_KEY="test-key")
    yield url
    srv.shutdown()


def test_rest_client_auth_and_errors(api):
    c = InventoryClient(api, "test-key")
    assert c.stock("TN-ALPINE2") == 6
    assert [p["sku"] for p in c.search("tent")] == ["TN-ALPINE2", "TN-SOLO1"]
    with pytest.raises(APIError) as e:
        InventoryClient(api, "wrong").stock("TN-ALPINE2")
    assert e.value.status == 401
    with pytest.raises(APIError) as e:
        c.reserve("PK-SUMMIT45", 1)
    assert e.value.status == 409 and "only 0 in stock" in str(e.value)


def test_rate_limit_is_retried_using_retry_after():
    srv = serve(0, {"k"}, limit=2)
    waits = []
    c = InventoryClient(f"http://127.0.0.1:{srv.server_port}", "k", sleep=waits.append, attempts=2)
    c.stock("HL-BEAM"); c.stock("HL-BEAM")
    with pytest.raises(APIError) as e:
        c.stock("HL-BEAM")
    assert e.value.status == 429 and len(waits) == 1 and waits[0] > 0
    srv.shutdown()


def test_mcp_server_in_process(api):
    import asyncio
    import brightline_mcp
    from mcp import Client

    async def go():
        async with Client(brightline_mcp.mcp) as c:
            names = {t.name: t for t in (await c.list_tools()).tools}
            assert set(names) == {"search_products", "check_stock", "reserve_stock"}
            assert names["check_stock"].annotations.read_only_hint is True
            r = await c.call_tool("check_stock", {"sku": "JK-STORM"})
            assert r.structured_content == {"sku": "JK-STORM", "in_stock": 22}
            bad = await c.call_tool("check_stock", {"sku": "NOPE"})
            assert bad.is_error and "unknown sku NOPE" in bad.content[0].text
            res = await c.read_resource("policy://returns")
            assert "30 days" in res.contents[0].text
            p = await c.get_prompt("stock_reply", {"customer": "Ana", "product": "Beam 400"})
            assert "check_stock" in p.messages[0].content.text
    asyncio.run(go())


def test_agent_uses_rest_and_mcp_tools_over_stdio(api):
    from agent_inventory import build
    server = StdioServerParameters(command=sys.executable, args=[str(HERE / "brightline_mcp.py")],
                                   env={**os.environ}, cwd=str(HERE))
    model = ScriptedModel([[call("inv_search_products", query="tent")],
                           [call("inv_check_stock", sku="TN-SOLO1"), call("product_details", sku="TN-SOLO1")],
                           [call("inv_reserve_stock", sku="TN-SOLO1", qty=1)],
                           "The Solo 1P Ultralight Tent ($349) has 3 in stock. I have asked a colleague to hold one."])
    agent, bridge = build(model, InventoryClient(api, "test-key"), server, approver=AllowList({}))
    try:
        res = agent.run("Do you have a one-person tent?")
        tools = {t.name: t for t in agent.tools.tools.values()}
        assert tools["inv_check_stock"].risk == "read" and tools["inv_reserve_stock"].risk == "external"
        results = [m.content for m in res.messages if m.role == "tool"]
        assert '"in_stock": 3' in results[1] and '"price": 349.0' in results[2]
        assert "approval denied" in results[3]          # reserving changes inventory: blocked without approval
        assert res.status == "done"
    finally:
        bridge.close()
