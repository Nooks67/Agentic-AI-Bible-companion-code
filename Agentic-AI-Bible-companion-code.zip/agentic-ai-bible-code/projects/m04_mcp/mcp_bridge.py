"""Use tools from any MCP server inside an agentlab agent.

The MCP client is asynchronous; agentlab tools are plain functions. The bridge runs the
client on a background event loop and wraps each remote tool as a local Tool.
"""
from __future__ import annotations

import asyncio
import json
import sys
import threading
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from mcp import Client  # noqa: E402

from agentlab.tools import Tool  # noqa: E402


class MCPBridge:
    def __init__(self, server: Any, prefix: str = "", timeout: float = 20.0):
        """server: a StdioServerParameters, a URL, or (in tests) an MCPServer instance."""
        self.prefix, self.timeout = prefix, timeout
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self.loop.run_forever, daemon=True).start()
        ready = threading.Event()
        self._session = asyncio.run_coroutine_threadsafe(self._hold(server, ready), self.loop)
        if not ready.wait(timeout):
            raise TimeoutError("MCP server did not start in time")
        if self._session.done():            # connecting failed: surface the real error
            self._session.result()

    async def _hold(self, server: Any, ready: threading.Event) -> None:
        # The client must be opened and closed in the same task, so one task holds it for the bridge's lifetime.
        self._closing = asyncio.Event()
        try:
            async with Client(server) as client:
                self.client = client
                ready.set()
                await self._closing.wait()
        finally:
            ready.set()

    def _run(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(self.timeout)

    def tools(self) -> list[Tool]:
        out = []
        for t in self._run(self.client.list_tools()).tools:
            read_only = bool(t.annotations and t.annotations.read_only_hint)
            out.append(Tool(name=self.prefix + t.name, description=t.description or t.name,
                            fn=self._caller(t.name), parameters=t.input_schema,
                            risk="read" if read_only else "external", timeout=self.timeout))
        return out

    def _caller(self, name: str):
        def fn(**arguments: Any) -> str:
            result = self._run(self.client.call_tool(name, arguments))
            text = "\n".join(c.text for c in result.content if getattr(c, "type", "") == "text")
            if result.is_error:
                raise RuntimeError(text or "MCP tool error")
            return json.dumps(result.structured_content) if result.structured_content is not None else text
        return fn

    def read(self, uri: str) -> str:
        return "\n".join(c.text for c in self._run(self.client.read_resource(uri)).contents)

    def close(self) -> None:
        self.loop.call_soon_threadsafe(self._closing.set)
        self._session.result(self.timeout)
        self.loop.call_soon_threadsafe(self.loop.stop)
