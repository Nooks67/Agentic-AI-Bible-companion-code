"""Generate an OpenAPI 3.1 description of the lead service from its Pydantic models.

No-code assistant builders and workflow tools can import this file to call the service as an "action".
  python make_openapi.py > openapi.json
"""
import json

from lead_service import Assessment, Lead


def openapi(server_url: str = "https://leads.brightline.example") -> dict:
    result = {"type": "object", "properties": {
        **Assessment.model_json_schema()["properties"],
        "route": {"type": "string", "enum": ["sales", "support", "review", "discard", "duplicate"]},
        "needs_approval": {"type": "boolean"},
        "injection_flag": {"type": "boolean"},
    }, "required": ["route", "needs_approval"]}
    return {
        "openapi": "3.1.0",
        "info": {"title": "Brightline lead assessment", "version": "1.0.0",
                 "description": "Qualifies inbound business leads. Replies are drafts for human approval."},
        "servers": [{"url": server_url}],
        "components": {"securitySchemes": {"bearer": {"type": "http", "scheme": "bearer"}},
                       "schemas": {"Lead": Lead.model_json_schema(), "AssessmentResult": result}},
        "security": [{"bearer": []}],
        "paths": {
            "/v1/assess-lead": {"post": {
                "operationId": "assessLead",
                "summary": "Assess one inbound lead and say how to route it",
                "requestBody": {"required": True, "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Lead"}}}},
                "responses": {
                    "200": {"description": "Routing decision", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/AssessmentResult"}}}},
                    "401": {"description": "Missing or wrong bearer token"},
                    "422": {"description": "Invalid lead fields"},
                    "503": {"description": "AI step unavailable; route to review"}}}},
            "/healthz": {"get": {"operationId": "health", "summary": "Liveness check", "security": [],
                                 "responses": {"200": {"description": "Service is up"}}}},
        },
    }


if __name__ == "__main__":
    print(json.dumps(openapi(), indent=1))
