"""E2E helpers: the lead service with a scripted model, and an approvals queue stub that records requests."""
import json, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, "/home/claude/agentbook/code/projects/m05_automation")
sys.path.insert(0, "/home/claude/agentbook/code")
from agentlab import ScriptedModel
from lead_service import serve

GOOD = {"intent": "bulk_order", "team_size": 40, "urgency": "medium", "fit_score": 85,
        "reply_draft": "Thanks for reaching out! A colleague will send options for your team. Brightline Business Team"}
SUPPORT = {"intent": "support", "team_size": None, "urgency": "low", "fit_score": 10, "reply_draft": "Thanks, our order desk will help. Brightline Business Team"}
serve(ScriptedModel([json.dumps(GOOD), json.dumps(SUPPORT)]), "e2e-token-123", port=8787)

class Approvals(BaseHTTPRequestHandler):
    def do_POST(self):
        body = self.rfile.read(int(self.headers["content-length"]))
        with open("approvals.log", "a") as f:
            f.write(body.decode() + "\n")
        self.send_response(201); self.send_header("content-type", "application/json"); self.end_headers()
        self.wfile.write(b'{"queued": true}')
    def log_message(self, *a): pass
srv = ThreadingHTTPServer(("127.0.0.1", 8788), Approvals)
threading.Thread(target=srv.serve_forever, daemon=True).start()
print("stubs ready", flush=True)
threading.Event().wait()
