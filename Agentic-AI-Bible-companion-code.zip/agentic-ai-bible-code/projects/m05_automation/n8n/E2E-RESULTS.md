# n8n end-to-end check (22 October 2026)

Environment: n8n 2.44.6 on Node.js 24.22, SQLite, `N8N_LISTEN_ADDRESS=127.0.0.1`.
Lead service: `lead_service.py` with a scripted model (`e2e_stubs.py`), approvals queue stub on port 8788.

Steps: `n8n import:credentials --input=credentials.json`, `n8n import:workflow --input=lead_intake.workflow.json`,
`n8n publish:workflow --id=<id>`, `n8n start`, then POST to `/webhook/brightline-lead`.

| Request | Response | Approval queue |
|---|---|---|
| School, 40 students | 200 `{"status":"received","route":"sales"}` | 1 entry with reply draft |
| Damaged order question | 200 `{"status":"received","route":"support"}` | none |
| Invalid email (service returns 422) | 202 `{"status":"received","route":"review"}` after retries (4.1 s) | none |
