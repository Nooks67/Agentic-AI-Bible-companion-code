"""Capstone: the Brightline Support Copilot.

One request flows through:
  1. triage      structured classification (Module II); spam stops here
  2. agent loop  order tools (Module III) + policy retrieval (Module VI) behind guardrails (Module X)
  3. checks      every policy citation must match a retrieved source, or the answer is withheld and escalated
  4. records     trace, audit log, metrics (Module IX); served over HTTP by the Module XI service

  python copilot.py --from lee@example.com "Can I return the jacket from BL-10301? It hasn't arrived."
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (ROOT, ROOT / "projects" / "m02_triage", ROOT / "projects" / "m03_orderdesk",
          ROOT / "projects" / "m06_rag", ROOT / "projects" / "m10_guardrails"):
    sys.path.insert(0, str(p))

from agentlab import Agent, AgentConfig, ChatModel, IdempotencyLedger, Message, Tracer, model_from_env, tool  # noqa: E402
from agentlab.agent import RunResult  # noqa: E402
from agentlab.llm import Usage  # noqa: E402
from agentlab.memory import LongTermMemory  # noqa: E402
from agentlab.rag import Chunk, check_citations  # noqa: E402
from guardrails import build_guarded  # noqa: E402
from orderdesk import CarrierAPI, OrderDB, build_tools  # noqa: E402
from policy_assistant import build_index  # noqa: E402
from triage import guard as triage_guard, triage_one  # noqa: E402

HERE = Path(__file__).parent

SYSTEM = """You are Brightline Outfitters' support copilot. You help only the customer who wrote in.
Tools: lookup_order, track_shipment, create_return (a staff member approves), search_policies, escalate.
- Check order data with tools before answering; quote dates and statuses exactly.
- For any policy statement (returns, refunds, shipping, warranty, accounts), call search_policies first and cite the
  source id in square brackets after the sentence, e.g. [returns#1]. Do not cite order data.
- Never promise refunds, discounts or delivery dates that the tools did not give you.
- If you cannot help safely, call escalate."""


@dataclass
class CopilotResult:
    status: str                    # answered | escalated | discarded | withheld | stopped
    answer: str
    ticket: dict | None = None
    run: RunResult | None = None
    problems: list[str] = field(default_factory=list)


class Copilot:
    def __init__(self, model: ChatModel, workdir: Path, human=lambda tool, args, reason: False,
                 db: OrderDB | None = None, carrier: CarrierAPI | None = None, memory: LongTermMemory | None = None):
        self.model, self.workdir, self.human = model, workdir, human
        self.db, self.carrier = db or OrderDB(), carrier or CarrierAPI()
        self.memory = memory or LongTermMemory()
        self.index = build_index()
        workdir.mkdir(parents=True, exist_ok=True)

    def _policy_tool(self, seen: dict[str, Chunk]):
        index = self.index

        @tool
        def search_policies(query: str) -> list[dict]:
            """Search Brightline's policy pages. Returns passages with ids to cite.

            Args:
                query: What you need to know, in a few words.
            """
            hits = index.retriever.search(query, k=3)
            for c, _ in hits:
                seen[c.id] = c
            return [{"id": c.id, "text": c.text} for c, _ in hits]
        return search_policies

    def handle(self, sender: str, message: str, run_id: str | None = None) -> CopilotResult:
        email = {"from": sender, "subject": "", "body": message}
        try:
            ticket, _ = triage_one(self.model, email)
            ticket = triage_guard(ticket, email)
        except Exception as e:                          # triage failure must not drop the customer
            ticket = None
            Tracer(self.workdir / "trace.jsonl").event("triage_failed", error=type(e).__name__)
        if ticket and ticket.category == "spam":
            return CopilotResult("discarded", "", ticket.model_dump())

        seen: dict[str, Chunk] = {}
        escalations: list[dict] = []
        order_tools = build_tools(sender, self.db, self.carrier, IdempotencyLedger(str(self.workdir / "actions.db")), escalations)
        registry = build_guarded(order_tools + [self._policy_tool(seen)], HERE / "governance" / "policy.json", self.human,
                                 self.workdir / "audit.jsonl", {"customer_email": sender, "session": run_id})
        prefs = self.memory.recall(sender, message + " prefer", k=2)
        system = SYSTEM + (f"\nKnown customer preferences: {'; '.join(m.text for m in prefs)}" if prefs else "")
        if ticket:
            system += f"\nTriage: {ticket.category}, priority {ticket.priority}."
        agent = Agent(self.model, registry, system, AgentConfig(max_steps=8, max_tool_calls=12, max_seconds=90),
                      tracer=Tracer(self.workdir / "trace.jsonl", run_id))
        run = agent.run(message, run_id)
        tk = ticket.model_dump() if ticket else None
        if run.status != "done":
            return CopilotResult("stopped", "Sorry, I couldn't finish this. A colleague will follow up.", tk, run)
        if escalations:
            return CopilotResult("escalated", run.answer, tk, run)
        if re.search(r"\[[\w.-]+#\d+\]", run.answer):
            check = check_citations(self._policy_part(run.answer), [(c, 1.0) for c in seen.values()])
            if not check["ok"]:
                escalations.append({"customer": sender, "reason": "answer failed citation check"})
                return CopilotResult("withheld", "Thanks for your patience. A colleague will confirm the details shortly.",
                                     tk, run, check["problems"])
        return CopilotResult("answered", run.answer, tk, run)

    @staticmethod
    def _policy_part(answer: str) -> str:
        """Only sentences with citations are policy claims; order facts were checked by the tools themselves."""
        sents = re.split(r"(?<=[.!?])\s+", answer.strip())
        return " ".join(s for s in sents if "[" in s)


def service_factory(workdir: Path, model_factory=model_from_env, human=lambda tool, args, reason: False):
    """Adapter for the Module XI server: payload -> callable(message) -> RunResult."""
    def factory(payload: dict):
        def run(message: str) -> RunResult:
            res = Copilot(model_factory(), workdir, human).handle(payload["customer_email"], message)
            if res.run:
                res.run.answer = res.answer
                return res.run
            return RunResult(res.status, res.answer, 0, 0, Usage(), 0.0)
        return run
    return factory


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("message")
    ap.add_argument("--from", dest="sender", required=True)
    a = ap.parse_args()
    def console(tool_name, args, reason):
        return input(f"Approve {tool_name} {json.dumps(args)}? ({reason}) [y/N] ").lower() == "y"
    r = Copilot(model_from_env(), Path(".copilot"), console).handle(a.sender, a.message)
    print(f"[{r.status}] {r.answer}")
