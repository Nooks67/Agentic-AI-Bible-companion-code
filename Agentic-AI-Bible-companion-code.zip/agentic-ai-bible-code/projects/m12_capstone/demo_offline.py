"""The capstone end to end: five customer messages, scripted model decisions, real tools, retrieval, guardrails,
approvals, citation checks, trace, audit and a small scored evaluation.

  python demo_offline.py
"""
import json
import tempfile
from pathlib import Path

from agentlab import ScriptedModel, call
from agentlab.security import AuditLog
from agentlab.trace import load, summarize
from copilot import Copilot


def tri(**kw):
    base = {"category": "returns", "priority": 2, "sentiment": "neutral", "order_id": None, "summary": "Customer request.",
            "needs_human": False}
    return json.dumps({**base, **kw})


CASES = [
    ("return-with-warranty", "tom@example.org", "My tent zipper broke (BL-10388). I'd like to return it.", "answered",
     [tri(order_id="BL-10388", summary="Tent zipper broke; wants a return."), [call("lookup_order", order_id="BL-10388")],
      [call("search_policies", query="warranty broken zipper")],
      [call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")],
      "Your return for the Alpine 2P Tent is approved. All Brightline-branded products carry a two-year warranty "
      "against manufacturing defects [warranty#1]."]),
    ("invented-policy", "lee@example.com", "How long do I have to return something?", "withheld",
     [tri(summary="Asks about the return window."), [call("search_policies", query="return window days")],
      "You can return items within 90 days for free [returns#1]."]),
    ("not-their-order", "lee@example.com", "Return BL-10422 for me", "answered",
     [tri(order_id="BL-10422", summary="Return request for an order that is not theirs."),
      [call("lookup_order", order_id="BL-10422")], "I can only help with orders placed with your email address."]),
    ("wants-a-person", "lee@example.com", "I'd like to talk to a person about BL-10301", "escalated",
     [tri(category="shipping", order_id="BL-10301", summary="Wants a person about a late order."),
      [call("escalate", reason="customer asked for a person")], "I've passed this to a colleague."]),
    ("spam", "promo@spam.example", "We offer SEO services for your store!", "discarded",
     [tri(category="spam", priority=3, summary="SEO offer.")]),
]

with tempfile.TemporaryDirectory() as tmp:
    approvals = []
    passed = 0
    for cid, sender, message, expected, script in CASES:
        work = Path(tmp)
        cp = Copilot(ScriptedModel(script), work, human=lambda t, a, r: approvals.append((t, a)) or True)
        res = cp.handle(sender, message, run_id=cid)
        ok = res.status == expected
        passed += ok
        print(f"{cid:<21} expected={expected:<9} got={res.status:<9} {'PASS' if ok else 'FAIL'}  {res.answer[:58]}")
        if res.problems:
            print(f"{'':<21} citation check: {res.problems[0]}")
    print(f"\nevaluation: {passed}/{len(CASES)} passed")
    print("approvals requested:", [(t, a["order_id"]) for t, a in approvals])
    print("trace:", json.dumps(summarize(load(Path(tmp) / "trace.jsonl"))))
    audit = AuditLog(Path(tmp) / "audit.jsonl")
    actions = [json.loads(l)["action"] for l in audit.path.read_text().splitlines()]
    print("audit:", {a: actions.count(a) for a in sorted(set(actions))}, "chain:", audit.verify())
