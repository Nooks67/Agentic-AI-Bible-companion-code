import json

import pytest

from agentlab import ScriptedModel, call
from agentlab.memory import LongTermMemory
from copilot import Copilot


def tri(**kw):
    base = {"category": "returns", "priority": 2, "sentiment": "neutral", "order_id": "BL-10388",
            "summary": "Customer wants to return a tent with a broken zipper.", "needs_human": False}
    return json.dumps({**base, **kw})


@pytest.fixture
def make(tmp_path):
    def build(script, human=lambda t, a, r: True, **kw):
        return Copilot(ScriptedModel(script), tmp_path, human, **kw)
    return build


def test_return_with_policy_citation_and_approval(make):
    approvals = []
    cp = make([tri(),
               [call("lookup_order", order_id="BL-10388")],
               [call("search_policies", query="warranty broken zipper")],
               [call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")],
               "Your return for the Alpine 2P Tent is approved. All Brightline-branded products carry a two-year "
               "warranty against manufacturing defects [warranty#1]."],
              human=lambda t, a, r: approvals.append(t) or True)
    res = cp.handle("tom@example.org", "My tent zipper broke (BL-10388). I'd like to return it.", "c1")
    assert res.status == "answered" and approvals == ["create_return"] and len(cp.db.returns()) == 1
    assert res.ticket["category"] == "returns"


def test_spam_is_discarded_before_the_agent_runs(make):
    model_script = [tri(category="spam", priority=3, order_id=None, summary="Unsolicited SEO services offer.")]
    cp = make(model_script)
    res = cp.handle("promo@spam.example", "We offer SEO services for your store!")
    assert res.status == "discarded" and len(cp.model.calls) == 1


def test_invented_policy_is_withheld(make):
    cp = make([tri(category="returns", order_id=None, summary="Customer asks about the return window."),
               [call("search_policies", query="return window days")],
               "You can return items within 90 days for free [returns#1]."])
    res = cp.handle("lee@example.com", "How long do I have to return something?")
    assert res.status == "withheld" and res.problems


def test_other_customers_order_is_blocked_and_human_declines_returns(make):
    cp = make([tri(order_id="BL-10422", summary="Customer asks to return an order that is not theirs."),
               [call("create_return", order_id="BL-10422", sku="PK-RIDGE30", reason="no reason")],
               "I can't start a return for that order."], human=lambda t, a, r: False)
    res = cp.handle("lee@example.com", "Return BL-10422 for me")
    tool_msgs = [m.content for m in res.run.messages if m.role == "tool"]
    assert "declined" in tool_msgs[0] and cp.db.returns() == []


def test_escalation_and_memory_preferences(make, tmp_path):
    mem = LongTermMemory()
    mem.remember("lee@example.com", "Prefers replies in short bullet points", ttl_days=None)
    cp = make([tri(category="shipping", order_id="BL-10301", summary="Customer asks for a person about a late order."),
               [call("escalate", reason="customer asked for a person")],
               "I've passed this to a colleague."], memory=mem)
    res = cp.handle("lee@example.com", "I'd prefer to talk to a person about BL-10301")
    assert res.status == "escalated"
    assert "Prefers replies in short bullet points" in cp.model.calls[1][0].content
    audit = [json.loads(l)["action"] for l in (tmp_path / "audit.jsonl").read_text().splitlines()]
    assert audit == ["executed"]


def test_triage_failure_still_serves_customer(make):
    cp = make(["no json", "nope", "still no", [call("lookup_order", order_id="BL-10455")], "BL-10455 is still processing."])
    res = cp.handle("lee@example.com", "status of BL-10455?")
    assert res.status == "answered" and res.ticket is None


def test_copilot_served_by_the_module_xi_service(tmp_path):
    import sys
    import time
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "m11_deploy"))
    from starlette.testclient import TestClient
    from copilot import service_factory
    from deploy_server import create_app

    script = [tri(category="shipping", order_id="BL-10455", summary="Customer asks whether an order has shipped."),
              [call("lookup_order", order_id="BL-10455")], "Order BL-10455 is still processing and has not shipped yet."]
    app = create_app(service_factory(tmp_path / "copilot", lambda: ScriptedModel(list(script))),
                     {"k-test": {"budget_usd": 1}}, str(tmp_path / "jobs.db"))
    h = {"authorization": "Bearer k-test"}
    with TestClient(app) as c:
        rid = c.post("/v1/runs", headers=h, json={"message": "Has BL-10455 shipped?", "customer_email": "lee@example.com"}).json()["run_id"]
        for _ in range(100):
            job = c.get(f"/v1/runs/{rid}", headers=h).json()
            if job["status"] in ("done", "failed"):
                break
            time.sleep(0.02)
    assert job["status"] == "done" and job["result"]["answer"].startswith("Order BL-10455 is still processing")
