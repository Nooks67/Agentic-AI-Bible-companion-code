"""Module XI project: serve an agent in production with a job queue, cost limits, logs, metrics and health checks.

  AGENT_API_KEYS='{"key-ops-1": {"name": "ops", "budget_usd": 25}}' uvicorn deploy_server:app --port 8080
"""
from __future__ import annotations

import json
import logging
import os
import queue
import sqlite3
import sys
import threading
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Callable

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from agentlab.agent import RunResult  # noqa: E402
from agentlab.resilience import TokenBucket  # noqa: E402

log = logging.getLogger("agent-service")


class JsonFormatter(logging.Formatter):
    def format(self, r: logging.LogRecord) -> str:
        return json.dumps({"ts": round(r.created, 3), "level": r.levelname, "msg": r.getMessage(), **getattr(r, "extra", {})})


def setup_logging() -> None:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(JsonFormatter())
    log.handlers[:] = [h]
    log.setLevel(logging.INFO)


class Jobs:
    """Durable job table. Jobs left 'running' by a crash are re-queued at startup."""

    def __init__(self, path: str):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.lock = threading.Lock()
        self.db.execute("""CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, api_key TEXT, idem TEXT, payload TEXT,
            status TEXT, result TEXT, cost REAL DEFAULT 0, created REAL, finished REAL)""")
        self.db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idem_idx ON jobs(api_key, idem)")
        self.db.commit()

    def add(self, key: str, idem: str | None, payload: dict) -> tuple[str, bool]:
        with self.lock, self.db:
            if idem:
                row = self.db.execute("SELECT id FROM jobs WHERE api_key=? AND idem=?", (key, idem)).fetchone()
                if row:
                    return row[0], False
            jid = uuid.uuid4().hex[:12]
            self.db.execute("INSERT INTO jobs (id, api_key, idem, payload, status, created) VALUES (?,?,?,?,?,?)",
                            (jid, key, idem, json.dumps(payload), "queued", time.time()))
            return jid, True

    def set(self, jid: str, status: str, result: dict | None = None, cost: float = 0.0) -> None:
        with self.lock, self.db:
            self.db.execute("UPDATE jobs SET status=?, result=?, cost=?, finished=? WHERE id=?",
                            (status, json.dumps(result) if result else None, cost,
                             time.time() if status in ("done", "failed") else None, jid))

    def get(self, jid: str) -> dict | None:
        with self.lock:
            row = self.db.execute("SELECT id, api_key, payload, status, result, cost FROM jobs WHERE id=?", (jid,)).fetchone()
        if not row:
            return None
        return {"id": row[0], "api_key": row[1], "payload": json.loads(row[2]), "status": row[3],
                "result": json.loads(row[4]) if row[4] else None, "cost_usd": round(row[5], 6)}

    def spent(self, key: str) -> float:
        with self.lock:
            return self.db.execute("SELECT COALESCE(SUM(cost),0) FROM jobs WHERE api_key=?", (key,)).fetchone()[0]

    def requeue_interrupted(self) -> list[str]:
        with self.lock, self.db:
            ids = [r[0] for r in self.db.execute("SELECT id FROM jobs WHERE status IN ('queued','running')")]
            self.db.execute("UPDATE jobs SET status='queued' WHERE status='running'")
            return ids


class Metrics:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.runs: dict[str, int] = {}
        self.seconds = 0.0
        self.tokens = 0
        self.cost = 0.0

    def observe(self, status: str, seconds: float, tokens: int, cost: float) -> None:
        with self.lock:
            self.runs[status] = self.runs.get(status, 0) + 1
            self.seconds += seconds; self.tokens += tokens; self.cost += cost

    def prometheus(self, queue_depth: int) -> str:
        lines = ["# TYPE agent_runs_total counter"]
        lines += [f'agent_runs_total{{status="{s}"}} {n}' for s, n in sorted(self.runs.items())]
        lines += ["# TYPE agent_run_seconds_sum counter", f"agent_run_seconds_sum {self.seconds:.3f}",
                  "# TYPE agent_tokens_total counter", f"agent_tokens_total {self.tokens}",
                  "# TYPE agent_cost_usd_total counter", f"agent_cost_usd_total {self.cost:.6f}",
                  "# TYPE agent_queue_depth gauge", f"agent_queue_depth {queue_depth}"]
        return "\n".join(lines) + "\n"


AgentFactory = Callable[[dict], Callable[[str], RunResult]]   # payload -> (message -> RunResult)


def create_app(agent_factory: AgentFactory, api_keys: dict[str, dict], db_path: str = "jobs.db",
               workers: int = 2, max_cost_per_run: float = 0.05, requests_per_minute: int = 30) -> Starlette:
    jobs, metrics, q = Jobs(db_path), Metrics(), queue.Queue()
    buckets = {k: TokenBucket(rate=requests_per_minute / 60, capacity=requests_per_minute) for k in api_keys}
    stop = threading.Event()
    threads: list[threading.Thread] = []

    def worker() -> None:
        while not stop.is_set():
            try:
                jid = q.get(timeout=0.2)
            except queue.Empty:
                continue
            job = jobs.get(jid)
            jobs.set(jid, "running")
            t0 = time.perf_counter()
            try:
                result = agent_factory({**job["payload"], "max_cost_usd": max_cost_per_run})(job["payload"]["message"])
                out = {"status": result.status, "answer": result.answer, "steps": result.steps}
                jobs.set(jid, "done", out, result.cost_usd)
                tokens = result.usage.input_tokens + result.usage.output_tokens
                metrics.observe(result.status, time.perf_counter() - t0, tokens, result.cost_usd)
                log.info("run finished", extra={"extra": {"job": jid, "status": result.status, "steps": result.steps,
                                                          "cost_usd": round(result.cost_usd, 6), "tokens": tokens}})
            except Exception as e:      # never let one bad job kill the worker
                jobs.set(jid, "failed", {"error": f"{type(e).__name__}"})
                metrics.observe("failed", time.perf_counter() - t0, 0, 0.0)
                log.error("run failed", extra={"extra": {"job": jid, "error": f"{type(e).__name__}: {e}"}})
            finally:
                q.task_done()

    def auth(request: Request) -> str | None:
        h = request.headers.get("authorization", "")
        key = h.removeprefix("Bearer ").strip()
        return key if key in api_keys else None

    async def create_run(request: Request):
        key = auth(request)
        if not key:
            return JSONResponse({"error": "invalid API key"}, 401)
        if not buckets[key].try_acquire():
            return JSONResponse({"error": "rate limit"}, 429, headers={"retry-after": "2"})
        if jobs.spent(key) >= api_keys[key].get("budget_usd", 0):
            return JSONResponse({"error": "budget exhausted for this key"}, 402)
        try:
            body = await request.json()
            message, email = str(body["message"]).strip(), str(body["customer_email"]).strip()
        except (ValueError, KeyError, TypeError):
            return JSONResponse({"error": "body must be JSON with message and customer_email"}, 422)
        if not 1 <= len(message) <= 4000:
            return JSONResponse({"error": "message must be 1-4000 characters"}, 422)
        jid, new = jobs.add(key, request.headers.get("idempotency-key"), {"message": message, "customer_email": email})
        if new:
            q.put(jid)
        return JSONResponse({"run_id": jid, "status": jobs.get(jid)["status"]}, 202 if new else 200)

    async def get_run(request: Request):
        key = auth(request)
        job = jobs.get(request.path_params["run_id"])
        if not key or not job or job["api_key"] != key:      # do not reveal whether someone else's run exists
            return JSONResponse({"error": "not found"}, 404)
        return JSONResponse({k: job[k] for k in ("id", "status", "result", "cost_usd")})

    async def healthz(request: Request):
        return JSONResponse({"status": "ok"})

    async def readyz(request: Request):
        alive = sum(t.is_alive() for t in threads)
        ok = alive == workers
        try:
            jobs.spent("")
        except sqlite3.Error:
            ok = False
        return JSONResponse({"ready": ok, "workers_alive": alive, "queue_depth": q.qsize()}, 200 if ok else 503)

    async def metrics_ep(request: Request):
        return PlainTextResponse(metrics.prometheus(q.qsize()))

    @asynccontextmanager
    async def lifespan(app: Starlette):
        setup_logging()
        for jid in jobs.requeue_interrupted():
            q.put(jid)
        for _ in range(workers):
            t = threading.Thread(target=worker, daemon=True)
            t.start()
            threads.append(t)
        log.info("service started", extra={"extra": {"workers": workers}})
        yield
        stop.set()                      # graceful shutdown: finish current jobs, leave the rest queued
        for t in threads:
            t.join(timeout=30)

    app = Starlette(routes=[Route("/v1/runs", create_run, methods=["POST"]), Route("/v1/runs/{run_id}", get_run),
                            Route("/healthz", healthz), Route("/readyz", readyz), Route("/metrics", metrics_ep)],
                    lifespan=lifespan)
    app.state.jobs, app.state.queue = jobs, q
    return app


def production_app() -> Starlette:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "m03_orderdesk"))
    from agentlab import AgentConfig, AllowList, model_from_env
    from agentlab.agent import Pricing
    from orderdesk import make_agent

    pricing = Pricing(float(os.environ.get("PRICE_IN_PER_M", "0")), float(os.environ.get("PRICE_OUT_PER_M", "0")))

    def factory(payload: dict):
        agent = make_agent(payload["customer_email"], model_from_env(), AllowList({"escalate": lambda a: True}),
                           Path(os.environ.get("AGENT_WORKDIR", "/data/agent")))
        agent.pricing = pricing
        agent.config = AgentConfig(max_steps=8, max_tool_calls=12, max_seconds=60, max_cost_usd=payload["max_cost_usd"])
        return agent.run
    return create_app(factory, json.loads(os.environ["AGENT_API_KEYS"]), os.environ.get("JOBS_DB", "/data/jobs.db"),
                      workers=int(os.environ.get("WORKERS", "2")),
                      max_cost_per_run=float(os.environ.get("MAX_COST_PER_RUN", "0.05")))


if os.environ.get("AGENT_API_KEYS"):
    app = production_app()
