"""Serve the real order-desk agent over HTTP with uvicorn; scripted model decisions stand in for a provider.

  python demo_offline.py
"""
import json
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

import uvicorn

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "m03_orderdesk"))
from orderdesk import make_agent  # noqa: E402

from agentlab import AgentConfig, AllowList, ScriptedModel, call  # noqa: E402
from agentlab.agent import Pricing  # noqa: E402
from deploy_server import create_app  # noqa: E402

SCRIPTS = {   # decisions a model would make for each demo message
    "status": [[call("lookup_order", order_id="BL-10301")], [call("track_shipment", order_id="BL-10301")],
               "Your order is held at the regional hub because the address could not be verified."],
    "return": [[call("create_return", order_id="BL-10388", sku="TN-ALPINE2", reason="zipper broke")],
               "I've asked a colleague to approve your return."],
}
KEY = "demo-key-0123456789abcdefghij"
WORK = Path(tempfile.mkdtemp())


def factory(payload):
    script = SCRIPTS["return" if "return" in payload["message"].lower() else "status"]
    agent = make_agent(payload["customer_email"], ScriptedModel(script), AllowList({"escalate": lambda a: True}),
                       WORK / payload["customer_email"])
    agent.pricing = Pricing(3.0, 15.0)              # illustrative prices, USD per million tokens
    agent.config = AgentConfig(max_steps=8, max_tool_calls=12, max_seconds=60, max_cost_usd=payload["max_cost_usd"])
    return agent.run


def req(method, path, body=None, headers=None):
    r = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body else None,
                               headers={"authorization": f"Bearer {KEY}", "content-type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(r, timeout=5) as resp:
            return resp.status, json.loads(resp.read()) if "json" in resp.headers["content-type"] else resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


app = create_app(factory, {KEY: {"name": "support-inbox", "budget_usd": 0.003}}, str(WORK / "jobs.db"), workers=2)
server = uvicorn.Server(uvicorn.Config(app, port=8765, log_level="warning"))
threading.Thread(target=server.run, daemon=True).start()
while not server.started:
    time.sleep(0.05)
BASE = "http://127.0.0.1:8765"

runs = []
for msg, email, idem in [("Where is my order BL-10301?", "lee@example.com", "ticket-501"),
                         ("I want to return my tent from BL-10388", "tom@example.org", "ticket-502"),
                         ("Where is my order BL-10301?", "lee@example.com", "ticket-501")]:
    code, body = req("POST", "/v1/runs", {"message": msg, "customer_email": email}, {"idempotency-key": idem})
    print(f"POST {idem} -> {code} {body}")
    runs.append(body["run_id"])
time.sleep(0.5)
for rid in dict.fromkeys(runs):
    print("GET", rid, "->", req("GET", f"/v1/runs/{rid}")[1])
print("POST over budget ->", req("POST", "/v1/runs", {"message": "hi", "customer_email": "lee@example.com"}))
print(req("GET", "/metrics")[1])
server.should_exit = True
time.sleep(0.5)
