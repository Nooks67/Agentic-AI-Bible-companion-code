import json
import time

import pytest
from starlette.testclient import TestClient

from agentlab import Usage
from agentlab.agent import RunResult
from deploy_server import create_app

KEYS = {"k-ops": {"name": "ops", "budget_usd": 0.10}, "k-other": {"name": "other", "budget_usd": 1}}
H = {"authorization": "Bearer k-ops"}


def fake_factory(payload):
    def run(message):
        if "boom" in message:
            raise RuntimeError("model provider down")
        return RunResult("done", f"echo: {message}", 2, 1, Usage(100, 20), 0.04)
    return run


def wait_done(c, rid, headers=H):
    for _ in range(100):
        r = c.get(f"/v1/runs/{rid}", headers=headers).json()
        if r["status"] in ("done", "failed"):
            return r
        time.sleep(0.02)
    raise AssertionError("job did not finish")


@pytest.fixture
def client(tmp_path):
    app = create_app(fake_factory, KEYS, str(tmp_path / "jobs.db"), workers=2, requests_per_minute=100)
    with TestClient(app) as c:
        yield c


def test_run_lifecycle_and_metrics(client):
    r = client.post("/v1/runs", headers=H, json={"message": "Where is BL-10301?", "customer_email": "lee@example.com"})
    assert r.status_code == 202
    done = wait_done(client, r.json()["run_id"])
    assert done["result"] == {"status": "done", "answer": "echo: Where is BL-10301?", "steps": 2} and done["cost_usd"] == 0.04
    m = client.get("/metrics").text
    assert 'agent_runs_total{status="done"} 1' in m and "agent_tokens_total 120" in m


def test_auth_validation_and_isolation(client):
    assert client.post("/v1/runs", json={"message": "x", "customer_email": "a@b.c"}).status_code == 401
    assert client.post("/v1/runs", headers=H, json={"message": ""}).status_code == 422
    rid = client.post("/v1/runs", headers=H, json={"message": "hi", "customer_email": "a@b.c"}).json()["run_id"]
    assert client.get(f"/v1/runs/{rid}", headers={"authorization": "Bearer k-other"}).status_code == 404


def test_idempotency_key_prevents_duplicate_runs(client):
    h = {**H, "idempotency-key": "ticket-881"}
    a = client.post("/v1/runs", headers=h, json={"message": "hi", "customer_email": "a@b.c"})
    b = client.post("/v1/runs", headers=h, json={"message": "hi", "customer_email": "a@b.c"})
    assert a.status_code == 202 and b.status_code == 200 and a.json()["run_id"] == b.json()["run_id"]


def test_budget_exhaustion_returns_402(client):
    for i in range(3):
        rid = client.post("/v1/runs", headers=H, json={"message": f"m{i}", "customer_email": "a@b.c"}).json()["run_id"]
        wait_done(client, rid)
    assert client.post("/v1/runs", headers=H, json={"message": "more", "customer_email": "a@b.c"}).status_code == 402


def test_failed_job_does_not_kill_workers(client):
    rid = client.post("/v1/runs", headers=H, json={"message": "boom", "customer_email": "a@b.c"}).json()["run_id"]
    assert wait_done(client, rid) == {"id": rid, "status": "failed", "result": {"error": "RuntimeError"}, "cost_usd": 0.0}
    ready = client.get("/readyz").json()
    assert ready["ready"] is True and ready["workers_alive"] == 2


def test_rate_limit(tmp_path):
    app = create_app(fake_factory, KEYS, str(tmp_path / "j.db"), requests_per_minute=2)
    with TestClient(app) as c:
        codes = [c.post("/v1/runs", headers={"authorization": "Bearer k-other"},
                        json={"message": f"m{i}", "customer_email": "a@b.c"}).status_code for i in range(3)]
    assert codes == [202, 202, 429]


def test_interrupted_jobs_resume_after_restart(tmp_path):
    from deploy_server import Jobs
    db = str(tmp_path / "jobs.db")
    jobs = Jobs(db)
    jid, _ = jobs.add("k-ops", None, {"message": "left running", "customer_email": "a@b.c"})
    jobs.set(jid, "running")                            # the old process died here
    with TestClient(create_app(fake_factory, KEYS, db)) as c:
        assert wait_done(c, jid)["result"]["answer"] == "echo: left running"
