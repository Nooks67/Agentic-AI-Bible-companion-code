"""Print the permission matrix, replay the red-team scenarios against the guarded tools and verify the audit log."""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "tests"))
from test_guardrails import POLICY, TOOLS  # noqa: E402  (the same stand-in tools the tests use)

from guardrails import build_guarded, permission_matrix  # noqa: E402
from redteam import SCENARIOS  # noqa: E402

print(permission_matrix(POLICY, [t.name for t in TOOLS]))
with tempfile.TemporaryDirectory() as tmp:
    reviewer = lambda tool, args, reason: tool == "send_email"         # approves emails, declines refunds
    reg = build_guarded(TOOLS, POLICY, reviewer, Path(tmp) / "audit.jsonl",
                        {"customer_email": "lee@example.com", "session": "demo"})
    print()
    for sc in SCENARIOS:
        name, args = sc["call"]
        res = reg.call(name, args)
        print(f"{sc['id']:<22} blocked={not res.ok!s:<5} {res.error}")
    res = reg.call("search_policies", {"query": "returns"})
    print(f"{'injected-search-result':<22} wrapped={res.content.startswith('<untrusted')}")
    log = [json.loads(l) for l in reg.audit.path.read_text().splitlines()]
    print("\naudit entries:", len(log), "| actions:", sorted({e['action'] for e in log}), "| chain:", reg.audit.verify())
