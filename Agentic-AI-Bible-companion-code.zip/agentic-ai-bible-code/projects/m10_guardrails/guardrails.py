"""Module X project: a security, permission and governance layer for any agentlab agent.

GuardedRegistry sits between the agent and its tools. For every call it:
  1. asks the Policy (allow / approve / deny; deny by default),
  2. enforces per-tool rate limits,
  3. gets human approval when the policy says so,
  4. treats outputs of web/email/document tools as untrusted and flags injected instructions,
  5. redacts secrets from results,
  6. writes every decision to a hash-chained audit log.
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from agentlab.resilience import TokenBucket  # noqa: E402
from agentlab.security import AuditLog, Policy, Rule, redact_secrets, scan_injection, wrap_untrusted  # noqa: E402
from agentlab.tools import Tool, ToolRegistry, ToolResult  # noqa: E402

HumanApprover = Callable[[str, dict, str], bool]     # (tool, args, reason) -> approved?


def load_policy(path: str | Path) -> tuple[Policy, dict]:
    raw = json.loads(Path(path).read_text())
    rules = [Rule(r["tool"], r["effect"], r.get("when", {}), r.get("reason", "")) for r in raw["rules"]]
    for r in rules:
        if r.effect not in ("allow", "approve", "deny"):
            raise ValueError(f"bad effect {r.effect!r} in rule for {r.tool}")
    return Policy(rules), raw


@dataclass
class GuardedRegistry(ToolRegistry):
    policy: Policy = field(default_factory=lambda: Policy([]))
    human: HumanApprover = lambda tool, args, reason: False
    audit: AuditLog | None = None
    context: dict = field(default_factory=dict)          # facts about the session the model cannot change
    rate_limits: dict[str, TokenBucket] = field(default_factory=dict)
    untrusted_tools: set[str] = field(default_factory=set)
    actor: str = "agent"

    def _log(self, action: str, **detail) -> None:
        if self.audit:
            self.audit.record(self.actor, action, session=self.context.get("session"), **detail)

    def call(self, name: str, arguments: dict) -> ToolResult:
        effect, reason = self.policy.decide(name, arguments, self.context)
        if effect == "deny":
            self._log("denied", tool=name, args=arguments, reason=reason)
            return ToolResult(False, "", f"not permitted: {reason}. Tell the user what you cannot do and why.")
        bucket = self.rate_limits.get(name)
        if bucket and not bucket.try_acquire():
            self._log("rate_limited", tool=name)
            return ToolResult(False, "", f"rate limit reached for {name}; try again later")
        if effect == "approve":
            ok = self.human(name, arguments, reason)
            self._log("approval", tool=name, args=arguments, approved=ok)
            if not ok:
                return ToolResult(False, "", f"a reviewer declined {name}. Do not retry; tell the user it was not done.")
        # The policy (not the tool's own risk label) made the decision, so skip the base approver.
        saved, self.approver = self.approver, _AlwaysYes()
        try:
            res = super().call(name, arguments)
        finally:
            self.approver = saved
        if res.ok:
            text = redact_secrets(res.content)
            if name in self.untrusted_tools:
                rep = scan_injection(text)
                if rep.suspicious:
                    self._log("injection_flagged", tool=name, patterns=rep.matches)
                text = wrap_untrusted(text, name)
            res = ToolResult(True, text)
        self._log("executed", tool=name, args=arguments, ok=res.ok, error=res.error)
        return res


class _AlwaysYes:
    def approve(self, tool: Tool, arguments: dict) -> bool:
        return True


def build_guarded(tools: list[Tool], policy_path: str | Path, human: HumanApprover, audit_path: str | Path,
                  context: dict) -> GuardedRegistry:
    policy, raw = load_policy(policy_path)
    limits = {t: TokenBucket(rate=v["per_minute"] / 60, capacity=v["per_minute"]) for t, v in raw.get("rate_limits", {}).items()}
    reg = GuardedRegistry(policy=policy, human=human, audit=AuditLog(audit_path), context=context,
                          rate_limits=limits, untrusted_tools=set(raw.get("untrusted_output_tools", [])))
    return reg.add(*tools)


def permission_matrix(policy_path: str | Path, tool_names: list[str]) -> str:
    """Human-readable table for reviewers: what each tool may do and under what condition."""
    policy, raw = load_policy(policy_path)
    lines = [f"Policy version {raw['version']} (owner: {raw['owner']})", "", "| Tool | Effect | Condition | Reason |", "|---|---|---|---|"]
    for name in tool_names:
        rules = [r for r in policy.rules if r.tool in (name, "*")]
        if not rules:
            lines.append(f"| {name} | deny | (no rule: default) | not listed in policy |")
        for r in rules:
            cond = ", ".join(f"{k} {json.dumps(v)}" for k, v in r.when.items()) or "always"
            lines.append(f"| {name} | {r.effect} | {cond} | {r.reason} |")
    return "\n".join(lines)


def review_due(raw_policy: dict, today: str, max_age_days: int = 90) -> bool:
    """Governance check: policies must be reviewed at least every `max_age_days`."""
    t = time.strptime(today, "%Y-%m-%d"); v = time.strptime(raw_policy["version"], "%Y-%m-%d")
    return (time.mktime(t) - time.mktime(v)) / 86400 > max_age_days
