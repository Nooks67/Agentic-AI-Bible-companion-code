"""Retries, timeouts, circuit breaking and rate limiting for anything that talks to the network."""
from __future__ import annotations

import random
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

T = TypeVar("T")


class RetryableError(Exception):
    """Raise (or wrap) errors that are safe to retry: timeouts, 429s, 5xx."""


def retry(fn: Callable[[], T], attempts: int = 4, base: float = 0.5, max_delay: float = 20.0,
          retry_on: tuple[type[BaseException], ...] = (RetryableError, TimeoutError, ConnectionError),
          sleep: Callable[[float], None] = time.sleep, on_retry: Callable[[int, BaseException, float], None] | None = None) -> T:
    """Call fn; on a retryable error wait base*2^n (with full jitter) and try again."""
    for n in range(1, attempts + 1):
        try:
            return fn()
        except retry_on as e:
            if n == attempts:
                raise
            delay = random.uniform(0, min(max_delay, base * 2 ** (n - 1)))
            if on_retry:
                on_retry(n, e, delay)
            sleep(delay)
    raise AssertionError("unreachable")


@dataclass
class CircuitBreaker:
    """Stop calling a failing dependency for `cooldown` seconds after `threshold` consecutive failures."""
    threshold: int = 5
    cooldown: float = 30.0
    failures: int = 0
    opened_at: float | None = None
    clock: Callable[[], float] = time.monotonic

    def call(self, fn: Callable[[], T]) -> T:
        if self.opened_at is not None:
            if self.clock() - self.opened_at < self.cooldown:
                raise RuntimeError("circuit open: dependency recently failing, try later")
            self.opened_at = None          # half-open: allow one trial call
        try:
            result = fn()
        except Exception:
            self.failures += 1
            if self.failures >= self.threshold:
                self.opened_at = self.clock()
            raise
        self.failures = 0
        return result


@dataclass
class TokenBucket:
    """Allow `rate` calls per second on average, bursts up to `capacity`."""
    rate: float
    capacity: float
    tokens: float = field(init=False)
    updated: float = field(init=False)
    clock: Callable[[], float] = time.monotonic
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def __post_init__(self) -> None:
        self.tokens, self.updated = self.capacity, self.clock()

    def try_acquire(self, n: float = 1) -> bool:
        with self._lock:
            now = self.clock()
            self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
            self.updated = now
            if self.tokens >= n:
                self.tokens -= n
                return True
            return False


def with_deadline(fn: Callable[[], T], seconds: float) -> T:
    """Run fn in a worker thread and give up waiting after `seconds`.

    Note: Python cannot kill the thread; the work may still finish in the background.
    Use it for read-only calls, or pair it with an idempotency key.
    """
    box: dict[str, Any] = {}

    def target() -> None:
        try:
            box["value"] = fn()
        except BaseException as e:
            box["error"] = e

    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(seconds)
    if t.is_alive():
        raise TimeoutError(f"no result within {seconds:g}s")
    if "error" in box:
        raise box["error"]
    return box["value"]
