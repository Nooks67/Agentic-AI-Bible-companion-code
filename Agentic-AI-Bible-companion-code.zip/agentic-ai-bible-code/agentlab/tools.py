"""Tools: Python functions an agent may call, with schemas, validation, risk levels and timeouts."""
from __future__ import annotations

import concurrent.futures
import inspect
import json
import typing
from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol

import jsonschema

Risk = Literal["read", "write", "external", "destructive"]
NEEDS_APPROVAL: set[str] = {"write", "external", "destructive"}

_PY_TO_JSON = {str: "string", int: "integer", float: "number", bool: "boolean", dict: "object"}


def _schema_for(tp: Any) -> dict:
    origin, args = typing.get_origin(tp), typing.get_args(tp)
    if origin is Literal:
        return {"type": _PY_TO_JSON[type(args[0])], "enum": list(args)}
    if origin in (list, tuple):
        return {"type": "array", "items": _schema_for(args[0]) if args else {}}
    if origin in (typing.Union, getattr(__import__("types"), "UnionType", None)):
        inner = [a for a in args if a is not type(None)]
        return _schema_for(inner[0]) if len(inner) == 1 else {"anyOf": [_schema_for(a) for a in inner]}
    if tp in _PY_TO_JSON:
        return {"type": _PY_TO_JSON[tp]}
    raise TypeError(f"Unsupported parameter type {tp!r}")


def _param_docs(doc: str) -> dict[str, str]:
    """Read 'name: description' lines from an Args: section of the docstring."""
    out, active = {}, False
    for line in doc.splitlines():
        s = line.strip()
        if s.lower() in ("args:", "arguments:", "parameters:"):
            active = True
        elif active and ":" in s:
            k, v = s.split(":", 1)
            out[k.strip()] = v.strip()
        elif active and not s:
            active = False
    return out


@dataclass
class Tool:
    name: str
    description: str
    fn: Callable[..., Any]
    parameters: dict
    risk: Risk = "read"
    timeout: float = 10.0

    def spec(self) -> dict:
        """The provider-neutral description sent to the model."""
        return {"name": self.name, "description": self.description, "parameters": self.parameters}


def tool(fn: Callable | None = None, *, risk: Risk = "read", name: str | None = None, timeout: float = 10.0):
    """Turn a typed, documented function into a Tool. Usable as @tool or @tool(risk="write")."""
    def wrap(f: Callable) -> Tool:
        hints = typing.get_type_hints(f)
        sig = inspect.signature(f)
        doc = inspect.getdoc(f) or ""
        pdocs = _param_docs(doc)
        props, required = {}, []
        for p in sig.parameters.values():
            s = _schema_for(hints[p.name])
            if p.name in pdocs:
                s["description"] = pdocs[p.name]
            if p.default is inspect.Parameter.empty:
                required.append(p.name)
            else:
                s["default"] = p.default
            props[p.name] = s
        summary = doc.split("\n\n")[0].replace("\n", " ") if doc else f.__name__
        params = {"type": "object", "properties": props, "required": required, "additionalProperties": False}
        return Tool(name or f.__name__, summary, f, params, risk, timeout)
    return wrap(fn) if fn else wrap


@dataclass
class ToolResult:
    ok: bool
    content: str
    error: str | None = None

    def for_model(self) -> str:
        return self.content if self.ok else f"ERROR: {self.error}"


class Approver(Protocol):
    def approve(self, tool: Tool, arguments: dict) -> bool: ...


class DenyAll:
    """Safe default: nothing with side effects runs until a human-approval channel is wired in."""
    def approve(self, tool: Tool, arguments: dict) -> bool:
        return False


class AllowList:
    """Approve only specific (tool, predicate) pairs. Used in tests and narrow automations."""
    def __init__(self, rules: dict[str, Callable[[dict], bool]]):
        self.rules = rules
        self.asked: list[tuple[str, dict]] = []

    def approve(self, tool: Tool, arguments: dict) -> bool:
        self.asked.append((tool.name, arguments))
        rule = self.rules.get(tool.name)
        return bool(rule and rule(arguments))


@dataclass
class ToolRegistry:
    tools: dict[str, Tool] = field(default_factory=dict)
    approver: Approver = field(default_factory=DenyAll)

    def add(self, *tools: Tool) -> "ToolRegistry":
        for t in tools:
            if t.name in self.tools:
                raise ValueError(f"Duplicate tool name {t.name}")
            self.tools[t.name] = t
        return self

    def specs(self) -> list[dict]:
        return [t.spec() for t in self.tools.values()]

    def call(self, name: str, arguments: dict) -> ToolResult:
        t = self.tools.get(name)
        if t is None:
            return ToolResult(False, "", f"unknown tool '{name}'. Available: {', '.join(self.tools)}")
        if "__invalid_json__" in arguments:
            return ToolResult(False, "", "arguments were not valid JSON")
        try:
            jsonschema.validate(arguments, t.parameters)
        except jsonschema.ValidationError as e:
            where = "/".join(str(p) for p in e.absolute_path) or "arguments"
            return ToolResult(False, "", f"invalid arguments for {name} ({where}): {e.message}")
        if t.risk in NEEDS_APPROVAL and not self.approver.approve(t, arguments):
            return ToolResult(False, "", f"approval denied for {name} (risk: {t.risk}). Do not retry; explain to the user.")
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        try:
            value = pool.submit(t.fn, **arguments).result(timeout=t.timeout)
        except concurrent.futures.TimeoutError:
            return ToolResult(False, "", f"{name} timed out after {t.timeout:g}s")
        except Exception as e:  # tool bugs and API failures become messages, not crashes
            return ToolResult(False, "", f"{name} failed: {type(e).__name__}: {e}")
        finally:
            pool.shutdown(wait=False, cancel_futures=True)
        content = value if isinstance(value, str) else json.dumps(value, default=str)
        return ToolResult(True, content)
