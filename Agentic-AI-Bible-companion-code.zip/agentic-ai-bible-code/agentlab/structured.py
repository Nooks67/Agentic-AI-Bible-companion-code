"""Structured outputs: ask for JSON, validate it against a Pydantic model, repair on failure."""
from __future__ import annotations

import json
import re
from typing import TypeVar

from pydantic import BaseModel, ValidationError

from .llm import ChatModel, Message, Usage

T = TypeVar("T", bound=BaseModel)


class StructuredOutputError(RuntimeError):
    def __init__(self, message: str, attempts: list[str]):
        super().__init__(message)
        self.attempts = attempts


def extract_json(text: str) -> str:
    """Pull the first JSON object out of a reply that may include prose or ``` fences."""
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    if fenced:
        return fenced.group(1)
    start = text.find("{")
    if start < 0:
        raise ValueError("no JSON object found")
    depth, in_str, esc = 0, False, False
    for i, ch in enumerate(text[start:], start):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    raise ValueError("unbalanced JSON object")


def schema_instruction(model_cls: type[BaseModel]) -> str:
    schema = json.dumps(model_cls.model_json_schema(), indent=2)
    return ("Reply with one JSON object only, no prose, that validates against this JSON Schema:\n"
            f"{schema}")


def ask_structured(model: ChatModel, messages: list[Message], model_cls: type[T],
                   retries: int = 2) -> tuple[T, Usage]:
    """Call the model until its reply validates, feeding validation errors back. Raises after retries."""
    convo = list(messages) + [Message("system", schema_instruction(model_cls))]
    usage, attempts = Usage(), []
    for _ in range(retries + 1):
        reply = model.complete(convo)
        usage = usage + reply.usage
        text = reply.message.content
        attempts.append(text)
        try:
            return model_cls.model_validate_json(extract_json(text)), usage
        except (ValueError, ValidationError) as e:
            problem = str(e) if not isinstance(e, ValidationError) else "; ".join(
                f"{'.'.join(map(str, err['loc'])) or 'object'}: {err['msg']}" for err in e.errors())
            convo += [Message("assistant", text),
                      Message("user", f"That reply was invalid: {problem}. Return the corrected JSON object only.")]
    raise StructuredOutputError(f"no valid {model_cls.__name__} after {retries + 1} attempts", attempts)
