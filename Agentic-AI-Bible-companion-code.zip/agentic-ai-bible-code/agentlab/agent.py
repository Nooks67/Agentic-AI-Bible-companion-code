"""The agent execution loop: think (model), act (tools), observe (results), repeat, with hard limits."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any

from .llm import ChatModel, Message, Usage
from .state import CheckpointStore
from .tools import ToolRegistry
from .trace import Tracer


@dataclass
class Pricing:
    """USD per million tokens. Fill in from your provider's current price page; prices change often."""
    input_per_m: float = 0.0
    output_per_m: float = 0.0

    def cost(self, u: Usage) -> float:
        return u.input_tokens / 1e6 * self.input_per_m + u.output_tokens / 1e6 * self.output_per_m


@dataclass
class AgentConfig:
    max_steps: int = 8              # model turns per run
    max_tool_calls: int = 20        # total tool executions per run
    max_seconds: float | None = None
    max_cost_usd: float | None = None
    repeat_limit: int = 2           # identical calls allowed before the loop intervenes


@dataclass
class RunResult:
    status: str                     # done | max_steps | max_tool_calls | timeout | budget | error
    answer: str
    steps: int
    tool_calls: int
    usage: Usage
    cost_usd: float
    messages: list[Message] = field(default_factory=list)


class Agent:
    def __init__(self, model: ChatModel, tools: ToolRegistry | None = None, system: str = "",
                 config: AgentConfig | None = None, tracer: Tracer | None = None,
                 pricing: Pricing | None = None, store: CheckpointStore | None = None):
        self.model = model
        self.tools = tools or ToolRegistry()
        self.system = system
        self.config = config or AgentConfig()
        self.tracer = tracer or Tracer()
        self.pricing = pricing or Pricing()
        self.store = store

    def run(self, task: str, run_id: str | None = None) -> RunResult:
        """Start a new run. With a store and run_id, every step is checkpointed."""
        messages = ([Message("system", self.system)] if self.system else []) + [Message("user", task)]
        return self._loop(messages, run_id, start_step=0)

    def resume(self, run_id: str) -> RunResult:
        """Continue a run from its last checkpoint (after a crash or restart)."""
        if not self.store:
            raise ValueError("resume() needs a CheckpointStore")
        cp = self.store.load(run_id)
        if cp is None:
            raise KeyError(f"no checkpoint for run {run_id}")
        if cp.status != "running":
            raise ValueError(f"run {run_id} already finished with status {cp.status}")
        self.tracer.event("run_resume", run_id=run_id, step=cp.step)
        return self._loop(cp.messages, run_id, start_step=cp.step)

    # ------------------------------------------------------------------
    def _loop(self, messages: list[Message], run_id: str | None, start_step: int) -> RunResult:
        cfg, tr = self.config, self.tracer
        usage, n_calls, t0 = Usage(), 0, time.monotonic()
        seen: dict[str, int] = {}
        tr.event("run_start", task=messages[-1].content[:200] if start_step == 0 else None, step=start_step)

        def skip(calls: list, reason: str) -> None:
            # Every tool call must get a result message, or the transcript cannot be sent to a provider again.
            for c in calls:
                messages.append(Message("tool", f"ERROR: not executed: {reason}", tool_call_id=c.id))

        def finish(status: str, answer: str, step: int) -> RunResult:
            cost = self.pricing.cost(usage)
            if self.store and run_id:
                self.store.save(run_id, step, messages, status=status)
            tr.event("run_end", status=status, steps=step, tool_calls=n_calls, cost_usd=round(cost, 6))
            return RunResult(status, answer, step, n_calls, usage, cost, messages)

        step = start_step
        while True:
            if step >= cfg.max_steps:
                return finish("max_steps", "Stopped: step limit reached before the task was finished.", step)
            if cfg.max_seconds is not None and time.monotonic() - t0 > cfg.max_seconds:
                return finish("timeout", "Stopped: time limit reached.", step)
            step += 1
            t_model = time.perf_counter()
            try:
                reply = self.model.complete(messages, self.tools.specs() or None)
            except Exception as e:
                tr.event("model_error", error=f"{type(e).__name__}: {e}")
                return finish("error", f"Model call failed: {e}", step)
            usage = usage + reply.usage
            msg = reply.message
            messages.append(msg)
            tr.event("model_reply", step=step, text=msg.content[:500], tool_calls=[c.name for c in msg.tool_calls],
                     input_tokens=reply.usage.input_tokens, output_tokens=reply.usage.output_tokens,
                     ms=round((time.perf_counter() - t_model) * 1000, 1))
            if cfg.max_cost_usd is not None and self.pricing.cost(usage) > cfg.max_cost_usd:
                skip(msg.tool_calls, "cost budget reached")
                return finish("budget", "Stopped: cost budget reached.", step)
            if not msg.tool_calls:
                return finish("done", msg.content, step)
            for i, c in enumerate(msg.tool_calls):
                if n_calls >= cfg.max_tool_calls:
                    skip(msg.tool_calls[i:], "tool-call limit reached")
                    return finish("max_tool_calls", "Stopped: tool-call limit reached.", step)
                key = f"{c.name}:{json.dumps(c.arguments, sort_keys=True)}"
                seen[key] = seen.get(key, 0) + 1
                if seen[key] > cfg.repeat_limit:
                    text = (f"ERROR: you already called {c.name} with these exact arguments {seen[key] - 1} times. "
                            "Use the earlier result or try a different approach.")
                    tr.event("tool_result", step=step, tool=c.name, ok=False, repeated=True)
                else:
                    n_calls += 1
                    t_tool = time.perf_counter()
                    res = self.tools.call(c.name, c.arguments)
                    text = res.for_model()
                    tr.event("tool_result", step=step, tool=c.name, args=c.arguments, ok=res.ok, error=res.error,
                             ms=round((time.perf_counter() - t_tool) * 1000, 1))
                messages.append(Message("tool", text, tool_call_id=c.id))
            if self.store and run_id:
                self.store.save(run_id, step, messages, status="running")
