"""Agent memory: a token-bounded conversation window, summarisation, and a long-term store with retention."""
from __future__ import annotations

import re
import sqlite3
import time
from dataclasses import dataclass

from .llm import ChatModel, Message, estimate_tokens
from .rag import tokenize

PII = [
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "[email]"),
    (re.compile(r"\b(?:\d[ -]?){13,19}\b"), "[card-number]"),
    (re.compile(r"\+?\d[\d ().-]{7,}\d"), "[phone]"),
]


def redact(text: str) -> str:
    for pattern, label in PII:
        text = pattern.sub(label, text)
    return text


class ConversationWindow:
    """Keep the system message and as many recent turns as fit in `max_tokens`.
    Never splits an assistant tool call from its tool results."""

    def __init__(self, max_tokens: int = 3000):
        self.max_tokens = max_tokens

    def fit(self, messages: list[Message]) -> list[Message]:
        system = [m for m in messages if m.role == "system"]
        rest = [m for m in messages if m.role != "system"]
        budget = self.max_tokens - sum(estimate_tokens(m.content) for m in system)
        kept: list[Message] = []
        i = len(rest) - 1
        while i >= 0:
            j = i
            while j > 0 and rest[j].role == "tool":    # walk back to the assistant turn that made the calls
                j -= 1
            group = rest[j:i + 1]
            cost = sum(estimate_tokens(m.content) + 8 for m in group)
            if cost > budget:
                break
            kept = group + kept
            budget -= cost
            i = j - 1
        while kept and kept[0].role == "tool":
            kept.pop(0)
        return system + kept


SUMMARY_PROMPT = ("Summarise the conversation so far for your own future reference in at most 8 bullet points. "
                  "Keep decisions, open tasks, user preferences and exact identifiers. Drop small talk.")


def compress(model: ChatModel, messages: list[Message], keep_recent: int = 6) -> list[Message]:
    """Replace older turns with a model-written summary; keep the system message and the last turns verbatim."""
    system = [m for m in messages if m.role == "system"]
    rest = [m for m in messages if m.role != "system"]
    if len(rest) <= keep_recent:
        return messages
    cut = len(rest) - keep_recent
    while cut < len(rest) and rest[cut].role == "tool":
        cut += 1                                     # do not orphan tool results
    old, recent = rest[:cut], rest[cut:]
    transcript = "\n".join(f"{m.role}: {m.content}" for m in old if m.content)
    summary = model.complete([Message("system", SUMMARY_PROMPT), Message("user", transcript)]).message.content
    return system + [Message("system", f"Summary of earlier conversation:\n{summary}")] + recent


@dataclass
class Memory:
    id: int
    user: str
    text: str
    kind: str
    source: str
    created: float
    expires: float | None


class LongTermMemory:
    """Facts about a user, with provenance, expiry, redaction and deletion."""

    def __init__(self, path: str = ":memory:", clock=time.time):
        self.clock = clock
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT, text TEXT, kind TEXT, source TEXT, created REAL, expires REAL)""")

    def remember(self, user: str, text: str, kind: str = "fact", source: str = "conversation",
                 ttl_days: float | None = 180) -> int:
        clean = redact(text)
        expires = self.clock() + ttl_days * 86400 if ttl_days else None
        with self.db:
            cur = self.db.execute("INSERT INTO memories (user, text, kind, source, created, expires) VALUES (?,?,?,?,?,?)",
                                  (user, clean, kind, source, self.clock(), expires))
        return cur.lastrowid

    def _live(self, user: str) -> list[Memory]:
        rows = self.db.execute("SELECT * FROM memories WHERE user=? AND (expires IS NULL OR expires > ?)",
                               (user, self.clock())).fetchall()
        return [Memory(*r) for r in rows]

    def recall(self, user: str, query: str, k: int = 3) -> list[Memory]:
        q = set(tokenize(query))
        scored = [(len(q & set(tokenize(m.text))), m) for m in self._live(user)]
        return [m for s, m in sorted(scored, key=lambda x: (-x[0], -x[1].created)) if s > 0][:k]

    def forget(self, user: str, memory_id: int | None = None) -> int:
        """Delete one memory, or everything for the user (a right-to-erasure request)."""
        with self.db:
            if memory_id is None:
                return self.db.execute("DELETE FROM memories WHERE user=?", (user,)).rowcount
            return self.db.execute("DELETE FROM memories WHERE user=? AND id=?", (user, memory_id)).rowcount

    def purge_expired(self) -> int:
        with self.db:
            return self.db.execute("DELETE FROM memories WHERE expires IS NOT NULL AND expires <= ?", (self.clock(),)).rowcount
