"""Multi-agent coordination: a coordinator plans, specialised workers execute, a blackboard holds shared results."""
from __future__ import annotations

import concurrent.futures
import threading
from dataclasses import dataclass, field
from typing import Callable, Literal

from pydantic import BaseModel, Field

from .llm import ChatModel, Message
from .structured import ask_structured


class Task(BaseModel):
    id: str = Field(pattern=r"^[a-z0-9_-]{1,32}$")
    worker: str
    instruction: str = Field(min_length=5)
    depends_on: list[str] = []


class Plan(BaseModel):
    tasks: list[Task] = Field(min_length=1, max_length=12)


Worker = Callable[[str, dict[str, str]], str]   # (instruction, results of dependencies) -> output


@dataclass
class TaskRecord:
    task: Task
    status: Literal["pending", "done", "failed", "skipped"] = "pending"
    output: str = ""
    attempts: int = 0
    error: str = ""


@dataclass
class Blackboard:
    """Shared state. Each task's output is written once, by the worker that owns the task."""
    records: dict[str, TaskRecord] = field(default_factory=dict)
    log: list[str] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def write(self, task_id: str, worker: str, status: str, output: str = "", error: str = "") -> None:
        with self._lock:
            rec = self.records[task_id]
            if rec.task.worker != worker:
                raise PermissionError(f"{worker} cannot write task {task_id} owned by {rec.task.worker}")
            rec.status, rec.output, rec.error = status, output, error  # type: ignore[assignment]
            self.log.append(f"{worker} -> {task_id}: {status}")


def validate_plan(plan: Plan, workers: dict[str, Worker]) -> None:
    ids = [t.id for t in plan.tasks]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate task ids")
    for t in plan.tasks:
        if t.worker not in workers:
            raise ValueError(f"task {t.id} uses unknown worker {t.worker}")
        for d in t.depends_on:
            if d not in ids:
                raise ValueError(f"task {t.id} depends on unknown task {d}")
    # cycle check (depth-first search)
    deps = {t.id: t.depends_on for t in plan.tasks}
    state: dict[str, int] = {}
    def visit(n: str) -> None:
        if state.get(n) == 1:
            raise ValueError(f"dependency cycle through {n}")
        if state.get(n) == 2:
            return
        state[n] = 1
        for d in deps[n]:
            visit(d)
        state[n] = 2
    for n in deps:
        visit(n)


PLANNER = """You coordinate a team of workers: {workers}.
Break the user's goal into at most {max_tasks} tasks. Assign each to exactly one worker.
Use depends_on when a task needs another task's output. Do not invent workers."""


class Coordinator:
    def __init__(self, model: ChatModel, workers: dict[str, Worker], max_tasks: int = 8,
                 retries: int = 1, parallel: int = 3):
        self.model, self.workers = model, workers
        self.max_tasks, self.retries, self.parallel = max_tasks, retries, parallel

    def plan(self, goal: str) -> Plan:
        sys = PLANNER.format(workers=", ".join(self.workers), max_tasks=self.max_tasks)
        plan, _ = ask_structured(self.model, [Message("system", sys), Message("user", goal)], Plan)
        validate_plan(plan, self.workers)
        return plan

    def execute(self, plan: Plan) -> Blackboard:
        board = Blackboard({t.id: TaskRecord(t) for t in plan.tasks})
        with concurrent.futures.ThreadPoolExecutor(self.parallel) as pool:
            while True:
                pending = [r for r in board.records.values() if r.status == "pending"]
                if not pending:
                    break
                ready, blocked = [], []
                for r in pending:
                    dep_status = [board.records[d].status for d in r.task.depends_on]
                    if any(s in ("failed", "skipped") for s in dep_status):
                        blocked.append(r)
                    elif all(s == "done" for s in dep_status):
                        ready.append(r)
                for r in blocked:
                    board.write(r.task.id, r.task.worker, "skipped", error="a dependency failed")
                if not ready:
                    continue
                futures = {pool.submit(self._run_task, r, board): r for r in ready}
                concurrent.futures.wait(futures)
        return board

    def _run_task(self, rec: TaskRecord, board: Blackboard) -> None:
        inputs = {d: board.records[d].output for d in rec.task.depends_on}
        last = ""
        for _ in range(self.retries + 1):
            rec.attempts += 1
            try:
                out = self.workers[rec.task.worker](rec.task.instruction, inputs)
                board.write(rec.task.id, rec.task.worker, "done", output=out)
                return
            except Exception as e:  # a failed worker must not take the whole team down
                last = f"{type(e).__name__}: {e}"
        board.write(rec.task.id, rec.task.worker, "failed", error=last)
