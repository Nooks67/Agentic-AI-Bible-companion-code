"""Provider-neutral chat model interface, plus a scripted model for offline tests.

Every agent in this book talks to a model through `ChatModel.complete()`. Swapping
providers means swapping one object; the agent loop never changes.
"""
from __future__ import annotations

import json
import math
import os
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class Message:
    role: str                      # "system", "user", "assistant" or "tool"
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str | None = None  # set on role="tool" messages


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0

    def __add__(self, other: Usage) -> Usage:
        return Usage(self.input_tokens + other.input_tokens, self.output_tokens + other.output_tokens)


@dataclass
class Reply:
    message: Message
    usage: Usage
    model: str


class ChatModel(Protocol):
    name: str

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply: ...


def estimate_tokens(text: str) -> int:
    """Rough count (about 4 characters per token for English). Use the provider's count for billing."""
    return max(1, math.ceil(len(text) / 4))


# --------------------------------------------------------------------------- scripted model
Step = str | list[ToolCall] | Callable[[list[Message]], Message]


class ScriptedModel:
    """A deterministic stand-in for a real model. It replays a script of replies.

    Use it for tests and for running every example offline. Its "decisions" are
    written by you in advance, so it proves your plumbing works, not that a real
    model would choose the same steps.
    """

    def __init__(self, script: list[Step], name: str = "scripted"):
        self.script = list(script)
        self.name = name
        self.calls: list[list[Message]] = []   # every prompt it received, for assertions

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        self.calls.append(list(messages))
        if not self.script:
            raise RuntimeError("ScriptedModel ran out of scripted replies")
        step = self.script.pop(0)
        if callable(step):
            msg = step(messages)
        elif isinstance(step, list):
            msg = Message("assistant", "", tool_calls=step)
        else:
            msg = Message("assistant", step)
        prompt = sum(estimate_tokens(m.content) for m in messages)
        out = estimate_tokens(msg.content + json.dumps([c.arguments for c in msg.tool_calls]))
        return Reply(msg, Usage(prompt, out), self.name)


def call(name: str, id: str | None = None, **arguments: Any) -> ToolCall:
    """Shorthand for scripts: call("lookup_order", order_id="A100")."""
    return ToolCall(id or f"call_{name}_{random.randrange(10**6):06d}", name, arguments)


# --------------------------------------------------------------------------- HTTP helper
class ModelHTTPError(RuntimeError):
    def __init__(self, status: int, body: str):
        super().__init__(f"HTTP {status}: {body[:300]}")
        self.status = status


RETRYABLE = {408, 409, 429, 500, 502, 503, 504}


def post_json(url: str, payload: dict, headers: dict, timeout: float = 60, attempts: int = 4) -> dict:
    """POST JSON with retries on rate limits and server errors (exponential backoff + jitter)."""
    data = json.dumps(payload).encode()
    for attempt in range(1, attempts + 1):
        req = urllib.request.Request(url, data=data, headers={"content-type": "application/json", **headers})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")
            if e.code not in RETRYABLE or attempt == attempts:
                raise ModelHTTPError(e.code, body) from None
            wait = float(e.headers.get("retry-after") or 0) or min(30, 2 ** attempt) * random.uniform(0.5, 1.0)
        except (urllib.error.URLError, TimeoutError) as e:
            if attempt == attempts:
                raise ModelHTTPError(0, str(e)) from None
            wait = min(30, 2 ** attempt) * random.uniform(0.5, 1.0)
        time.sleep(wait)
    raise AssertionError("unreachable")


# --------------------------------------------------------------------------- OpenAI-compatible
class OpenAICompatibleModel:
    """Chat Completions format: used by OpenAI and by many local and hosted servers
    (for example Ollama, vLLM and LM Studio expose the same /chat/completions shape)."""

    def __init__(self, model: str | None = None, base_url: str | None = None, api_key: str | None = None,
                 timeout: float = 60):
        self.name = model or os.environ.get("AGENTLAB_MODEL", "")
        self.base_url = (base_url or os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.timeout = timeout
        if not self.name:
            raise ValueError("Set a model name (argument or AGENTLAB_MODEL)")

    @staticmethod
    def to_wire(m: Message) -> dict:
        if m.role == "tool":
            return {"role": "tool", "tool_call_id": m.tool_call_id, "content": m.content}
        out: dict[str, Any] = {"role": m.role, "content": m.content or None}
        if m.tool_calls:
            out["tool_calls"] = [{"id": c.id, "type": "function",
                                  "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
                                 for c in m.tool_calls]
        return out

    @staticmethod
    def from_wire(data: dict) -> tuple[Message, Usage]:
        msg = data["choices"][0]["message"]
        calls = []
        for c in msg.get("tool_calls") or []:
            raw = c["function"].get("arguments") or "{}"
            try:
                args = json.loads(raw)
            except json.JSONDecodeError:
                args = {"__invalid_json__": raw}   # let the tool layer report it back to the model
            calls.append(ToolCall(c["id"], c["function"]["name"], args))
        u = data.get("usage") or {}
        return (Message("assistant", msg.get("content") or "", tool_calls=calls),
                Usage(u.get("prompt_tokens", 0), u.get("completion_tokens", 0)))

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        payload: dict[str, Any] = {"model": self.name, "messages": [self.to_wire(m) for m in messages], **opts}
        if tools:
            payload["tools"] = [{"type": "function", "function": t} for t in tools]
        headers = {"authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        data = post_json(f"{self.base_url}/chat/completions", payload, headers, self.timeout)
        msg, usage = self.from_wire(data)
        return Reply(msg, usage, data.get("model", self.name))


# --------------------------------------------------------------------------- Anthropic Messages API
class AnthropicModel:
    """Anthropic Messages API: system prompt is a separate field, tool calls are
    `tool_use` content blocks, and tool results go back as `tool_result` blocks."""

    def __init__(self, model: str | None = None, api_key: str | None = None, max_tokens: int = 1024,
                 base_url: str = "https://api.anthropic.com/v1", timeout: float = 60):
        self.name = model or os.environ.get("AGENTLAB_MODEL", "")
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.max_tokens, self.base_url, self.timeout = max_tokens, base_url.rstrip("/"), timeout
        if not self.name:
            raise ValueError("Set a model name (argument or AGENTLAB_MODEL)")

    @staticmethod
    def to_wire(messages: list[Message]) -> tuple[str, list[dict]]:
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        out: list[dict] = []
        for m in messages:
            if m.role == "system":
                continue
            if m.role == "tool":
                block = {"type": "tool_result", "tool_use_id": m.tool_call_id, "content": m.content}
                if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list):
                    out[-1]["content"].append(block)        # several results share one user turn
                else:
                    out.append({"role": "user", "content": [block]})
            elif m.tool_calls:
                blocks: list[dict] = [{"type": "text", "text": m.content}] if m.content else []
                blocks += [{"type": "tool_use", "id": c.id, "name": c.name, "input": c.arguments} for c in m.tool_calls]
                out.append({"role": "assistant", "content": blocks})
            else:
                out.append({"role": m.role, "content": m.content})
        return system, out

    @staticmethod
    def from_wire(data: dict) -> tuple[Message, Usage]:
        text, calls = [], []
        for b in data.get("content", []):
            if b["type"] == "text":
                text.append(b["text"])
            elif b["type"] == "tool_use":
                calls.append(ToolCall(b["id"], b["name"], b.get("input") or {}))
        u = data.get("usage") or {}
        return Message("assistant", "".join(text), tool_calls=calls), Usage(u.get("input_tokens", 0), u.get("output_tokens", 0))

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        system, wire = self.to_wire(messages)
        payload: dict[str, Any] = {"model": self.name, "max_tokens": self.max_tokens, "messages": wire, **opts}
        if system:
            payload["system"] = system
        if tools:
            payload["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
                                for t in tools]
        headers = {"x-api-key": self.api_key, "anthropic-version": "2023-06-01"}
        data = post_json(f"{self.base_url}/messages", payload, headers, self.timeout)
        msg, usage = self.from_wire(data)
        return Reply(msg, usage, data.get("model", self.name))


def model_from_env() -> ChatModel:
    """Pick a real provider from environment variables (see Appendix A)."""
    provider = os.environ.get("AGENTLAB_PROVIDER", "openai")
    return AnthropicModel() if provider == "anthropic" else OpenAICompatibleModel()
