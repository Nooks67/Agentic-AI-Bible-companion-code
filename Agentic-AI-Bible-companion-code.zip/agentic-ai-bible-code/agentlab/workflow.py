"""A small workflow graph: named steps, conditional routing, a transition limit and checkpoints.

Deterministic steps and model-driven steps live in the same graph, so you decide
exactly where the model is allowed to choose the path.
"""
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from typing import Any, Callable

END = "__end__"
State = dict[str, Any]
Step = Callable[[State], State]
Router = Callable[[State], str]


@dataclass
class Graph:
    steps: dict[str, Step] = field(default_factory=dict)
    edges: dict[str, str | Router] = field(default_factory=dict)
    start: str | None = None
    max_transitions: int = 50

    def step(self, name: str, fn: Step, *, start: bool = False) -> "Graph":
        self.steps[name] = fn
        if start or self.start is None:
            self.start = name
        return self

    def edge(self, src: str, dst: str | Router) -> "Graph":
        """dst is a step name, END, or a function of state that returns one of those."""
        self.edges[src] = dst
        return self

    def validate(self) -> None:
        for src, dst in self.edges.items():
            if src not in self.steps:
                raise ValueError(f"edge from unknown step {src}")
            if isinstance(dst, str) and dst != END and dst not in self.steps:
                raise ValueError(f"edge to unknown step {dst}")
        missing = [s for s in self.steps if s not in self.edges]
        if missing:
            raise ValueError(f"steps with no outgoing edge: {missing}")

    def run(self, state: State, checkpoint: "GraphCheckpoints | None" = None, run_id: str = "run",
            resume: bool = False) -> State:
        self.validate()
        current = self.start
        history: list[str] = []
        if resume and checkpoint:
            saved = checkpoint.load(run_id)
            if saved:
                current, state, history = saved
        for _ in range(self.max_transitions):
            if current == END:
                state["_history"] = history
                if checkpoint:
                    checkpoint.save(run_id, END, state, history)
                return state
            state = self.steps[current](dict(state))
            history.append(current)
            dst = self.edges[current]
            nxt = dst(state) if callable(dst) else dst
            if nxt != END and nxt not in self.steps:
                raise ValueError(f"router after {current} returned unknown step {nxt!r}")
            current = nxt
            if checkpoint:
                checkpoint.save(run_id, current, state, history)
        raise RuntimeError(f"workflow exceeded {self.max_transitions} transitions; path so far: {history[-10:]}")


class GraphCheckpoints:
    def __init__(self, path: str = ":memory:"):
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS wf (run_id TEXT PRIMARY KEY, next TEXT, state TEXT, history TEXT)")

    def save(self, run_id: str, nxt: str, state: State, history: list[str]) -> None:
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO wf VALUES (?,?,?,?)",
                            (run_id, nxt, json.dumps(state, default=str), json.dumps(history)))

    def load(self, run_id: str) -> tuple[str, State, list[str]] | None:
        row = self.db.execute("SELECT next, state, history FROM wf WHERE run_id=?", (run_id,)).fetchone()
        return (row[0], json.loads(row[1]), json.loads(row[2])) if row else None
