"""Human approval as a durable queue: requests are bound to the exact action, expire, and record who decided."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
import uuid
from dataclasses import dataclass
from typing import Callable

from .tools import Tool


def action_hash(tool: str, arguments: dict) -> str:
    canonical = json.dumps({"tool": tool, "args": arguments}, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


@dataclass
class ApprovalRequest:
    id: str
    tool: str
    arguments: dict
    action_hash: str
    reason: str
    status: str          # pending | approved | declined | expired | used
    requested_at: float
    expires_at: float
    decided_by: str | None
    note: str | None


class ApprovalQueue:
    def __init__(self, path: str = ":memory:", ttl_seconds: float = 24 * 3600, clock: Callable[[], float] = time.time):
        self.ttl, self.clock = ttl_seconds, clock
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS approvals (id TEXT PRIMARY KEY, tool TEXT, arguments TEXT,
            action_hash TEXT, reason TEXT, status TEXT, requested_at REAL, expires_at REAL, decided_by TEXT, note TEXT)""")

    def _row(self, r) -> ApprovalRequest:
        req = ApprovalRequest(r[0], r[1], json.loads(r[2]), *r[3:])
        if req.status == "pending" and self.clock() > req.expires_at:
            req.status = "expired"
        return req

    def request(self, tool: str, arguments: dict, reason: str = "") -> ApprovalRequest:
        """Create a pending request, or return the open one for the same action (no duplicate requests)."""
        h = action_hash(tool, arguments)
        for r in self.db.execute("SELECT * FROM approvals WHERE action_hash=? AND status='pending'", (h,)):
            req = self._row(r)
            if req.status == "pending":
                return req
        now = self.clock()
        req = ApprovalRequest(uuid.uuid4().hex[:10], tool, arguments, h, reason, "pending", now, now + self.ttl, None, None)
        with self.db:
            self.db.execute("INSERT INTO approvals VALUES (?,?,?,?,?,?,?,?,?,?)",
                            (req.id, tool, json.dumps(arguments), h, reason, "pending", now, req.expires_at, None, None))
        return req

    def decide(self, request_id: str, approved: bool, by: str, note: str = "") -> ApprovalRequest:
        req = self.get(request_id)
        if req.status != "pending":
            raise ValueError(f"request {request_id} is {req.status}; it can no longer be decided")
        status = "approved" if approved else "declined"
        with self.db:
            self.db.execute("UPDATE approvals SET status=?, decided_by=?, note=? WHERE id=?", (status, by, note, request_id))
        return self.get(request_id)

    def get(self, request_id: str) -> ApprovalRequest:
        r = self.db.execute("SELECT * FROM approvals WHERE id=?", (request_id,)).fetchone()
        if r is None:
            raise KeyError(request_id)
        return self._row(r)

    def pending(self) -> list[ApprovalRequest]:
        rows = [self._row(r) for r in self.db.execute("SELECT * FROM approvals WHERE status='pending' ORDER BY requested_at")]
        return [r for r in rows if r.status == "pending"]

    def find_approved(self, tool: str, arguments: dict) -> ApprovalRequest | None:
        h = action_hash(tool, arguments)
        rows = [self._row(r) for r in self.db.execute(
            "SELECT * FROM approvals WHERE action_hash=? AND status='approved'", (h,))]
        return next((r for r in rows if self.clock() <= r.expires_at), None)

    def is_approved(self, tool: str, arguments: dict) -> bool:
        return self.find_approved(tool, arguments) is not None

    def consume(self, request_id: str) -> None:
        """An approval authorises one execution; mark it used so it cannot authorise a second."""
        with self.db:
            self.db.execute("UPDATE approvals SET status='used' WHERE id=? AND status='approved'", (request_id,))


class QueueApprover:
    """Approver for ToolRegistry: runs an action only if a matching, unexpired approval exists.
    Otherwise files a request for a person and refuses for now; the agent tells the user it is pending."""

    def __init__(self, queue: ApprovalQueue, reason: Callable[[Tool, dict], str] = lambda t, a: ""):
        self.queue, self.reason = queue, reason

    def approve(self, tool: Tool, arguments: dict) -> bool:
        granted = self.queue.find_approved(tool.name, arguments)
        if granted:
            self.queue.consume(granted.id)
            return True
        self.queue.request(tool.name, arguments, self.reason(tool, arguments))
        return False
