"""Model routing, fallback and response caching."""
from __future__ import annotations

import hashlib
import json
import sqlite3
from dataclasses import asdict
from typing import Any, Callable

from .llm import ChatModel, Message, Reply, ToolCall, Usage


class FallbackModel:
    """Try models in order; move to the next one when a call raises."""

    def __init__(self, models: list[ChatModel], on_fallback: Callable[[str, Exception], None] | None = None):
        self.models, self.on_fallback = models, on_fallback
        self.name = "+".join(m.name for m in models)

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        last: Exception | None = None
        for m in self.models:
            try:
                return m.complete(messages, tools, **opts)
            except Exception as e:
                last = e
                if self.on_fallback:
                    self.on_fallback(m.name, e)
        raise RuntimeError(f"all models failed; last error: {last}")


class RouterModel:
    """Send each request to a model chosen by a rule (for example: short, tool-free requests to a small model)."""

    def __init__(self, routes: dict[str, ChatModel], choose: Callable[[list[Message], list[dict] | None], str]):
        self.routes, self.choose = routes, choose
        self.name = "router"
        self.log: list[str] = []

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        key = self.choose(messages, tools)
        self.log.append(key)
        return self.routes[key].complete(messages, tools, **opts)


class CachedModel:
    """Exact-match cache keyed by model name + messages + tools + options. Only safe for deterministic settings."""

    def __init__(self, inner: ChatModel, path: str = ":memory:"):
        self.inner, self.name = inner, inner.name
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, reply TEXT)")
        self.hits = self.misses = 0

    def _key(self, messages: list[Message], tools: list[dict] | None, opts: dict) -> str:
        raw = json.dumps([self.inner.name, [asdict(m) for m in messages], tools, opts], sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()

    def complete(self, messages: list[Message], tools: list[dict] | None = None, **opts: Any) -> Reply:
        k = self._key(messages, tools, opts)
        row = self.db.execute("SELECT reply FROM cache WHERE k=?", (k,)).fetchone()
        if row:
            self.hits += 1
            d = json.loads(row[0])
            msg = Message(d["role"], d["content"], [ToolCall(**c) for c in d["tool_calls"]])
            return Reply(msg, Usage(0, 0), self.name)   # a cache hit costs no tokens
        self.misses += 1
        reply = self.inner.complete(messages, tools, **opts)
        with self.db:
            self.db.execute("INSERT OR REPLACE INTO cache VALUES (?,?)", (k, json.dumps(asdict(reply.message))))
        return reply
