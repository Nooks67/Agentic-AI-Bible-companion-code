"""Structured tracing: one JSON object per event, so every run can be replayed and measured."""
from __future__ import annotations

import json
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


class Tracer:
    def __init__(self, path: str | Path | None = None, run_id: str | None = None):
        self.path = Path(path) if path else None
        self.run_id = run_id or uuid.uuid4().hex[:12]
        self.events: list[dict] = []
        self._stack: list[str] = []

    def event(self, kind: str, **data: Any) -> dict:
        ev = {"ts": round(time.time(), 3), "run_id": self.run_id, "span": self._stack[-1] if self._stack else None,
              "kind": kind, **data}
        self.events.append(ev)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a") as f:
                f.write(json.dumps(ev, default=str) + "\n")
        return ev

    @contextmanager
    def span(self, name: str, **data: Any) -> Iterator[str]:
        sid = uuid.uuid4().hex[:8]
        t0 = time.perf_counter()
        self.event("span_start", name=name, span_id=sid, **data)
        self._stack.append(sid)
        status = "ok"
        try:
            yield sid
        except BaseException as e:
            status = f"error: {type(e).__name__}"
            raise
        finally:
            self._stack.pop()
            self.event("span_end", name=name, span_id=sid, status=status, ms=round((time.perf_counter() - t0) * 1000, 1))


def load(path: str | Path) -> list[dict]:
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def summarize(events: list[dict]) -> dict:
    """Headline numbers for one or more runs: steps, tool calls, errors, tokens, latency."""
    tools = [e for e in events if e["kind"] == "tool_result"]
    model = [e for e in events if e["kind"] == "model_reply"]
    ends = [e for e in events if e["kind"] == "run_end"]
    return {
        "runs": len({e["run_id"] for e in events}),
        "model_calls": len(model),
        "tool_calls": len(tools),
        "tool_errors": sum(1 for e in tools if not e.get("ok")),
        "input_tokens": sum(e.get("input_tokens", 0) for e in model),
        "output_tokens": sum(e.get("output_tokens", 0) for e in model),
        "statuses": {s: sum(1 for e in ends if e.get("status") == s) for s in sorted({e.get("status") for e in ends})},
        "model_ms": round(sum(e.get("ms", 0) for e in model), 1),
    }
