"""Evaluation harness: test cases, scorers, suite reports and regression comparison."""
from __future__ import annotations

import json
import statistics
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .agent import RunResult
from .llm import ChatModel, Message
from .structured import extract_json


@dataclass
class Case:
    id: str
    input: str
    checks: list[dict]                 # e.g. {"type": "contains", "value": "refund"}
    tags: list[str] = field(default_factory=list)


def tools_used(result: RunResult) -> list[str]:
    return [c.name for m in result.messages if m.role == "assistant" for c in m.tool_calls]


def score_check(check: dict, result: RunResult) -> tuple[bool, str]:
    t, v, ans = check["type"], check.get("value"), result.answer
    if t == "contains":
        return v.lower() in ans.lower(), f"answer contains {v!r}"
    if t == "not_contains":
        return v.lower() not in ans.lower(), f"answer avoids {v!r}"
    if t == "status":
        return result.status == v, f"status is {v}"
    if t == "tool_called":
        return v in tools_used(result), f"called {v}"
    if t == "tool_not_called":
        return v not in tools_used(result), f"did not call {v}"
    if t == "tool_sequence":
        used = tools_used(result)
        it = iter(used)
        return all(x in it for x in v), f"tool order {v}"
    if t == "max_steps":
        return result.steps <= v, f"finished in <= {v} steps"
    if t == "json_valid":
        try:
            json.loads(extract_json(ans)); return True, "answer has valid JSON"
        except ValueError:
            return False, "answer has valid JSON"
    raise ValueError(f"unknown check type {t}")


@dataclass
class CaseResult:
    id: str
    passed: bool
    failures: list[str]
    seconds: float
    steps: int
    tool_calls: int
    tokens: int
    status: str


@dataclass
class Report:
    results: list[CaseResult]

    @property
    def pass_rate(self) -> float:
        return sum(r.passed for r in self.results) / max(1, len(self.results))

    def summary(self) -> dict:
        secs = [r.seconds for r in self.results] or [0.0]
        return {"cases": len(self.results), "passed": sum(r.passed for r in self.results),
                "pass_rate": round(self.pass_rate, 3), "mean_seconds": round(statistics.mean(secs), 4),
                "mean_steps": round(statistics.mean([r.steps for r in self.results] or [0]), 2),
                "total_tokens": sum(r.tokens for r in self.results),
                "failed": [r.id for r in self.results if not r.passed]}

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps({"summary": self.summary(), "results": [r.__dict__ for r in self.results]}, indent=1))


def run_suite(run_case: Callable[[Case], RunResult], cases: list[Case]) -> Report:
    """run_case builds a *fresh* agent for each case so state never leaks between cases."""
    out = []
    for case in cases:
        t0 = time.perf_counter()
        res = run_case(case)
        secs = time.perf_counter() - t0
        fails = [label for ok, label in (score_check(c, res) for c in case.checks) if not ok]
        out.append(CaseResult(case.id, not fails, fails, round(secs, 4), res.steps, res.tool_calls,
                              res.usage.input_tokens + res.usage.output_tokens, res.status))
    return Report(out)


def compare(baseline: dict, current: dict) -> list[str]:
    """Regressions: cases that passed in the baseline report and fail now, plus pass-rate drops."""
    was = {r["id"]: r["passed"] for r in baseline["results"]}
    now = {r["id"]: r["passed"] for r in current["results"]}
    out = [f"regressed: {cid}" for cid, ok in was.items() if ok and now.get(cid) is False]
    if current["summary"]["pass_rate"] < baseline["summary"]["pass_rate"]:
        out.append(f"pass rate fell {baseline['summary']['pass_rate']} -> {current['summary']['pass_rate']}")
    return out


JUDGE_PROMPT = """You are grading an AI assistant's answer against a rubric.
Rubric:
{rubric}

Question: {question}
Answer: {answer}

Return JSON: {{"score": <integer 1-5>, "reason": "<one sentence>"}}"""


def judge(model: ChatModel, question: str, answer: str, rubric: str) -> dict:
    """Model-based grading. Calibrate it against human grades before trusting it (Chapter 28)."""
    text = model.complete([Message("user", JUDGE_PROMPT.format(rubric=rubric, question=question, answer=answer))]).message.content
    data = json.loads(extract_json(text))
    score = int(data["score"])
    if not 1 <= score <= 5:
        raise ValueError(f"judge score out of range: {score}")
    return {"score": score, "reason": str(data.get("reason", ""))}


def agreement(a: list[int], b: list[int], tolerance: int = 0) -> float:
    """Share of items where two graders (e.g. model vs human) agree within `tolerance` points."""
    return sum(abs(x - y) <= tolerance for x, y in zip(a, b)) / max(1, len(a))
