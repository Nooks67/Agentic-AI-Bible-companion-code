"""Durable state: checkpoints for resuming runs, and an idempotency ledger so actions never run twice."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

from .llm import Message, ToolCall


def _dump(messages: list[Message]) -> str:
    return json.dumps([asdict(m) for m in messages])


def _load(text: str) -> list[Message]:
    out = []
    for d in json.loads(text):
        d["tool_calls"] = [ToolCall(**c) for c in d.get("tool_calls", [])]
        out.append(Message(**d))
    return out


@dataclass
class Checkpoint:
    run_id: str
    step: int
    status: str
    messages: list[Message]
    saved_at: float


class CheckpointStore:
    """SQLite-backed. One row per (run, step); load() returns the newest."""

    def __init__(self, path: str | Path = ":memory:"):
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS checkpoints (
            run_id TEXT, step INTEGER, status TEXT, messages TEXT, saved_at REAL,
            PRIMARY KEY (run_id, step))""")
        self.db.commit()

    def save(self, run_id: str, step: int, messages: list[Message], status: str = "running") -> None:
        with self.db:  # one transaction: a crash mid-write leaves the previous checkpoint intact
            self.db.execute("INSERT OR REPLACE INTO checkpoints VALUES (?,?,?,?,?)",
                            (run_id, step, status, _dump(messages), time.time()))

    def load(self, run_id: str) -> Checkpoint | None:
        row = self.db.execute("SELECT run_id, step, status, messages, saved_at FROM checkpoints "
                              "WHERE run_id=? ORDER BY step DESC LIMIT 1", (run_id,)).fetchone()
        return Checkpoint(row[0], row[1], row[2], _load(row[3]), row[4]) if row else None

    def runs(self, status: str | None = None) -> list[str]:
        q = "SELECT run_id, status FROM checkpoints c WHERE step = (SELECT MAX(step) FROM checkpoints WHERE run_id=c.run_id)"
        return [r for r, s in self.db.execute(q) if status is None or s == status]


class IdempotencyLedger:
    """Remember the result of every side-effecting action by key.

    If a run is retried or resumed, the same action with the same key returns the
    stored result instead of executing again (no double charges, no duplicate emails).
    """

    def __init__(self, path: str | Path = ":memory:"):
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS actions (key TEXT PRIMARY KEY, result TEXT, at REAL)")
        self.db.commit()

    @staticmethod
    def key(action: str, **params: Any) -> str:
        raw = action + json.dumps(params, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def run_once(self, key: str, fn: Callable[[], Any]) -> tuple[Any, bool]:
        """Return (result, executed_now)."""
        row = self.db.execute("SELECT result FROM actions WHERE key=?", (key,)).fetchone()
        if row:
            return json.loads(row[0]), False
        result = fn()
        with self.db:
            self.db.execute("INSERT INTO actions VALUES (?,?,?)", (key, json.dumps(result, default=str), time.time()))
        return result, True
