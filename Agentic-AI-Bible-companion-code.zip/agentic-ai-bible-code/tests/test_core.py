"""Tests for the agentlab library. Run: python -m pytest tests"""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest
from pydantic import BaseModel, Field

from agentlab import (Agent, AgentConfig, AllowList, CheckpointStore, IdempotencyLedger, Message, Pricing,
                      ScriptedModel, ToolRegistry, call, tool)
from agentlab.llm import AnthropicModel, OpenAICompatibleModel, ToolCall
from agentlab.structured import StructuredOutputError, ask_structured, extract_json


@tool
def get_weather(city: str, unit: str = "C") -> dict:
    """Current weather for a city.

    Args:
        city: City name, e.g. "Lisbon".
        unit: "C" or "F".
    """
    return {"city": city, "temp": 21, "unit": unit}


@tool
def broken() -> str:
    """Always fails."""
    raise ValueError("database unavailable")


@tool(timeout=0.2)
def slow() -> str:
    """Takes too long."""
    time.sleep(2)
    return "late"


@tool(risk="external")
def send_email(to: str, body: str) -> str:
    """Send an email."""
    return f"sent to {to}"


def registry(approver=None):
    r = ToolRegistry().add(get_weather, broken, slow, send_email)
    if approver:
        r.approver = approver
    return r


def test_schema_from_signature():
    p = get_weather.parameters
    assert p["required"] == ["city"]
    assert p["properties"]["city"] == {"type": "string", "description": 'City name, e.g. "Lisbon".'}
    assert p["properties"]["unit"]["default"] == "C"
    assert get_weather.description == "Current weather for a city."


def test_successful_task():
    model = ScriptedModel([[call("get_weather", city="Lisbon")], "It is 21 C in Lisbon."])
    res = Agent(model, registry()).run("Weather in Lisbon?")
    assert res.status == "done" and res.answer == "It is 21 C in Lisbon."
    assert res.tool_calls == 1
    tool_msg = res.messages[-2]
    assert tool_msg.role == "tool" and json.loads(tool_msg.content)["temp"] == 21


def test_invalid_and_missing_arguments_are_reported_to_model():
    r = registry()
    assert "required property" in r.call("get_weather", {}).error
    assert "is not of type 'string'" in r.call("get_weather", {"city": 5}).error
    assert "Additional properties" in r.call("get_weather", {"city": "X", "zip": "1"}).error
    assert "unknown tool" in r.call("nope", {}).error


def test_tool_exception_and_timeout_become_errors():
    r = registry()
    assert r.call("broken", {}).error == "broken failed: ValueError: database unavailable"
    t0 = time.monotonic()
    assert "timed out" in r.call("slow", {}).error
    assert time.monotonic() - t0 < 1.5


def test_approval_denied_by_default_and_allowed_by_rule():
    assert "approval denied" in registry().call("send_email", {"to": "a@b.co", "body": "hi"}).error
    ok = registry(AllowList({"send_email": lambda a: a["to"].endswith("@example.com")}))
    assert ok.call("send_email", {"to": "x@example.com", "body": "hi"}).ok
    assert not ok.call("send_email", {"to": "x@evil.test", "body": "hi"}).ok


def test_repeated_identical_call_is_stopped():
    same = [call("get_weather", city="Oslo")]
    model = ScriptedModel([same, same, same, "done"])
    res = Agent(model, registry(), config=AgentConfig(repeat_limit=2)).run("loop")
    assert res.tool_calls == 2
    assert "already called get_weather" in res.messages[-2].content


def test_max_steps_and_tool_call_limits():
    model = ScriptedModel([[call("get_weather", city=f"C{i}")] for i in range(10)])
    assert Agent(model, registry(), config=AgentConfig(max_steps=3)).run("x").status == "max_steps"
    model = ScriptedModel([[call("get_weather", city=f"C{i}") for i in range(5)]])
    assert Agent(model, registry(), config=AgentConfig(max_tool_calls=3)).run("x").status == "max_tool_calls"


def test_cost_budget_stops_run():
    model = ScriptedModel([[call("get_weather", city="A")], [call("get_weather", city="B")], "ok"])
    res = Agent(model, registry(), pricing=Pricing(1_000_000, 1_000_000),
                config=AgentConfig(max_cost_usd=0.5)).run("x" * 400)
    assert res.status == "budget"


def test_model_error_is_contained():
    class Down:
        name = "down"
        def complete(self, *a, **k):
            raise ConnectionError("no route")
    assert Agent(Down(), registry()).run("x").status == "error"


class ProcessKilled(BaseException):
    """Simulates the process dying: not an Exception, so nothing in the loop catches it."""


def test_checkpoint_resume_after_crash():
    store = CheckpointStore()
    def die(messages):
        raise ProcessKilled()
    first = ScriptedModel([[call("get_weather", city="Rome")], die])
    with pytest.raises(ProcessKilled):
        Agent(first, registry(), store=store).run("Weather in Rome?", run_id="r1")
    cp = store.load("r1")
    assert cp.status == "running" and cp.step == 1
    assert [m.role for m in cp.messages] == ["user", "assistant", "tool"]
    second = ScriptedModel(["It is 21 C in Rome."])
    r2 = Agent(second, registry(), store=store).resume("r1")
    assert r2.status == "done" and "Rome" in r2.answer
    assert second.calls[0][-1].role == "tool"   # resumed with the tool result already in context
    with pytest.raises(ValueError):
        Agent(second, registry(), store=store).resume("r1")   # finished runs cannot be resumed


def test_idempotency_ledger_runs_once():
    ledger, sent = IdempotencyLedger(), []
    key = ledger.key("send_invoice", invoice="INV-7")
    for _ in range(3):
        ledger.run_once(key, lambda: sent.append(1) or {"status": "sent"})
    assert len(sent) == 1


class Ticket(BaseModel):
    category: str = Field(pattern="^(billing|bug|other)$")
    priority: int = Field(ge=1, le=3)


def test_structured_output_repairs_then_validates():
    model = ScriptedModel(['Sure! {"category": "money", "priority": 1}',
                           '```json\n{"category": "billing", "priority": 1}\n```'])
    out, usage = ask_structured(model, [Message("user", "I was charged twice")], Ticket)
    assert out.category == "billing" and usage.output_tokens > 0
    assert "invalid" in model.calls[1][-1].content


def test_structured_output_gives_up():
    with pytest.raises(StructuredOutputError):
        ask_structured(ScriptedModel(["no", "still no", "nope"]), [Message("user", "x")], Ticket)


def test_extract_json_handles_braces_in_strings():
    assert json.loads(extract_json('note: {"a": "x } y", "b": {"c": 1}} trailing')) == {"a": "x } y", "b": {"c": 1}}


# ----------------------------------------------------------------- provider adapters against a local fake server
class Fake(BaseHTTPRequestHandler):
    reply: dict = {}
    seen: list = []

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["content-length"])))
        Fake.seen.append((self.path, {k.lower(): v for k, v in self.headers.items()}, body))
        out = json.dumps(Fake.reply).encode()
        self.send_response(200)
        self.send_header("content-type", "application/json")
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


@pytest.fixture
def fake_server():
    srv = HTTPServer(("127.0.0.1", 0), Fake)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    Fake.seen.clear()
    yield f"http://127.0.0.1:{srv.server_port}"
    srv.shutdown()


def test_openai_compatible_wire_format(fake_server):
    Fake.reply = {"model": "m", "usage": {"prompt_tokens": 12, "completion_tokens": 7},
                  "choices": [{"message": {"role": "assistant", "content": None, "tool_calls": [
                      {"id": "c1", "type": "function", "function": {"name": "get_weather", "arguments": "{\"city\": \"Oslo\"}"}}]}}]}
    m = OpenAICompatibleModel("m", base_url=fake_server, api_key="k")
    convo = [Message("system", "s"), Message("user", "u"),
             Message("assistant", "", [ToolCall("c0", "get_weather", {"city": "A"})]), Message("tool", "{}", tool_call_id="c0")]
    r = m.complete(convo, [get_weather.spec()])
    path, headers, body = Fake.seen[0]
    assert path == "/chat/completions" and headers["authorization"] == "Bearer k"
    assert body["tools"][0]["type"] == "function" and body["tools"][0]["function"]["name"] == "get_weather"
    assert body["messages"][2]["tool_calls"][0]["function"]["arguments"] == '{"city": "A"}'
    assert body["messages"][3] == {"role": "tool", "tool_call_id": "c0", "content": "{}"}
    assert r.message.tool_calls[0].arguments == {"city": "Oslo"} and r.usage.input_tokens == 12


def test_anthropic_wire_format(fake_server):
    Fake.reply = {"model": "m", "usage": {"input_tokens": 9, "output_tokens": 4}, "stop_reason": "tool_use",
                  "content": [{"type": "text", "text": "Checking."},
                              {"type": "tool_use", "id": "t1", "name": "get_weather", "input": {"city": "Oslo"}}]}
    m = AnthropicModel("m", api_key="k", base_url=fake_server)
    convo = [Message("system", "be brief"), Message("user", "u"),
             Message("assistant", "", [ToolCall("t0", "get_weather", {"city": "A"}), ToolCall("t9", "get_weather", {"city": "B"})]),
             Message("tool", "r0", tool_call_id="t0"), Message("tool", "r9", tool_call_id="t9")]
    r = m.complete(convo, [get_weather.spec()])
    path, headers, body = Fake.seen[0]
    assert path == "/messages" and headers["x-api-key"] == "k" and headers["anthropic-version"] == "2023-06-01"
    assert body["system"] == "be brief" and body["tools"][0]["input_schema"]["required"] == ["city"]
    assert body["messages"][2]["content"] == [{"type": "tool_result", "tool_use_id": "t0", "content": "r0"},
                                             {"type": "tool_result", "tool_use_id": "t9", "content": "r9"}]
    assert r.message.content == "Checking." and r.message.tool_calls[0].id == "t1"


def test_every_tool_call_gets_a_result_even_when_a_limit_stops_the_run():
    model = ScriptedModel([[call("get_weather", city=f"C{i}") for i in range(5)]])
    res = Agent(model, registry(), config=AgentConfig(max_tool_calls=3)).run("x")
    asked = [c.id for c in res.messages[-6].tool_calls]
    answered = [m.tool_call_id for m in res.messages if m.role == "tool"]
    assert asked == answered and res.messages[-1].content == "ERROR: not executed: tool-call limit reached"
