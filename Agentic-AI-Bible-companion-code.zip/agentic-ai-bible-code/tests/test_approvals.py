import pytest

from agentlab import Agent, ScriptedModel, ToolRegistry, call, tool
from agentlab.approvals import ApprovalQueue, QueueApprover


@tool(risk="write")
def create_return(order_id: str, sku: str) -> str:
    """Create a return."""
    return f"RMA for {order_id}/{sku}"


def test_request_is_bound_to_exact_action_and_expires():
    t = [0.0]
    q = ApprovalQueue(ttl_seconds=3600, clock=lambda: t[0])
    r = q.request("create_return", {"order_id": "BL-10388", "sku": "TN-ALPINE2"}, "zipper broke")
    assert q.request("create_return", {"sku": "TN-ALPINE2", "order_id": "BL-10388"}).id == r.id   # same action, no duplicate
    q.decide(r.id, True, by="ana")
    assert q.is_approved("create_return", {"order_id": "BL-10388", "sku": "TN-ALPINE2"})
    assert not q.is_approved("create_return", {"order_id": "BL-10388", "sku": "TN-SOLO1"})
    t[0] = 3601
    assert not q.is_approved("create_return", {"order_id": "BL-10388", "sku": "TN-ALPINE2"})
    r2 = q.request("create_return", {"order_id": "BL-10301", "sku": "JK-STORM"})
    t[0] = 9000
    assert q.get(r2.id).status == "expired" and q.pending() == []
    with pytest.raises(ValueError, match="expired"):
        q.decide(r2.id, True, by="ana")


def test_agent_files_request_then_succeeds_after_approval():
    q = ApprovalQueue()
    reg = ToolRegistry(approver=QueueApprover(q)).add(create_return)
    step = [call("create_return", order_id="BL-10388", sku="TN-ALPINE2")]
    first = Agent(ScriptedModel([step, "A colleague will review your return."]), reg).run("return tent")
    assert "approval denied" in first.messages[-2].content and len(q.pending()) == 1
    q.decide(q.pending()[0].id, True, by="ana", note="photo checked")
    second = Agent(ScriptedModel([step, "Your return is created."]), reg).run("return tent")
    assert second.messages[-2].content == "RMA for BL-10388/TN-ALPINE2"


def test_an_approval_authorises_one_execution_only():
    q = ApprovalQueue()
    reg = ToolRegistry(approver=QueueApprover(q)).add(create_return)
    args = {"order_id": "BL-10388", "sku": "TN-ALPINE2"}
    q.decide(q.request("create_return", args).id, True, by="ana")
    assert reg.call("create_return", args).ok
    assert "approval denied" in reg.call("create_return", args).error
